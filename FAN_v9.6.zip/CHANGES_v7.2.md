# FAN v7.2 — Değişiklikler

## 1) Filtreleme tamamen kaldırıldı (Ensemble + Yan)
- `TIER_NO_PRED` eşiği 0.0'a çekildi. Artık HİÇBİR koşulda "--" (tahmin yok / beklemede) gösterilmiyor.
- Ensemble her zaman ya SINGLE (tekil, `%≥65`) ya da DOUBLE (çiftli, `<65`) formatında;
  confidence 0.15–0.93 arası sürekli üretiliyor.
- Yan tahmin de her zaman iki formdan biri:
  - Her iki eksen de `%≥65` → çapraz + sayı: `T•B=3`, `C•K=2` vb.
  - Diğer tüm durumlar → çift harf: `T•B`, `C•K` vb.
  - Tek harf ya da "--" kaldırıldı.
- İlk 2 veriden azken (soğuk başlangıç) hâlâ "--" görünebilir (veri yetersiz); bu beklenen durum.

## 2) Yan tahmin başarısını artırmak için ek ayarlar
- `binyPattern` (v7.1'de eklenen ikili-eksenli pattern arayıcı) blend ağırlığı korundu:
  binary n-gram %58 + binyPattern %42 birleşimi ana eksen oylarını oluşturuyor,
  ardından 4-değerli yöntemlerin marjinali `BLEND_FULL=%40` oranında harmanlanıyor.
- Recency decay yan için 3.5x (daha keskin, yeni desenler daha baskın).
- Pattern length bonusu `len^1.25 / 14`; 6+ uzun desenler %3 ek bonus.
- Half-memory artık her tahminde (hem zayıf/çiftli) her iki eksen için de güncelleniyor.
- Warmup 5 örneğe indirildi (hızlı adapte).
- CAP 0.94, MIN 0.06 (aşırı kesinlik yok).
- 9 yan yöntem online ağırlık takibiyle çalışmaya devam ediyor; başarısız yöntem otomatik
  olarak düşük ağırlığa çekiliyor, başarılı olan yükseltiliyor.

## 3) CSV'ye güven (confidence) sütunları eklendi
Yeni sütunlar (geriye dönük uyumlu — eski CSV'ler de okunur; ayrım `c.size >= 90`):
- `ensemble_guven` → ensemble güveni (0-1 arası, % olarak gösterilir)
- `kalip_guven`    → kalıp arama güveni
- `yan_guven`      → yan tahmin OE+SB ortalama güveni
- `meta_guven`     → meta-öğrenci güveni
- Her 13 yöntem için artık 5 alan: `<isim>_tahmin | _dogru | _basari | _aktif | _guven`
  (eski formatta 4 alandı; yeni 5. alanda method confidence yazılıyor)

Bu sayede CSV'yi açıp her yöntemin/ensemble'ın o anki ne kadar "emin" olduğunu
görebilir ve güven skoru mantığının doğru çalışıp çalışmadığını denetleyebilirsin.

## 4) Diğer
- `noPredictionCount / sideNoPrediction / ensembleNoPred` sayaçları kaldırıldı
  (her zaman tahmin üretildiği için artık 0 olacaklardı).
- Overlay ve ana ekranda "Beklemede" ibaresi ve gri "--" gösterimi kaldırıldı;
  SINGLE yeşil, DOUBLE turuncu/beyaz renklendirme korundu.
- `v7.1` → `v7.2`, versionCode 8 → 9.
- Kalıp arama motoru (PatternMatcher) HİÇ DEĞİŞMEDİ:
  - max pattern uzunluğu dinamik (≤50 veri → 10, ≤100 → 15, 150+ → 25)
  - arama penceresi 2000
  - recency 3x keskin
  - uzun pattern (≥10) bonusu 1.5x
  - kalıp çıktısı her zaman çiftli (pri/sec).
- Kombine yöntemi her yerde kapalı/uyumluluk satırı olarak duruyor (0/HAYIR).
