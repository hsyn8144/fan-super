# FAN v8.0 — Hibrit (Kotlin + Python)

## Yeni: 3 çalışma modu
- 🔵 **Sadece Kotlin** — mevcut v7.2 davranışı
- ⚡ **Hibrit** — hem Kotlin hem 🐍 Python tahminleri ekranda ve overlay'de yan yana
- 🐍 **Sadece Python** — tahminler Termux'ta çalışan Python betiğinden okunur

Mod seçimi ana ekranda 3-sekmeli radyo grubu, ayrıca Ayarlar'dan değiştirilebilir.

## Yeni: Download/FAN/ kalıcı klasör
- Ayarlar'daki "Download/FAN/ klasörüne otomatik kopyala" (varsayılan AÇIK)
  açıkken ana veri `Download/FAN/fan_data.csv` olarak da tutulur.
- İki ayrı "veri temizle":
  - 🟠 **Uygulama verisini sıfırla** — sadece iç belleği temizler,
    Download/FAN/ klasörüne dokunmaz (ana veri korunur).
  - 🔴 **Klasörü sıfırla** — Download/FAN/ klasöründeki tüm dosyalar
    (ana CSV + Python log) çift/üç onaydan sonra silinir (GERİ ALINAMAZ).

## Overlay v8.0
- Hibrit modda 5 satır:
  1. 🔵 K (Kotlin ana)
  2. 🎯 Kalıp (her zaman çiftli)
  3. 🐍 Py (Python ana)
  4. 🔵 Yan (Kotlin çapraz)
  5. 🐍 PyYan (Python çapraz)
- Kompakt tutuldu (fontlar küçüldü, satır aralığı dar), ekranı kapatmaz.
- Yatay mod da 5 satırı kompakt gösterir.
- 2.5 sn'de bir `fan_python_log.csv`'yi kontrol eder, Python yeni
  tahmin ürettiyse anında overlay'e yansıtır.

## Yeni: Python bridge
- `PythonResult.kt` + `PythonBridge.kt` eklendi.
- `Download/FAN/fan_python_log.csv`'nin son satırı okunarak
  Python'un son tahmini/güveni/yan tahmini alınır.
- Ana ekranda ve overlay'de Python satırları yeşil renkle gösterilir.

## İstatistik ekranı v8.0
- Mod seçimine göre içerik değişir: Kotlin/Python/Hibrit.
- Hibritte iki kart yan yana: Kotlin mavi, Python yeşil, hangisi kazanıyor rozeti.
- Python'un son ağırlıkları ve güven kalibrasyonu da gösterilir.

## Python tarafı (`fan_live.py`)
- `Download/FAN/fan_data.csv`'yi izler, yeni veri geldikçe Hedge ensemble ile öğrenir.
- Her yeni tahmin için `fan_python_log.csv`'ye 16 kolonlu satır yazar:
  timestamp|pri|sec|conf|side_fmt|side_conf|oe_conf|sb_conf|
  kpri|ksec|kconf|evaluated|pri_acc|any_acc|side_any_acc|weights_summary
- 2 sn'de bir kontrol, 50 veri warmup, 9 strateji (kalip/markov/ngram/delta/streak/bias/ppm/binary/binyPattern).
- Son 50 veri kayan başarıyı takip eder.
- Canlı ekranda ağırlıklar ve tahminler gösterilir.

## v8.0 — Son Düzeltmeler (build #2)
- Açılışta içeride veri yoksa Download/FAN/fan_data.csv'den otomatik içe aktarma
- Ana ekrandaki "Verileri Temizle" butonunda kırmızı klasör-sıfırlama için 3 aşamalı onay (1/3, 2/3, 3/3)
- SettingsDialog'daki kırmızı buton da aynı şekilde 3 aşamalı onay
- WRITE/READ_EXTERNAL_STORAGE izinleri eklendi (API 28-32 için)
- Hibrit modda 5 satır (K, Kalıp, Py, KYan, PyYan) sorunsuz görünür
- tvSideIndependent referansı zaten yok (layout da kaldırılmıştı)
- Overlay compact: 15sp ana, 10sp etiket, dp(10) padding, butonlar 40dp
