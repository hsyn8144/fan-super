package com.fan.app.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.fan.app.R
import com.fan.app.data.CsvManager
import com.fan.app.data.PythonBridge
import com.fan.app.engine.PredictionEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class OverlayService : Service() {

    companion object {
        var isRunning = false
        const val CHANNEL_ID = "fan_overlay_channel"
        const val NOTIF_ID = 1001

        const val ACTION_REFRESH = "com.fan.app.overlay.ACTION_REFRESH"
        const val ACTION_APPLY_SETTINGS = "com.fan.app.overlay.ACTION_APPLY_SETTINGS"
    }

    private lateinit var overlayView: OverlayView
    private lateinit var engine: PredictionEngine
    private lateinit var csvManager: CsvManager

    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        csvManager = CsvManager(this)
        engine = PredictionEngine(csvManager)
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification())
        initOverlay()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_REFRESH -> refreshOverlay()
            ACTION_APPLY_SETTINGS -> {
                applySettingsFromPrefs()
                refreshOverlay()
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        serviceScope.cancel()

        if (::overlayView.isInitialized) {
            try { overlayView.hide() } catch (_: Exception) {}
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun initOverlay() {
        overlayView = OverlayView(this)

        overlayView.onValueEntered = { value ->
            serviceScope.launch {
                val result = engine.onNewValue(value)
                overlayView.updateDisplay(result)
                // Overlay'den girilen değeri de anında Download/FAN'a yazz
                try {
                    withContext(Dispatchers.IO) {
                        csvManager.ensureFileExists()
                        val sp = getSharedPreferences("fan_settings", Context.MODE_PRIVATE)
                        if (sp.getBoolean("csv_download_sync", true)) {
                            PythonBridge.syncDataToPublicFolder(
                                this@OverlayService, csvManager.readFullText())
                        }
                    }
                } catch (e: Exception) {
                    Log.w("FAN_Overlay", "Sync hatasi: ${e.message}")
                }
            }
        }
        overlayView.onDeletePressed = {
            serviceScope.launch {
                val result = engine.deleteLastValue()
                overlayView.updateDisplay(result)
            }
        }
        applySettingsFromPrefs()
        overlayView.show()
        refreshOverlay()
    }

    private fun refreshOverlay() {
        if (!::overlayView.isInitialized) return
        serviceScope.launch {
            val result = engine.getCurrentPrediction()
            overlayView.updateDisplay(result)
        }
    }

    private fun applySettingsFromPrefs() {
        if (!::overlayView.isInitialized) return
        val prefs = getSharedPreferences("fan_settings", Context.MODE_PRIVATE)
        overlayView.setButtonSize(prefs.getInt("button_size", 100))
        overlayView.setOpacity(prefs.getInt("button_opacity", 30))
        overlayView.setFadeDelay(prefs.getInt("fade_delay", 4) * 1000L)
        overlayView.setVibrationEnabled(prefs.getBoolean("vibration", false))
        overlayView.setRunMode(prefs.getInt("run_mode", PythonBridge.MODE_KOTLIN))
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID, "FAN Overlay", NotificationManager.IMPORTANCE_LOW
        ).apply { description = "FAN overlay servisi"; setShowBadge(false) }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("FAN v9.6 Aktif")
            .setContentText("Overlay çalışıyor (Hibrit/Kotlin/Python mod hazır)")
            .setSmallIcon(R.drawable.ic_fan_logo)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .build()
    }
}
