package com.fan.app.ui

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.Window
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import com.fan.app.data.CsvManager
import com.fan.app.data.PythonBridge

class SettingsDialog(context: Context) : Dialog(context) {

    private val prefs = context.getSharedPreferences("fan_settings", Context.MODE_PRIVATE)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        buildUI()
    }

    private fun buildUI() {
        val scroll = ScrollView(context)
        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(Color.parseColor("#F5F5F5"))
        }

        val title = TextView(context).apply {
            text = "Ayarlar"
            textSize = 18f
            setTextColor(Color.parseColor("#212121"))
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 16)
        }
        container.addView(title)

        val version = TextView(context).apply {
            text = "FAN v9.6 - Hibrit Mod (Kotlin + Python)"
            textSize = 11f
            setTextColor(Color.parseColor("#757575"))
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 16)
        }
        container.addView(version)

        // CALISMA MODU
        container.addView(sectionHeader("CALISMA MODU"))

        val currentMode = prefs.getInt("run_mode", PythonBridge.MODE_KOTLIN)
        val radioGroup = RadioGroup(context).apply {
            orientation = RadioGroup.VERTICAL
            setPadding(8, 4, 0, 8)
        }
        val rbKotlin = RadioButton(context).apply { text = "Mavi Nur: Sadece Kotlin"; tag = PythonBridge.MODE_KOTLIN }
        val rbHybrid = RadioButton(context).apply { text = "Yildirim: Hibrit (ikisi birlikte)"; tag = PythonBridge.MODE_HYBRID }
        val rbPython = RadioButton(context).apply { text = "Yilan: Sadece Python"; tag = PythonBridge.MODE_PYTHON }
        radioGroup.addView(rbKotlin)
        radioGroup.addView(rbHybrid)
        radioGroup.addView(rbPython)
        radioGroup.check(when (currentMode) {
            PythonBridge.MODE_PYTHON -> rbPython.id
            PythonBridge.MODE_HYBRID -> rbHybrid.id
            else -> rbKotlin.id
        })
        radioGroup.setOnCheckedChangeListener { _, _ ->
            val selected = radioGroup.findViewById<RadioButton>(radioGroup.checkedRadioButtonId)
            val mode = selected?.tag as? Int ?: PythonBridge.MODE_KOTLIN
            prefs.edit().putInt("run_mode", mode).apply()
        }
        container.addView(radioGroup)
        container.addView(buildDivider())

        // Overlay ayarlari
        val currentSize = prefs.getInt("button_size", 100)
        val sizeLabel = buildLabel("Buton Boyutu: %$currentSize")
        container.addView(sizeLabel)
        container.addView(buildSeekBar(min = 60, max = 150, step = 10, current = currentSize) { value ->
            sizeLabel.text = "Buton Boyutu: %$value"
            prefs.edit().putInt("button_size", value).apply()
        })

        val currentOpacity = prefs.getInt("button_opacity", 30)
        val opacityLabel = buildLabel("Buton Seffafligi: %$currentOpacity")
        container.addView(opacityLabel)
        container.addView(buildSeekBar(min = 10, max = 100, step = 10, current = currentOpacity) { value ->
            opacityLabel.text = "Buton Seffafligi: %$value"
            prefs.edit().putInt("button_opacity", value).apply()
        })

        val currentDelay = prefs.getInt("fade_delay", 4)
        val delayLabel = buildLabel("Seffaflik Gecikmesi: ${currentDelay}sn")
        container.addView(delayLabel)
        container.addView(buildSeekBar(min = 2, max = 15, step = 1, current = currentDelay) { value ->
            delayLabel.text = "Seffaflik Gecikmesi: ${value}sn"
            prefs.edit().putInt("fade_delay", value).apply()
        })
        container.addView(buildDivider())

        // Titresim
        container.addView(buildSwitch("Titresim", "vibration", false))
        container.addView(buildDivider())

        // CSV SENKRONIZASYONU
        container.addView(sectionHeader("CSV SENKRONIZASYONU"))
        container.addView(buildSwitchRow(
            "Download/FAN/ klasorune otomatik kopyala",
            "Python/Termux bu klasorden otomatik okur",
            "csv_download_sync", true
        ))

        val syncNowBtn = Button(context).apply {
            text = "Download/FAN'daki veriyi iceri yukle"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#2E7D32"))
            setPadding(0, 12, 0, 12)
            setOnClickListener {
                try {
                    val csv = CsvManager(context)
                    val loaded = PythonBridge.readDataFromPublicFolder()
                    if (loaded != null && loaded.isNotBlank()) {
                        csv.writeFullText(loaded)
                        csv.invalidateCache()
                        val lines = loaded.lines().filter { it.isNotBlank() }
                        val count = lines.count { !it.startsWith("id|") }
                        Toast.makeText(context,
                            "Download/FAN'dan $count veri yuklendi",
                            Toast.LENGTH_SHORT).show()
                    } else {
                        csv.ensureFileExists()
                        csv.syncToDownload(context)
                        Toast.makeText(context, "Download/FAN/ klasorune yazildi (icerden disari)", Toast.LENGTH_SHORT).show()
                    }
                } catch (ex: Exception) {
                    Toast.makeText(context, "Hata: ${ex.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
        container.addView(syncNowBtn, marginParams(top = 8, bottom = 4))

        val syncOutBtn = Button(context).apply {
            text = "Icerideki veriyi Download/FAN'a yaz"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#1565C0"))
            setPadding(0, 12, 0, 12)
            setOnClickListener {
                try {
                    val csv = CsvManager(context)
                    csv.ensureFileExists()
                    csv.syncToDownload(context)
                    Toast.makeText(context, "Download/FAN/ klasorune yazildi", Toast.LENGTH_SHORT).show()
                } catch (ex: Exception) {
                    Toast.makeText(context, "Hata: ${ex.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
        container.addView(syncOutBtn, marginParams(top = 4, bottom = 8))
        container.addView(buildDivider())

        // VERI SIFIRLAMA
        container.addView(sectionHeader("!! VERI SIFIRLAMA", Color.parseColor("#E65100")))

        val clearAppBtn = Button(context).apply {
            text = "Uygulama verisini sifirla"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#FB8C00"))
            setPadding(0, 14, 0, 14)
            setOnClickListener {
                showDoubleConfirm(
                    title = "Uygulama verisi silinecek",
                    message = "Sadece uygulamanin ic bellegi temizlenecek. Download/FAN/ klasorundeki ana veri ETKILENMEYECEK.",
                    okColor = Color.parseColor("#FB8C00")
                ) {
                    prefs.edit().putBoolean("pending_app_clear", true).apply()
                    Toast.makeText(context, "Uygulama ici veriyi sifirla isaretlendi. Cikinca uygulanacak.", Toast.LENGTH_SHORT).show()
                }
            }
        }
        container.addView(clearAppBtn, marginParams(top = 4, bottom = 8))

        val clearFolderBtn = Button(context).apply {
            text = "Download/FAN/ klasorunu sifirla"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#C62828"))
            setPadding(0, 14, 0, 14)
            setOnClickListener {
                // 3 asamali onay
                android.app.AlertDialog.Builder(context)
                    .setTitle("!! DIKKAT (1/3)")
                    .setMessage("Download/FAN/ klasorundeki TUM veriler (ana CSV + Python log) GERI ALINAMAYACAK sekilde silinecek.\n\nDevam etmek istiyor musun?")
                    .setPositiveButton("Evet") { d, _ ->
                        d.dismiss()
                        android.app.AlertDialog.Builder(context)
                            .setTitle("!! SON KARAR (2/3)")
                            .setMessage("Bu islem verilerinizi KALICI olarak silecek. Emin misiniz?")
                            .setPositiveButton("Evet, sil") { d2, _ ->
                                d2.dismiss()
                                android.app.AlertDialog.Builder(context)
                                    .setTitle("!!! SON UYARI (3/3)")
                                    .setMessage("GERI DONUS YOK. \"SIL\" butonuna basarsan veriler tamamen gider.")
                                    .setPositiveButton("SIL") { _, _ ->
                                        val ok = PythonBridge.deletePublicData()
                                        Toast.makeText(context,
                                            if (ok) "Klasor temizlendi (dosya yapisi korundu)." else "Klasor temizlenemedi (izin?).",
                                            Toast.LENGTH_SHORT).show()
                                    }
                                    .setNegativeButton("Iptal", null)
                                    .show()
                            }
                            .setNegativeButton("Iptal", null)
                            .show()
                    }
                    .setNegativeButton("Iptal", null)
                    .show()
            }
        }
        container.addView(clearFolderBtn, marginParams(top = 0, bottom = 8))
        container.addView(buildDivider())

        val saveBtn = Button(context).apply {
            text = "Kaydet & Kapat"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#1565C0"))
            setPadding(0, 16, 0, 16)
            setOnClickListener { dismiss() }
        }
        container.addView(saveBtn, marginParams(top = 8))

        scroll.addView(container)
        setContentView(scroll)
        window?.setLayout(
            (context.resources.displayMetrics.widthPixels * 0.92).toInt(),
            android.view.WindowManager.LayoutParams.WRAP_CONTENT
        )
    }

    private fun sectionHeader(text: String, color: Int = Color.parseColor("#0D47A1")): TextView {
        return TextView(context).apply {
            this.text = text
            textSize = 12f
            setTextColor(color)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, 10, 0, 6)
        }
    }

    private fun buildLabel(text: String): TextView = TextView(context).apply {
        this.text = text
        textSize = 14f
        setTextColor(Color.parseColor("#212121"))
        setPadding(0, 8, 0, 4)
    }

    private fun buildSeekBar(min: Int, max: Int, step: Int, current: Int, onChange: (Int) -> Unit): SeekBar {
        val steps = (max - min) / step
        val currentStep = (current - min) / step
        return SeekBar(context).apply {
            this.max = steps
            progress = currentStep
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                    onChange(min + (progress * step))
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
    }

    private fun buildSwitch(label: String, key: String, default: Boolean): View {
        return buildSwitchRow(label, null, key, default)
    }

    private fun buildSwitchRow(label: String, sub: String?, key: String, default: Boolean): View {
        val row = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 8, 0, 8)
        }
        val top = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val lab = TextView(context).apply {
            text = label
            textSize = 14f
            setTextColor(Color.parseColor("#212121"))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val sw = Switch(context).apply {
            isChecked = prefs.getBoolean(key, default)
            setOnCheckedChangeListener { _, isChecked ->
                prefs.edit().putBoolean(key, isChecked).apply()
                if (isChecked && key == "csv_download_sync") {
                    try { CsvManager(context).syncToDownload(context) } catch (_: Exception) {}
                }
            }
        }
        top.addView(lab)
        top.addView(sw)
        row.addView(top)
        if (sub != null) {
            val subLab = TextView(context).apply {
                text = sub
                textSize = 10f
                setTextColor(Color.parseColor("#757575"))
                setPadding(0, 2, 0, 0)
            }
            row.addView(subLab)
        }
        return row
    }

    private fun buildDivider(): View = View(context).apply {
        setBackgroundColor(Color.parseColor("#E0E0E0"))
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 1
        ).apply { topMargin = 8; bottomMargin = 8 }
    }

    private fun marginParams(top: Int = 0, bottom: Int = 0): LinearLayout.LayoutParams {
        return LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = top; bottomMargin = bottom }
    }

    private fun showDoubleConfirm(
        title: String,
        message: String,
        okColor: Int = Color.parseColor("#C62828"),
        onOk: () -> Unit
    ) {
        android.app.AlertDialog.Builder(context)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("Evet, devam et") { d, _ -> onOk(); d.dismiss() }
            .setNegativeButton("Iptal", null)
            .show()
    }
}
