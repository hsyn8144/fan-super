package com.fan.app.engine

object MethodWeightTracker {

    private val consecutiveWrongs = mutableMapOf<Int, Int>()
    private val lastPrediction = mutableMapOf<Int, Int>()
    private val multipliers = mutableMapOf<Int, Double>()
    private val correctRates = mutableMapOf<Int, EmaTracker>()

    private class EmaTracker(alpha: Double = 0.1) {
        private val a = alpha
        var value = 0.5
        fun update(correct: Boolean) {
            value = value * (1 - a) + (if (correct) 1.0 else 0.0) * a
        }
    }

    fun getMultiplier(methodIndex: Int): Double {
        val base = multipliers[methodIndex] ?: 1.0
        val ema = correctRates[methodIndex]?.value ?: 0.5
        // v2.2: karesiyle ağırlıklandır — düşük doğruluk daha hızlı cezalandırılıyor
        val emaFactor = if (ema >= 0.25) {
            val n = ((ema - 0.25) / 0.55).coerceIn(0.0, 1.0)
            0.4 + 1.4 * n * n   // 0.4 .. 1.8
        } else {
            0.15 + 0.6 * (ema / 0.25)  // 0.15 .. 0.75 — çok kötü yöntemler kısılır
        }
        return (base * emaFactor).coerceIn(0.05, 2.5)
    }

    fun getAccuracy(methodIndex: Int): Double = correctRates[methodIndex]?.value ?: 0.5

    fun update(methodIndex: Int, prediction: Int, actualValue: Int) {
        if (prediction <= 0) return
        val isCorrect = prediction == actualValue
        val lastPred = lastPrediction[methodIndex]

        // EMA accuracy (independent of prediction identity)
        correctRates.getOrPut(methodIndex) { EmaTracker() }.update(isCorrect)

        if (!isCorrect) {
            if (lastPred == prediction) {
                val wrongCount = (consecutiveWrongs[methodIndex] ?: 0) + 1
                consecutiveWrongs[methodIndex] = wrongCount
                if (wrongCount >= 2) {
                    val cur = multipliers[methodIndex] ?: 1.0
                    multipliers[methodIndex] = maxOf(cur * 0.55, 0.15)  // softer punishment
                }
            } else {
                consecutiveWrongs[methodIndex] = 1
            }
        } else {
            consecutiveWrongs[methodIndex] = 0
            val cur = multipliers[methodIndex] ?: 1.0
            multipliers[methodIndex] = minOf(cur * 1.2, 1.0)
        }
        lastPrediction[methodIndex] = prediction
    }

    fun reset() {
        consecutiveWrongs.clear()
        lastPrediction.clear()
        multipliers.clear()
        correctRates.clear()
    }
}
