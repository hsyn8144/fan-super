package com.fan.app.engine

class BayesianUpdater {

    // Cached conditional counts — not reset between calls; incrementally updated
    private val conditionalCounts = mutableMapOf<Pair<Int, Int>, Double>()
    private val priorCounts = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)
    private var trainedSize = 0
    private val decayFactor = 0.995
    private val alpha = 0.5

    fun compute(data: List<Int>): Map<Int, Double> {
        if (data.size < 3) return equal()

        val last = data.last()

        // Incremental train — only process newly added data
        val startIdx = maxOf(1, trainedSize)
        if (startIdx < data.size) {
            // Apply slight decay to all existing counts to favor recency
            for (k in conditionalCounts.keys) conditionalCounts[k] = (conditionalCounts[k]!!) * decayFactor
            for (k in priorCounts.keys) priorCounts[k] = (priorCounts[k]!!) * decayFactor

            for (i in startIdx until data.size - 1) {
                val from = data[i]
                val to = data[i + 1]
                // Higher weight for recent transitions
                val recencyWeight = 1.0  // decay already applied globally
                conditionalCounts[Pair(from, to)] = (conditionalCounts[Pair(from, to)] ?: 0.0) + recencyWeight
                priorCounts[to] = (priorCounts[to] ?: 0.0) + recencyWeight
            }
            trainedSize = data.size - 1
        }

        val votes = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)
        val totalFromLast = (1..4).sumOf { conditionalCounts[Pair(last, it)] ?: 0.0 }

        val totalPrior = priorCounts.values.sum()

        for (next in 1..4) {
            val conditional = conditionalCounts[Pair(last, next)] ?: 0.0
            val prior = priorCounts[next] ?: 0.0

            val likelihood = if (totalFromLast > 0)
                (conditional + alpha) / (totalFromLast + alpha * 4)
            else 0.25

            val priorProb = if (totalPrior > 0)
                (prior + alpha) / (totalPrior + alpha * 4)
            else 0.25

            // Adaptive weighting: use more likelihood when data is rich
            val likelihoodWeight = (totalFromLast / (totalFromLast + 8.0)).coerceIn(0.3, 0.8)
            votes[next] = likelihood * likelihoodWeight + priorProb * (1 - likelihoodWeight)
        }

        val total = votes.values.sum()
        if (total == 0.0) return equal()
        return votes.mapValues { it.value / total }
    }

    fun reset() {
        conditionalCounts.clear()
        priorCounts.clear()
        priorCounts.putAll(mapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0))
        trainedSize = 0
    }

    private fun equal() = mapOf(1 to 0.25, 2 to 0.25, 3 to 0.25, 4 to 0.25)
}
