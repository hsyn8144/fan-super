package com.fan.app.engine

import com.fan.app.data.CsvManager
import com.fan.app.data.DataEntry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

class PredictionEngine(private val csvManager: CsvManager) {

    companion object { const val SILENT_THRESHOLD = 50 }

    private val mutex = Mutex()
    private var lastComputedResult: Ensemble.EnsembleResult? = null
    private var pendingEntry: DataEntry? = null

    // In-memory rolling counters for incremental accuracy
    private data class RollingStats(
        var total: Int = 0,
        var ensembleCorrect: Int = 0,
        var ensembleSecCorrect: Int = 0,
        var ensembleTotalCorrect: Int = 0,
        var kalipCorrect: Int = 0,
        var kalipSecCorrect: Int = 0,
        var sideCorrect: Int = 0,          // any correct (main metric)
        val methodCorrect: IntArray = IntArray(DataEntry.METHOD_COUNT),
        val methodActive: IntArray = IntArray(DataEntry.METHOD_COUNT)
    )

    private val stats = RollingStats()

    suspend fun onNewValue(value: Int): EngineResult = withContext(Dispatchers.Default) {
        mutex.withLock {
            val allEntries = csvManager.readAllEntries()
            val allData = allEntries.map { it.value }.toMutableList()
            val totalBefore = allData.size
            val prevResult = lastComputedResult
            val prevEntry = pendingEntry

            if (prevEntry != null && prevResult != null && totalBefore > 0) {
                // v7.2: filtre yok — her zaman tahmin var
                val isCorrect    = prevResult.finalPrediction == value
                val secCorrect   = prevResult.tier == "DOUBLE" && prevResult.secondPrediction != null && prevResult.secondPrediction == value

                val sideDetailed = SidePrediction.checkCorrect(prevResult.sidePrediction, value)
                val sideCorrectAny = sideDetailed.any

                val kalipCorrect = prevResult.kalipPrediction == value
                val kalipSecCorr = prevResult.kalipSecondary != null && prevResult.kalipSecondary == value

                // Update rolling stats (ilk 50 veri sayılmaz)
                if (totalBefore >= SILENT_THRESHOLD) {
                    stats.total++
                    if (isCorrect) stats.ensembleCorrect++
                    if (secCorrect) stats.ensembleSecCorrect++
                    if (isCorrect || secCorrect) stats.ensembleTotalCorrect++
                    if (kalipCorrect) stats.kalipCorrect++
                    if (kalipSecCorr) stats.kalipSecCorrect++
                    if (sideCorrectAny) stats.sideCorrect++
                }

                // Online confidence calibration (ensemble)
                Ensemble.recordCalibrationOutcome(isCorrect || secCorrect)

                // Update SidePrediction online performance
                val regimeGroup = extractRegimeGroup(prevEntry)
                val dataForSide = allData.dropLast(1)
                SidePrediction.updatePerformanceWithData(dataForSide, prevResult.sidePrediction, value, regimeGroup)

                val updatedEntry = updateEntryWithResult(
                    prevEntry, value,
                    isCorrect, secCorrect, sideCorrectAny,
                    kalipCorrect, kalipSecCorr,
                    prevResult,
                    allEntries
                )
                csvManager.updateLastEntry(updatedEntry)

                // Update per-method correct/active stats
                val methodPreds = listOf(
                    prevEntry.method1Prediction,  prevEntry.method2Prediction,
                    prevEntry.method3Prediction,  prevEntry.method4Prediction,
                    prevEntry.method5Prediction,  prevEntry.method6Prediction,
                    prevEntry.method7Prediction,  prevEntry.method8Prediction,
                    prevEntry.method9Prediction,  prevEntry.method10Prediction,
                    prevEntry.method11Prediction, prevEntry.method12Prediction,
                    prevEntry.method13Prediction
                )
                val methodActives = listOf(
                    prevEntry.method1Active,  prevEntry.method2Active,
                    prevEntry.method3Active,  prevEntry.method4Active,
                    prevEntry.method5Active,  prevEntry.method6Active,
                    prevEntry.method7Active,  prevEntry.method8Active,
                    prevEntry.method9Active,  prevEntry.method10Active,
                    prevEntry.method11Active, prevEntry.method12Active,
                    prevEntry.method13Active
                )
                methodPreds.forEachIndexed { idx, pred ->
                    if (pred > 0) {
                        MethodWeightTracker.update(idx, pred, value)
                    }
                    if (totalBefore >= SILENT_THRESHOLD) {
                        if (methodActives[idx]) {
                            stats.methodActive[idx]++
                            if (pred == value) stats.methodCorrect[idx]++
                        }
                    }
                }
            }

            allData.add(value)
            val newResult = Ensemble.compute(allData, allEntries)
            lastComputedResult = newResult
            val entry = buildEntry(totalBefore + 1L, value, newResult, allEntries)
            csvManager.appendEntry(entry)
            pendingEntry = entry

            EngineResult(newResult, totalBefore < SILENT_THRESHOLD, allData.size, allData.takeLast(6).reversed())
        }
    }

    suspend fun deleteLastValue(): EngineResult? = withContext(Dispatchers.Default) {
        mutex.withLock {
            val allEntries = csvManager.readAllEntries()
            if (allEntries.isEmpty()) return@withLock null
            csvManager.deleteLastEntry()
            val remaining = allEntries.dropLast(1).map { it.value }
            pendingEntry = if (remaining.isNotEmpty()) csvManager.readAllEntries().lastOrNull() else null
            val newResult = if (remaining.size >= 2) {
                Ensemble.compute(remaining).also { lastComputedResult = it }
            } else { lastComputedResult = null; null }
            resetRollingStats()
            EngineResult(newResult, remaining.size < SILENT_THRESHOLD, remaining.size, remaining.takeLast(6).reversed())
        }
    }

    suspend fun getCurrentPrediction(): EngineResult = withContext(Dispatchers.Default) {
        val allEntries = csvManager.readAllEntries()
        val allData = allEntries.map { it.value }
        val result = if (allData.size >= 2) {
            Ensemble.compute(allData, allEntries).also { lastComputedResult = it }
        } else null
        pendingEntry = allEntries.lastOrNull()
        EngineResult(result, allData.size < SILENT_THRESHOLD, allData.size, allData.takeLast(6).reversed())
    }

    suspend fun getStats(): StatsResult = withContext(Dispatchers.Default) {
        if (stats.total == 0) recomputeRollingStats()
        val (primary, totalHits, size) = csvManager.getEnsembleStats()
        val totalAll = csvManager.getTotalCount()
        val methodStats = csvManager.getMethodStats()
        val n = stats.total.coerceAtLeast(1)
        StatsResult(
            totalCount = totalAll,
            evaluatedCount = size,
            evaluatedWithPrediction = size,
            correctCount = primary,
            totalCorrectCount = totalHits,
            noPredictionCount = 0,
            accuracy = if (size > 0) primary.toDouble() / size else 0.0,
            totalAccuracy = if (size > 0) totalHits.toDouble() / size else 0.0,
            kalipAccuracy = if (n > 0) stats.kalipCorrect.toDouble() / n else 0.0,
            sideAnyAccuracy = if (n > 0) stats.sideCorrect.toDouble() / n else 0.0,
            methodStats = methodStats
        )
    }

    private fun recomputeRollingStats() {
        resetRollingStats()
        val entries = csvManager.readAllEntries().drop(SILENT_THRESHOLD)
        for (e in entries) {
            stats.total++
            // v7.2: filtre yok — her zaman tahmin var
            if (e.ensembleCorrect) stats.ensembleCorrect++
            if (e.ensembleSecCorrect) stats.ensembleSecCorrect++
            if (e.ensembleCorrect || e.ensembleSecCorrect) stats.ensembleTotalCorrect++
            if (e.kalipCorrect) stats.kalipCorrect++
            if (e.kalipSecCorrect) stats.kalipSecCorrect++
            // Side: "--" artık olmayacak ama eski kayıtlar için güvenli ol
            if (e.sidePrediction != "--" && e.sideCorrect) stats.sideCorrect++

            val preds = listOf(
                e.method1Prediction, e.method2Prediction, e.method3Prediction, e.method4Prediction,
                e.method5Prediction, e.method6Prediction, e.method7Prediction, e.method8Prediction,
                e.method9Prediction, e.method10Prediction, e.method11Prediction, e.method12Prediction,
                e.method13Prediction
            )
            val acts = listOf(
                e.method1Active, e.method2Active, e.method3Active, e.method4Active,
                e.method5Active, e.method6Active, e.method7Active, e.method8Active,
                e.method9Active, e.method10Active, e.method11Active, e.method12Active,
                e.method13Active
            )
            for (i in 0 until DataEntry.METHOD_COUNT) {
                if (acts[i]) {
                    stats.methodActive[i]++
                    if (preds[i] == e.value) stats.methodCorrect[i]++
                }
            }
        }
    }

    private fun resetRollingStats() {
        stats.total = 0
        stats.ensembleCorrect = 0
        stats.ensembleSecCorrect = 0
        stats.ensembleTotalCorrect = 0
        stats.kalipCorrect = 0
        stats.kalipSecCorrect = 0
        stats.sideCorrect = 0
        stats.methodCorrect.fill(0)
        stats.methodActive.fill(0)
    }

    private fun extractRegimeGroup(entry: DataEntry): String {
        val r = entry.currentRegime
        return when {
            r.contains("TEKRAR") -> "TEKRAR"
            r.contains("YON") || r.contains("ARTIS") || r.contains("AZALIS") ||
                r.contains("TEPE") || r.contains("VADI") || r.contains("DONGU") -> "YON"
            r.contains("SALINIM") || r.contains("ZIT") || r.contains("ORT") ||
                r.contains("KOSEGEN") || r.contains("ZIGZAK") -> "SALINIMM"
            else -> "KAOS"
        }
    }

    private fun buildEntry(
        id: Long, value: Int,
        result: Ensemble.EnsembleResult,
        allEntries: List<DataEntry>
    ): DataEntry {
        val evaluated = allEntries.drop(SILENT_THRESHOLD)
        val n = evaluated.size + 1

        fun acc(correctCount: Int, isCurrentCorrect: Boolean): Double {
            if (n < 5) return 0.0
            val c = correctCount + (if (isCurrentCorrect) 0 else 0)
            return c.toDouble() / n
        }

        val mv = result.methodVotes
        // Her yöntemin güveni (confidence)
        fun mConf(idx: Int): Double = mv.getOrNull(idx)?.confidence ?: 0.0
        val sideConfAvg = (result.sidePrediction.oddEvenConfidence + result.sidePrediction.smallBigConfidence) / 2.0
        // Kalıp güveni
        val kalipMv = mv.getOrNull(0)
        val kalipConf = kalipMv?.confidence ?: 0.0

        return DataEntry(
            id = id, value = value,
            ensemblePrediction    = result.finalPrediction,
            ensembleSecondary     = if (result.tier == "DOUBLE") (result.secondPrediction ?: 0) else 0,
            ensembleIsDouble      = result.tier == "DOUBLE" && result.secondPrediction != null,
            ensembleTier          = result.tier,
            ensembleCorrect       = false,
            ensembleTotalAccuracy = acc(stats.ensembleTotalCorrect, false),
            ensembleAccuracy      = acc(stats.ensembleCorrect, false),
            ensembleSecCorrect    = false,
            ensembleSecAccuracy   = acc(stats.ensembleSecCorrect, false),
            ensembleConfidence    = result.confidence,
            kalipPrediction       = result.kalipPrediction,
            kalipSecondary        = result.kalipSecondary ?: 0,
            kalipIsDouble         = true,
            kalipCorrect          = false,
            kalipSecCorrect       = false,
            kalipAccuracy         = acc(stats.kalipCorrect, false),
            kalipConfidence       = kalipConf,
            sidePrediction        = result.sideFormatted,
            sideCorrect           = false,
            sideAccuracy          = acc(stats.sideCorrect, false),
            sideConfidence        = sideConfAvg,
            currentRegime         = result.currentRegime,
            detectedPattern       = result.detectedPattern,
            regimeSequence        = result.regimeSequence,
            anomalyFlags          = result.anomalyInfo?.let { AnomalyDetector.formatAnomalyFlags(it) } ?: "",
            confidenceAdjusted    = (result.anomalyInfo?.confidenceAdjustment ?: 1.0) != 1.0,
            metaConfidence        = result.metaConfidence,
            method1Prediction  = mv.getOrNull(0)?.topPrediction  ?: 0, method1Correct  = false, method1Accuracy  = mAcc(0),  method1Active  = mv.getOrNull(0)?.isActive  ?: true, conf1 = mConf(0),
            method2Prediction  = mv.getOrNull(1)?.topPrediction  ?: 0, method2Correct  = false, method2Accuracy  = mAcc(1),  method2Active  = mv.getOrNull(1)?.isActive  ?: true, conf2 = mConf(1),
            method3Prediction  = mv.getOrNull(2)?.topPrediction  ?: 0, method3Correct  = false, method3Accuracy  = mAcc(2),  method3Active  = mv.getOrNull(2)?.isActive  ?: true, conf3 = mConf(2),
            method4Prediction  = mv.getOrNull(3)?.topPrediction  ?: 0, method4Correct  = false, method4Accuracy  = mAcc(3),  method4Active  = mv.getOrNull(3)?.isActive  ?: true, conf4 = mConf(3),
            method5Prediction  = mv.getOrNull(4)?.topPrediction  ?: 0, method5Correct  = false, method5Accuracy  = mAcc(4),  method5Active  = mv.getOrNull(4)?.isActive  ?: true, conf5 = mConf(4),
            method6Prediction  = mv.getOrNull(5)?.topPrediction  ?: 0, method6Correct  = false, method6Accuracy  = mAcc(5),  method6Active  = mv.getOrNull(5)?.isActive  ?: true, conf6 = mConf(5),
            method7Prediction  = mv.getOrNull(6)?.topPrediction  ?: 0, method7Correct  = false, method7Accuracy  = mAcc(6),  method7Active  = mv.getOrNull(6)?.isActive  ?: true, conf7 = mConf(6),
            method8Prediction  = mv.getOrNull(7)?.topPrediction  ?: 0, method8Correct  = false, method8Accuracy  = mAcc(7),  method8Active  = mv.getOrNull(7)?.isActive  ?: true, conf8 = mConf(7),
            method9Prediction  = mv.getOrNull(8)?.topPrediction  ?: 0, method9Correct  = false, method9Accuracy  = mAcc(8),  method9Active  = mv.getOrNull(8)?.isActive  ?: true, conf9 = mConf(8),
            method10Prediction = mv.getOrNull(9)?.topPrediction  ?: 0, method10Correct = false, method10Accuracy = mAcc(9),  method10Active = mv.getOrNull(9)?.isActive  ?: true, conf10 = mConf(9),
            method11Prediction = mv.getOrNull(10)?.topPrediction ?: 0, method11Correct = false, method11Accuracy = mAcc(10), method11Active = mv.getOrNull(10)?.isActive ?: true, conf11 = mConf(10),
            method12Prediction = mv.getOrNull(11)?.topPrediction ?: 0, method12Correct = false, method12Accuracy = mAcc(11), method12Active = mv.getOrNull(11)?.isActive ?: true, conf12 = mConf(11),
            method13Prediction = mv.getOrNull(12)?.topPrediction ?: 0, method13Correct = false, method13Accuracy = mAcc(12), method13Active = mv.getOrNull(12)?.isActive ?: true, conf13 = mConf(12)
        )
    }

    private fun updateEntryWithResult(
        entry: DataEntry, actualValue: Int,
        isCorrect: Boolean, secCorrect: Boolean, sideCorrect: Boolean,
        kalipCorrect: Boolean, kalipSecCorrect: Boolean,
        result: Ensemble.EnsembleResult,
        allEntries: List<DataEntry>
    ): DataEntry {
        val evaluated = allEntries.drop(SILENT_THRESHOLD)
        val newTotal = evaluated.size + 1
        fun newAcc(prevCount: Int, hit: Boolean): Double {
            if (newTotal < 5) return 0.0
            val c = prevCount + (if (hit) 1 else 0)
            return c.toDouble() / newTotal
        }
        return entry.copy(
            ensembleCorrect       = isCorrect,
            ensembleTotalAccuracy = newAcc(evaluated.count { it.ensembleCorrect || it.ensembleSecCorrect }, isCorrect || secCorrect),
            ensembleAccuracy      = newAcc(evaluated.count { it.ensembleCorrect }, isCorrect),
            ensembleSecCorrect    = secCorrect,
            ensembleSecAccuracy   = newAcc(evaluated.count { it.ensembleSecCorrect }, secCorrect),
            kalipCorrect          = kalipCorrect,
            kalipSecCorrect       = kalipSecCorrect,
            kalipAccuracy         = newAcc(evaluated.count { it.kalipCorrect }, kalipCorrect),
            sideCorrect           = sideCorrect,
            sideAccuracy          = newAcc(evaluated.count { it.sideCorrect }, sideCorrect),
            method1Correct  = entry.method1Prediction  == actualValue,
            method2Correct  = entry.method2Prediction  == actualValue,
            method3Correct  = entry.method3Prediction  == actualValue,
            method4Correct  = entry.method4Prediction  == actualValue,
            method5Correct  = entry.method5Prediction  == actualValue,
            method6Correct  = entry.method6Prediction  == actualValue,
            method7Correct  = entry.method7Prediction  == actualValue,
            method8Correct  = entry.method8Prediction  == actualValue,
            method9Correct  = entry.method9Prediction  == actualValue,
            method10Correct = entry.method10Prediction == actualValue,
            method11Correct = entry.method11Prediction == actualValue,
            method12Correct = entry.method12Prediction == actualValue,
            method13Correct = entry.method13Prediction == actualValue
        )
    }

    private fun mAcc(index: Int): Double {
        val active = stats.methodActive[index]
        val correct = stats.methodCorrect[index]
        return if (active >= 5) correct.toDouble() / active else 0.0
    }

    fun clearAll() {
        csvManager.clearAll()
        lastComputedResult = null
        pendingEntry = null
        resetRollingStats()
        MethodWeightTracker.reset()
        Ensemble.reset()
    }

    data class EngineResult(
        val ensembleResult: Ensemble.EnsembleResult?,
        val isSilent: Boolean,
        val totalDataCount: Int,
        val recentValues: List<Int>
    )

    data class StatsResult(
        val totalCount: Int,
        val evaluatedCount: Int,
        val evaluatedWithPrediction: Int,
        val correctCount: Int,
        val totalCorrectCount: Int,
        val noPredictionCount: Int,
        val accuracy: Double,
        val totalAccuracy: Double,
        val kalipAccuracy: Double,
        val sideAnyAccuracy: Double,
        val methodStats: List<Triple<String, Int, Int>>
    )
}
