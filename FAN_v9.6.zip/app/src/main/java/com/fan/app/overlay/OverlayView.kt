package com.fan.app.overlay

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.cardview.widget.CardView
import com.fan.app.data.PythonBridge
import com.fan.app.data.PythonResult
import com.fan.app.engine.Ensemble
import com.fan.app.engine.PredictionEngine
import com.fan.app.engine.SidePrediction
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.abs

class OverlayView(context: Context) : LinearLayout(context) {

    var onValueEntered: ((Int) -> Unit)? = null
    var onDeletePressed: (() -> Unit)? = null
    var onSettingsRequested: (() -> Unit)? = null

    private val windowManager =
        context.getSystemService(Context.WINDOW_SERVICE) as WindowManager

    private val uiScope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private lateinit var params: WindowManager.LayoutParams
    private var isAddedToWindow = false
    private var isHorizontal = false

    private var buttonSizePct = 100
    private var opacityPct = 30
    private var fadeDelayMs = 4000L
    private var vibrationEnabled = false
    private var runMode = PythonBridge.MODE_KOTLIN

    private var fadeJob: Job? = null
    private var isFaded = false
    private var pyPollJob: Job? = null

    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f
    private var wasDragging = false

    private var lastResult: PredictionEngine.EngineResult? = null
    private var lastPyResult: PythonResult = PythonResult.EMPTY

    // 5 satır: K ana, K kalip, Py ana, K yan, Py yan
    private var tvKM: TextView? = null; private var tvKMC: TextView? = null
    private var tvKK: TextView? = null; private var tvKKC: TextView? = null
    private var tvPM: TextView? = null; private var tvPMC: TextView? = null
    private var tvKY: TextView? = null; private var tvKYC: TextView? = null
    private var tvPY: TextView? = null; private var tvPYC: TextView? = null
    private var tvRecentValues: TextView? = null
    private var btnDel: Button? = null
    private var btn1: Button? = null; private var btn2: Button? = null
    private var btn3: Button? = null; private var btn4: Button? = null

    init {
        orientation = VERTICAL
        buildVerticalLayout()
    }

    fun setRunMode(mode: Int) {
        this.runMode = mode
        // Satırların görünürlüğünü ayarla
        val showK = mode == PythonBridge.MODE_KOTLIN || mode == PythonBridge.MODE_HYBRID
        val showP = mode == PythonBridge.MODE_PYTHON || mode == PythonBridge.MODE_HYBRID
        // Kotlin satırları
        tvKM?.visibility = if (showK) View.VISIBLE else View.GONE
        tvKMC?.visibility = if (showK) View.VISIBLE else View.GONE
        tvKK?.visibility = if (showK) View.VISIBLE else View.GONE
        tvKKC?.visibility = if (showK) View.VISIBLE else View.GONE
        tvKY?.visibility = if (showK) View.VISIBLE else View.GONE
        tvKYC?.visibility = if (showK) View.VISIBLE else View.GONE
        // Python satırları
        tvPM?.visibility = if (showP) View.VISIBLE else View.GONE
        tvPMC?.visibility = if (showP) View.VISIBLE else View.GONE
        tvPY?.visibility = if (showP) View.VISIBLE else View.GONE
        tvPYC?.visibility = if (showP) View.VISIBLE else View.GONE
        restoreLastDisplay()
    }

    fun show() {
        if (isAddedToWindow) return

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = dp(120)
        }

        try {
            windowManager.addView(this, params)
            isAddedToWindow = true
            alpha = 1f
            scheduleFade()
            startPyPolling()
        } catch (_: Exception) {
        }
    }

    fun hide() {
        fadeJob?.cancel()
        pyPollJob?.cancel()
        if (!isAddedToWindow) return
        try { windowManager.removeView(this) } catch (_: Exception) {}
        isAddedToWindow = false
    }

    private fun safeRebuildLayout(horizontal: Boolean) {
        val savedX = if (::params.isInitialized) params.x else 0
        val savedY = if (::params.isInitialized) params.y else dp(120)
        val wasAdded = isAddedToWindow

        if (wasAdded) {
            try { windowManager.removeView(this) } catch (_: Exception) {}
            isAddedToWindow = false
        }

        isHorizontal = horizontal
        if (horizontal) buildHorizontalLayoutInternal()
        else buildVerticalLayoutInternal()

        if (wasAdded && ::params.isInitialized) {
            params.x = savedX
            params.y = savedY
            try {
                windowManager.addView(this, params)
                isAddedToWindow = true
            } catch (_: Exception) {}
        }
    }

    private fun buildVerticalLayout() { buildVerticalLayoutInternal() }

    private fun buildVerticalLayoutInternal() {
        removeAllViews()
        orientation = VERTICAL
        setPadding(dp(8), dp(8), dp(8), dp(8))

        val card = CardView(context).apply {
            radius = dp(14).toFloat()
            setCardBackgroundColor(Color.parseColor("#CC1565C0"))
            cardElevation = dp(8).toFloat()
        }
        val inner = LinearLayout(context).apply {
            orientation = VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        val predictionPanel = LinearLayout(context).apply {
            orientation = VERTICAL
            setPadding(0, 0, 0, dp(4))
        }

        // Satırlar (compact)
        fun addRow(label: String, labelColor: Int, predColor: Int, confColor: Int): Pair<TextView, TextView> {
            val row = LinearLayout(context).apply {
                orientation = HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(1), 0, dp(1))
            }
            val lab = TextView(context).apply {
                text = label; textSize = 10f
                setTextColor(labelColor)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(0, 0, dp(6), 0)
            }
            val pred = TextView(context).apply {
                text = "--"; textSize = 15f
                setTextColor(predColor)
                typeface = Typeface.MONOSPACE
                gravity = Gravity.START or Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f)
            }
            val conf = TextView(context).apply {
                text = "--"; textSize = 10f
                setTextColor(confColor)
                typeface = Typeface.MONOSPACE
                gravity = Gravity.END or Gravity.CENTER_VERTICAL
            }
            row.addView(lab); row.addView(pred); row.addView(conf)
            predictionPanel.addView(row)
            return pred to conf
        }

        val k = addRow("🔵 K", Color.parseColor("#64B5F6"), Color.WHITE, Color.parseColor("#FFB74D"))
        tvKM = k.first; tvKMC = k.second
        val kk = addRow("🎯 Kalıp", Color.parseColor("#FFB74D"), Color.parseColor("#FFE0B2"), Color.parseColor("#FFB74D"))
        tvKK = kk.first; tvKKC = kk.second
        val py = addRow("🐍 Py", Color.parseColor("#81C784"), Color.parseColor("#A5D6A7"), Color.parseColor("#81C784"))
        tvPM = py.first; tvPMC = py.second
        val ky = addRow("🔵 Yan", Color.parseColor("#CE93D8"), Color.parseColor("#E1BEE7"), Color.parseColor("#CE93D8"))
        tvKY = ky.first; tvKYC = ky.second
        val py2 = addRow("🐍 PyYan", Color.parseColor("#81C784"), Color.parseColor("#A5D6A7"), Color.parseColor("#81C784"))
        tvPY = py2.first; tvPYC = py2.second

        tvRecentValues = TextView(context).apply {
            textSize = 9f
            setTextColor(Color.parseColor("#BBDEFB"))
            gravity = Gravity.CENTER
            typeface = Typeface.MONOSPACE
            text = "- - - - - -"
            setPadding(0, dp(4), 0, dp(2))
        }
        predictionPanel.addView(tvRecentValues,
            LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))

        inner.addView(predictionPanel,
            LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))

        btnDel = createButton("DEL", Color.parseColor("#78909C"), 12f)
        btn4 = createButton("4", Color.parseColor("#F44336"), 14f)
        btn3 = createButton("3", Color.parseColor("#FF9800"), 14f)
        btn2 = createButton("2", Color.parseColor("#2196F3"), 14f)
        btn1 = createButton("1", Color.parseColor("#4CAF50"), 14f)

        val btnH = dp(40)
        inner.addView(btnDel, btnParams(btnH))
        inner.addView(btn4, btnParams(btnH))
        inner.addView(btn3, btnParams(btnH))
        inner.addView(btn2, btnParams(btnH))
        inner.addView(btn1, btnParams(btnH))

        card.addView(inner)
        addView(card)

        setupButtonListeners()
        attachDragListener(predictionPanel)
        setRunMode(runMode)
        restoreLastDisplay()
    }

    private fun buildHorizontalLayoutInternal() {
        // Yatay mod da kompakt kalsın: 5 tahmin satırı sol tarafta, butonlar sağda
        removeAllViews()
        orientation = HORIZONTAL
        setPadding(dp(6), dp(6), dp(6), dp(6))

        val card = CardView(context).apply {
            radius = dp(12).toFloat()
            setCardBackgroundColor(Color.parseColor("#CC1565C0"))
            cardElevation = dp(8).toFloat()
        }
        val inner = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        val predPanel = LinearLayout(context).apply {
            orientation = VERTICAL
            setPadding(dp(4), 0, dp(6), 0)
        }
        fun addRowH(label: String, lc:Int, pc:Int, cc:Int): Pair<TextView, TextView> {
            val row = LinearLayout(context).apply {
                orientation = HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            }
            val lab = TextView(context).apply {
                text=label; textSize=8f; setTextColor(lc); typeface=Typeface.DEFAULT_BOLD
                setPadding(0,0,dp(4),0)
            }
            val pred = TextView(context).apply {
                text="--"; textSize=12f; setTextColor(pc); typeface=Typeface.MONOSPACE
                layoutParams=LinearLayout.LayoutParams(0,LayoutParams.WRAP_CONTENT,1f)
            }
            val conf = TextView(context).apply {
                text="--"; textSize=8f; setTextColor(cc); typeface=Typeface.MONOSPACE
            }
            row.addView(lab); row.addView(pred); row.addView(conf); predPanel.addView(row)
            return pred to conf
        }
        val k = addRowH("K", Color.parseColor("#64B5F6"), Color.WHITE, Color.parseColor("#FFB74D"))
        tvKM = k.first; tvKMC = k.second
        val kk = addRowH("KK", Color.parseColor("#FFB74D"), Color.parseColor("#FFE0B2"), Color.parseColor("#FFB74D"))
        tvKK = kk.first; tvKKC = kk.second
        val py = addRowH("Py", Color.parseColor("#81C784"), Color.parseColor("#A5D6A7"), Color.parseColor("#81C784"))
        tvPM = py.first; tvPMC = py.second
        val ky = addRowH("KY", Color.parseColor("#CE93D8"), Color.parseColor("#E1BEE7"), Color.parseColor("#CE93D8"))
        tvKY = ky.first; tvKYC = ky.second
        val py2 = addRowH("PYy", Color.parseColor("#81C784"), Color.parseColor("#A5D6A7"), Color.parseColor("#81C784"))
        tvPY = py2.first; tvPYC = py2.second
        tvRecentValues = TextView(context).apply {
            textSize = 8f; setTextColor(Color.parseColor("#BBDEFB")); gravity=Gravity.CENTER
            typeface=Typeface.MONOSPACE; text="- - - -"; setPadding(0,dp(3),0,0)
        }
        predPanel.addView(tvRecentValues)
        inner.addView(predPanel, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))

        val grp = LinearLayout(context).apply { orientation = HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
        btnDel = createButton("⌫", Color.parseColor("#78909C"), 11f)
        btn4 = createButton("4", Color.parseColor("#F44336"), 12f)
        btn3 = createButton("3", Color.parseColor("#FF9800"), 12f)
        btn2 = createButton("2", Color.parseColor("#2196F3"), 12f)
        btn1 = createButton("1", Color.parseColor("#4CAF50"), 12f)
        val sz = dp(38)
        grp.addView(btnDel, btnParamsH(sz))
        grp.addView(btn4, btnParamsH(sz))
        grp.addView(btn3, btnParamsH(sz))
        grp.addView(btn2, btnParamsH(sz))
        grp.addView(btn1, btnParamsH(sz))
        inner.addView(grp)
        card.addView(inner); addView(card)
        setupButtonListeners()
        attachDragListener(predPanel)
        setRunMode(runMode)
        restoreLastDisplay()
    }

    private fun createButton(label: String, color: Int, size: Float): Button {
        return Button(context).apply {
            text = label; setTextColor(Color.WHITE); textSize = size
            setBackgroundColor(color); stateListAnimator = null; isAllCaps = false
            minHeight = 0; minimumHeight = 0; setPadding(0, 0, 0, 0)
        }
    }

    private fun btnParams(h: Int): LayoutParams {
        val size = ((h * buttonSizePct) / 100f).toInt()
        return LayoutParams(LayoutParams.MATCH_PARENT, size).apply { setMargins(0, dp(2), 0, dp(2)) }
    }
    private fun btnParamsH(sizePx: Int): LayoutParams {
        val size = ((sizePx * buttonSizePct) / 100f).toInt()
        return LayoutParams(size, size).apply { setMargins(dp(2), 0, dp(2), 0) }
    }

    private fun setupButtonListeners() {
        btn1?.setOnClickListener { vibrate(); resetFade(); onValueEntered?.invoke(1) }
        btn2?.setOnClickListener { vibrate(); resetFade(); onValueEntered?.invoke(2) }
        btn3?.setOnClickListener { vibrate(); resetFade(); onValueEntered?.invoke(3) }
        btn4?.setOnClickListener { vibrate(); resetFade(); onValueEntered?.invoke(4) }
        btnDel?.setOnClickListener { vibrate(); resetFade(); onDeletePressed?.invoke() }
    }

    // Python log polling (v8.2: daha sık)
    private fun startPyPolling() {
        pyPollJob?.cancel()
        pyPollJob = uiScope.launch {
            while (isActive && isAddedToWindow) {
                try {
                    val py = PythonBridge.readLastPythonResult()
                    if (py.timestamp != lastPyResult.timestamp) {
                        lastPyResult = py
                        updateDisplay(lastResult)
                    }
                } catch (_: Exception) {}
                delay(1200)
            }
        }
    }

    fun updateDisplay(result: PredictionEngine.EngineResult?) {
        lastResult = result
        val ens = result?.ensembleResult

        // Kotlin satırları
        if (ens == null) {
            tvKM?.text = "--"; tvKMC?.text = "--"
            tvKK?.text = "--"; tvKKC?.text = "--"
            tvKY?.text = "--"; tvKYC?.text = "--"
        } else {
            val mText: String; val mColor: Int
            when (ens.tier) {
                "SINGLE" -> { mText = "${ens.finalPrediction}"; mColor = Color.parseColor("#4CAF50") }
                else -> {
                    mText = if (ens.secondPrediction != null) "${ens.finalPrediction}/${ens.secondPrediction}"
                            else "${ens.finalPrediction}"
                    mColor = Color.WHITE
                }
            }
            tvKM?.text = mText; tvKM?.setTextColor(mColor)
            tvKMC?.text = "%${(ens.confidence*100).toInt()}"

            val kT = if (ens.kalipSecondary != null && ens.kalipSecondary > 0)
                "${ens.kalipPrediction}/${ens.kalipSecondary}" else "${ens.kalipPrediction}"
            val kConf = ens.methodVotes.firstOrNull { it.methodIndex == 0 }?.confidence
                ?: ens.kalipPrediction.let { 0.25 }
            tvKK?.text = kT; tvKKC?.text = "%${(kConf*100).toInt()}"

            val sideStr = ens.sideFormatted.ifBlank {
                val sbL = if (ens.sidePrediction.smallBigPrediction == SidePrediction.SmallBig.BIG) "B" else "K"
                val oeL = if (ens.sidePrediction.oddEvenPrediction == SidePrediction.OddEven.ODD) "T" else "C"
                "$oeL•$sbL"
            }
            tvKY?.text = sideStr
            val sideC = when {
                sideStr.contains("=") -> Color.parseColor("#4CAF50")
                else -> Color.parseColor("#CE93D8")
            }
            tvKY?.setTextColor(sideC)
            val sideAvg = (ens.sidePrediction.smallBigConfidence + ens.sidePrediction.oddEvenConfidence)/2.0
            tvKYC?.text = "%${(sideAvg*100).toInt()}"
        }

        // Python satırları
        val py = lastPyResult
        if (!py.hasPrediction) {
            tvPM?.text = "--"; tvPMC?.text = "--"
            tvPY?.text = "--"; tvPYC?.text = "--"
        } else {
            val pText = if (py.secondary != null) "${py.primary}/${py.secondary}" else "${py.primary}"
            tvPM?.text = pText; tvPM?.setTextColor(Color.parseColor("#A5D6A7"))
            tvPMC?.text = "%${(py.confidence*100).toInt()}"
            val pySide = py.sideFormatted.ifBlank { "--" }
            tvPY?.text = pySide
            val pySideColor = if (pySide.contains("=")) Color.parseColor("#4CAF50") else Color.parseColor("#81C784")
            tvPY?.setTextColor(pySideColor)
            tvPYC?.text = "%${(py.sideConfidence*100).toInt()}"
        }

        // Son değerler
        tvRecentValues?.text =
            if (result == null || result.recentValues.isEmpty()) "- - - - - -"
            else result.recentValues.joinToString(" ")
    }

    private fun restoreLastDisplay() { lastResult?.let { updateDisplay(it) } }

    private fun attachDragListener(target: View) {
        target.setOnTouchListener { v, event ->
            if (!::params.isInitialized || !isAddedToWindow) return@setOnTouchListener false
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x; initialY = params.y
                    initialTouchX = event.rawX; initialTouchY = event.rawY
                    wasDragging = false; resetFade(); true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()
                    if (abs(dx) > dp(4) || abs(dy) > dp(4)) wasDragging = true
                    if (wasDragging) {
                        params.x = (initialX + dx).coerceAtLeast(0)
                        params.y = (initialY + dy).coerceAtLeast(0)
                        updateWindowLayoutSafely()
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (wasDragging) {
                        val deltaY = event.rawY - initialTouchY
                        handleRelease(deltaY)
                    } else v.performClick()
                    scheduleFade(); true
                }
                else -> false
            }
        }
    }

    private fun handleRelease(deltaY: Float) {
        if (deltaY < -dp(40)) {
            if (!isHorizontal) safeRebuildLayout(horizontal = true)
            post { snapToTop() }; return
        }
        if (isHorizontal) safeRebuildLayout(horizontal = false)
        post { snapLeftOrRight() }
    }
    private fun snapToTop() {
        if (!isAddedToWindow || !::params.isInitialized) return
        params.x = 0; params.y = 0; updateWindowLayoutSafely()
    }
    private fun snapLeftOrRight() {
        if (!isAddedToWindow || !::params.isInitialized) return
        val screenWidth = resources.displayMetrics.widthPixels
        val viewWidth = (width.takeIf { it > 0 } ?: measuredWidth).coerceAtLeast(1)
        params.x = if (params.x + viewWidth/2 < screenWidth/2) 0
        else (screenWidth - viewWidth).coerceAtLeast(0)
        updateWindowLayoutSafely()
    }
    private fun updateWindowLayoutSafely() {
        if (!isAddedToWindow || !::params.isInitialized) return
        try { windowManager.updateViewLayout(this, params) } catch (_: Exception) {}
    }

    private fun scheduleFade() {
        fadeJob?.cancel()
        if (!isAddedToWindow || fadeDelayMs <= 0L) return
        fadeJob = uiScope.launch {
            delay(fadeDelayMs)
            if (!isAddedToWindow) return@launch
            animate().alpha(opacityPct/100f).setDuration(500).start()
            isFaded = true
        }
    }
    private fun resetFade() {
        fadeJob?.cancel()
        if (!isAddedToWindow) return
        animate().alpha(1f).setDuration(200).start()
        isFaded = false; scheduleFade()
    }

    fun setButtonSize(pct: Int) {
        buttonSizePct = pct.coerceIn(60, 180)
        if (isAddedToWindow) safeRebuildLayout(isHorizontal)
    }
    fun setOpacity(pct: Int) {
        opacityPct = pct.coerceIn(10, 100)
        if (isFaded) alpha = opacityPct/100f
    }
    fun setFadeDelay(ms: Long) { fadeDelayMs = ms.coerceAtLeast(0L); resetFade() }
    fun setVibrationEnabled(enabled: Boolean) { vibrationEnabled = enabled }

    private fun vibrate() {
        if (!vibrationEnabled) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                vm.defaultVibrator.vibrate(VibrationEffect.createOneShot(30, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                val v = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                v.vibrate(VibrationEffect.createOneShot(30, VibrationEffect.DEFAULT_AMPLITUDE))
            }
        } catch (_: Exception) {}
    }
    private fun Int.dpToPx(): Int = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, toFloat(), context.resources.displayMetrics).toInt()
    private fun dp(value: Int): Int = value.dpToPx()
}
