package com.fan.app.engine

import kotlin.math.pow

class MarkovPredictor {

    // Cached transition tables
    private val trans1 = mutableMapOf<Pair<Int,Int>, Double>()
    private val trans2 = mutableMapOf<Triple<Int,Int,Int>, Double>()
    private val priorCounts = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)
    private var trainedSize = 0
    private val decay = 0.995

    fun compute(data: List<Int>): Map<Int, Double> {
        if (data.size < 3) return equal()
        val last = data.last()
        val prev = data.getOrNull(data.size - 2)

        // Incremental training
        trainIncremental(data)

        val p1 = probs1(last)
        if (prev != null && data.size >= 5) {
            val p2 = probs2(prev, last)
            if (p2 != null) {
                // Adaptive weight: use more 2nd-order when we have enough data for that context
                val support2 = (1..4).sumOf { trans2[Triple(prev, last, it)] ?: 0.0 }
                val w2 = (support2 / (support2 + 3.0)).coerceIn(0.25, 0.65)
                val merged = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)
                for (k in 1..4) merged[k] = (p1[k] ?: 0.25) * (1 - w2) + (p2[k] ?: 0.25) * w2
                return normalize(merged)
            }
        }
        return p1
    }

    private fun trainIncremental(data: List<Int>) {
        val start1 = maxOf(1, trainedSize)
        if (start1 < data.size) {
            // Global decay
            for (k in trans1.keys) trans1[k] = (trans1[k]!!) * decay
            for (k in trans2.keys) trans2[k] = (trans2[k]!!) * decay
            for (k in priorCounts.keys) priorCounts[k] = (priorCounts[k]!!) * decay

            for (i in start1 until data.size - 1) {
                val from = data[i]
                val to = data[i + 1]
                trans1[Pair(from, to)] = (trans1[Pair(from, to)] ?: 0.0) + 1.0
                priorCounts[to] = (priorCounts[to] ?: 0.0) + 1.0

                if (i >= 2) {
                    val prev2 = data[i - 1]
                    trans2[Triple(prev2, from, to)] = (trans2[Triple(prev2, from, to)] ?: 0.0) + 1.0
                }
            }
            trainedSize = data.size - 1
        }
    }

    private fun probs1(from: Int): Map<Int, Double> {
        val p = mutableMapOf(1 to 0.3, 2 to 0.3, 3 to 0.3, 4 to 0.3)
        var total = 1.2
        for (k in 1..4) {
            val c = trans1[Pair(from, k)] ?: 0.0
            p[k] = (p[k] ?: 0.3) + c
            total += c
        }
        return p.mapValues { it.value / total }
    }

    private fun probs2(prev: Int, last: Int): Map<Int, Double>? {
        val p = mutableMapOf(1 to 0.15, 2 to 0.15, 3 to 0.15, 4 to 0.15)
        var total = 0.6
        for (k in 1..4) {
            val w = trans2[Triple(prev, last, k)] ?: 0.0
            p[k] = (p[k] ?: 0.15) + w
            total += w
        }
        if (total < 1.5) return null // insufficient data
        return p.mapValues { it.value / total }
    }

    private fun normalize(m: Map<Int, Double>): Map<Int, Double> {
        val total = m.values.sum()
        if (total == 0.0) return equal()
        return m.mapValues { it.value / total }
    }

    fun reset() {
        trans1.clear()
        trans2.clear()
        priorCounts.clear()
        priorCounts.putAll(mapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0))
        trainedSize = 0
    }

    private fun equal() = mapOf(1 to 0.25, 2 to 0.25, 3 to 0.25, 4 to 0.25)
}
