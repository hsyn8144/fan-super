package com.fan.app.engine

import com.fan.app.data.DataEntry
import kotlin.math.pow

object Ensemble {

    // SINGLETON learners — instantiated ONCE, not per call (critical fix!)
    private val ogd = OnlineGradientDescent()
    private val bayesian = BayesianUpdater()
    private val qLearning = QLearningEngine()
    private val transformer = MiniTransformer()
    private val markov = MarkovPredictor()
    private val metaLearner = MetaLearner()

    // ── Tier constants (v7.2) ────────────────────────────────────────
    // Filtre tamamen KALDIRILDI: her zaman tahmin verilir ("--" / NONE yok).
    // <0.65 → DOUBLE (çiftli tahmin: pri/sec)
    // ≥0.65 → SINGLE (tekil, emin)
    const val TIER_NO_PRED = 0.0     // artık kullanılmıyor (geriye dönük uyumluluk)
    const val TIER_STRONG   = 0.65   // ≥0.65 → SINGLE (emin)

    // ── Online confidence calibration (Platt-style, rolling) ─────────
    private var calibTotal = 0
    private var calibCorrect = 0
    private var calibWindow = ArrayDeque<Boolean>()
    private const val CALIB_WINDOW = 40

    data class MethodVote(
        val methodIndex: Int,
        val methodName: String,
        val votes: Map<Int, Double>,
        val topPrediction: Int,
        val secondPrediction: Int?,
        val confidence: Double,
        val isActive: Boolean = true,
        val activityLevel: Double = 1.0,
        val regimeWeight: Double = 1.0
    )

    data class EnsembleResult(
        val finalPrediction: Int,
        val secondPrediction: Int?,
        val confidence: Double,
        val showDouble: Boolean,
        val tier: String,          // v7.2: "DOUBLE" / "SINGLE" — NONE kaldırıldı
        val methodVotes: List<MethodVote>,
        val totalVotes: Map<Int, Double>,
        val sidePrediction: SidePrediction.SidePredictionResult,
        val sideFormatted: String,
        val kalipPrediction: Int,
        val kalipSecondary: Int?,
        val kalipShowDouble: Boolean,
        val currentRegime: String,
        val detectedPattern: String,
        val regimeSequence: String,
        val anomalyInfo: AnomalyDetector.AnomalyResult?,
        val multiScaleInfo: MultiHorizonEnsemble.MultiScaleResult?,
        val metaConfidence: Double
    )

    data class WeightedContext(
        val regime: RegimeDetector.RegimeType,
        val microRegime: RegimeDetector.MicroRegimeType,
        val regimeGroup: String,
        val pattern: RegimeDetector.PatternInfo,
        val streak: Pair<Int, Int>,
        val gatingResults: List<ContextualGating.GatingResult>,
        val recentPerformance: List<Pair<Int, Boolean>>
    )

    fun compute(data: List<Int>, pastEntries: List<DataEntry> = emptyList()): EnsembleResult {
        val eq = equal()
        if (data.size < 2) {
            val side = SidePrediction.analyze(data)
            return EnsembleResult(
                finalPrediction = 1, secondPrediction = 2, confidence = 0.25,
                showDouble = true, tier = "DOUBLE",
                methodVotes = emptyList(), totalVotes = eq,
                sidePrediction = side, sideFormatted = SidePrediction.formatSidePrediction(side),
                kalipPrediction = 1, kalipSecondary = 2, kalipShowDouble = true,
                currentRegime = "KAOS", detectedPattern = "NONE", regimeSequence = "",
                anomalyInfo = null, multiScaleInfo = null, metaConfidence = 0.25
            )
        }

        return try {
            computeSafely(data, pastEntries, eq)
        } catch (e: Exception) {
            // Herhangi bir yöntem crash verirse güvenli varsayıma dön
            val side = SidePrediction.analyze(data)
            EnsembleResult(
                finalPrediction = 1, secondPrediction = 2, confidence = 0.25,
                showDouble = true, tier = "DOUBLE",
                methodVotes = emptyList(), totalVotes = eq,
                sidePrediction = side, sideFormatted = SidePrediction.formatSidePrediction(side),
                kalipPrediction = 1, kalipSecondary = 2, kalipShowDouble = true,
                currentRegime = "KAOS", detectedPattern = "NONE", regimeSequence = "",
                anomalyInfo = null, multiScaleInfo = null, metaConfidence = 0.25
            )
        }
    }

    private fun computeSafely(data: List<Int>, pastEntries: List<DataEntry>, eq: Map<Int, Double>): EnsembleResult {
        val regimeAnalysis = RegimeDetector.analyze(data)
        val patternInfo    = RegimeDetector.detectPattern(data)
        val streak         = RegimeDetector.getCurrentStreak(data)
        val recentPerf     = extractRecentPerformance(pastEntries)
        val regimeGroup    = regimeAnalysis.currentRegimeType.group

        val gatingContext = ContextualGating.GatingContext(
            data = data,
            regime = regimeAnalysis.currentRegime,
            regimeSubType = regimeAnalysis.subType,
            pattern = patternInfo,
            streak = streak,
            recentPerformance = recentPerf
        )
        val gatingResults = ContextualGating.evaluateAllMethods(gatingContext)
        val finalGating   = ContextualGating.applyEmergencyActivation(gatingResults)

        val methodVotes = computeMethodVotes(data, finalGating, pastEntries)

        val weightedContext = WeightedContext(
            regime = regimeAnalysis.currentRegime,
            microRegime = regimeAnalysis.currentRegimeType,
            regimeGroup = regimeGroup,
            pattern = patternInfo,
            streak = streak,
            gatingResults = finalGating,
            recentPerformance = recentPerf
        )

        val weightedVotes = applyRegimeBasedWeighting(methodVotes, weightedContext)
        val totalVotes    = aggregateVotes(weightedVotes)

        val multiScale = if (data.size >= 25) MultiHorizonEnsemble.compute(data, pastEntries) else null
        val anomaly    = AnomalyDetector.detect(data, pastEntries.map { it.value })
        val rawRes     = resolveFinalPrediction(totalVotes, multiScale, anomaly)

        // ── Confidence calibration (v7.2: filtre kaldırıldı, tek/çift ayrım 0.65) ──
        val metaConf = calculateMetaConfidence(methodVotes, weightedVotes, weightedContext, anomaly)
        val calibFactor = if (calibTotal >= 8) {
            // Son sonuçlardaki isabet oranı, ama çok cezbetme (0.40 taban)
            0.40 + calibCorrect.toDouble() / calibTotal.coerceAtLeast(1) * 0.30
        } else 0.55  // warmup: çiftli bölge civarı
        // Raw conf en büyük ağırlık; meta ve calib ince ayar
        var calibratedConf = rawRes.confidence * 0.65 + metaConf * 0.22 + calibFactor * 0.13
        calibratedConf = calibratedConf.coerceIn(0.15, 0.93)

        // ── Apply tier rules (v7.2: filtre YOK, her zaman tahmin) ────────────
        val (tier, finalShowDouble, finalSecond) = when {
            calibratedConf >= TIER_STRONG -> Triple("SINGLE", false, null)
            else -> {
                val sec = rawRes.secondPrediction ?: run {
                    val s = totalVotes.entries.sortedByDescending { it.value }
                    if (s.size >= 2 && s[0].key != s[1].key) s[1].key else {
                        (1..4).firstOrNull { it != rawRes.finalPrediction } ?: 2
                    }
                }
                Triple("DOUBLE", true, sec)
            }
        }

        val side    = SidePrediction.analyze(data, regimeGroup)
        val sideStr = SidePrediction.formatSidePrediction(side)

        // Kalıp her zaman çiftli!
        val kalip = computeKalipDouble(methodVotes)

        return EnsembleResult(
            finalPrediction   = rawRes.finalPrediction,
            secondPrediction  = finalSecond,
            confidence        = calibratedConf,
            showDouble        = finalShowDouble,
            tier              = tier,
            methodVotes       = methodVotes,
            totalVotes        = totalVotes,
            sidePrediction    = side,
            sideFormatted     = sideStr,
            kalipPrediction   = kalip.first,
            kalipSecondary    = kalip.second,
            kalipShowDouble   = true,
            currentRegime     = "${regimeAnalysis.currentRegimeType.name}_${regimeAnalysis.subType}",
            detectedPattern   = "${patternInfo.type}_${patternInfo.length}",
            regimeSequence    = regimeAnalysis.regimeSequence.toDisplayString(),
            anomalyInfo       = anomaly,
            multiScaleInfo    = multiScale,
            metaConfidence    = metaConf
        )
    }

    /** Register outcome for confidence calibration (called by PredictionEngine). */
    fun recordCalibrationOutcome(correct: Boolean) {
        calibWindow.addLast(correct)
        calibCorrect += if (correct) 1 else 0
        calibTotal++
        while (calibWindow.size > CALIB_WINDOW) {
            val removed = calibWindow.removeFirst()
            calibCorrect -= if (removed) 1 else 0
            calibTotal--
        }
    }

    fun reset() {
        ogd.reset()
        bayesian.reset()
        qLearning.reset()
        transformer.reset()
        markov.reset()
        metaLearner.reset()
        SidePrediction.reset()
        MethodWeightTracker.reset()
        calibWindow.clear()
        calibTotal = 0; calibCorrect = 0
    }

    /** Kalıp (method 0) — HER ZAMAN çiftli sonuç verir. */
    private fun computeKalipDouble(methodVotes: List<MethodVote>): Pair<Int, Int?> {
        val mv = methodVotes.find { it.methodIndex == 0 } ?: return Pair(1, 2)
        val sorted = mv.votes.entries.sortedByDescending { it.value }
        val pri = sorted[0].key
        val sec = sorted.getOrNull(1)?.key ?: ((1..4).firstOrNull { it != pri } ?: 2)
        return Pair(pri, sec)
    }

    private fun applyRegimeBasedWeighting(
        votes: List<MethodVote>,
        context: WeightedContext
    ): List<Pair<MethodVote, Double>> {
        val regimeMethods = DataEntry.METHOD_GROUP_FIT
            .filter { context.regimeGroup in it.value }.keys.toList()

        val groups = listOf(
            listOf(0, 3, 5),       // pattern-based
            listOf(1, 2, 4),       // regime/statistical
            listOf(7, 11),         // neural/online
            listOf(8, 12),         // probabilistic
            listOf(9, 10)          // RL/meta
        )

        val methodPriors = mapOf(
            0 to 0.9,   // Kalip_Arama
            1 to 0.6,   // Rejim_Tespiti
            2 to 0.6,   // Fark_Dizisi
            3 to 0.6,   // Ayna_Kalip
            4 to 0.6,   // Kume_Kaymasi
            5 to 0.9,   // Beklenti_Sapma
            6 to 0.15,  // Dalga_Tekrar
            7 to 1.2,   // Online_Gradient
            8 to 1.4,   // Bayesian
            9 to 0.6,   // Meta_Learner
            10 to 0.5,  // Q_Learning
            11 to 0.7,  // Mini_Transformer
            12 to 1.3   // Markov
        )

        val groupBonus = 1.0 / groups.size
        val patternBonus = if (context.pattern.type != "NONE" && context.pattern.strength > 0.3)
            0.2 * context.pattern.strength else 0.0
        val patternMethods = listOf(0, 3)

        return votes.map { vote ->
            val inGroup = vote.methodIndex in regimeMethods
            var weight = (methodPriors[vote.methodIndex] ?: 0.5)
            if (inGroup) weight *= 1.15

            if (vote.methodIndex in patternMethods && context.pattern.strength > 0.3)
                weight += patternBonus / patternMethods.size

            val gating = context.gatingResults.find { it.methodIndex == vote.methodIndex }
            weight *= (gating?.activityLevel ?: 0.5)

            val recent = context.recentPerformance
                .filter { it.first == vote.methodIndex }.takeLast(30)
            val nRec = recent.size
            if (nRec >= 4) {
                val wSum = recent.indices.sumOf { (it + 1).toDouble() }
                val wCorrect = recent.indices.sumOf { i ->
                    if (recent[i].second) (i + 1).toDouble() else 0.0
                }
                val acc = wCorrect / wSum
                val perfWeight = when {
                    acc >= 0.48 -> 0.5 + 2.5 * ((acc - 0.48) / 0.25).coerceIn(0.0, 1.0)
                    acc >= 0.35 -> 0.25 + (acc - 0.35) * (0.9 / 0.13)
                    acc >= 0.25 -> 0.10 + (acc - 0.25) * (0.5 / 0.10)
                    else -> 0.03 + acc * 0.25
                }
                val confidence = (nRec / 20.0).coerceIn(0.2, 1.0)
                weight *= perfWeight * confidence + (1 - confidence) * (methodPriors[vote.methodIndex] ?: 0.5)
            } else {
                weight *= 0.8
            }

            weight *= MethodWeightTracker.getMultiplier(vote.methodIndex)

            if (context.streak.second > 3 && vote.methodIndex in listOf(7, 12)) weight *= 1.15
            else if (context.streak.second <= 2 && vote.methodIndex in listOf(0, 3, 5)) weight *= 1.10

            val anomalySev = context.gatingResults.firstOrNull()?.let { 0.0 } ?: 0.0
            if (anomalySev > 0.5 && vote.methodIndex in listOf(8, 12, 7)) weight *= 1.15

            Pair(vote.copy(regimeWeight = weight), weight * vote.activityLevel)
        }
    }

    private fun aggregateVotes(weighted: List<Pair<MethodVote, Double>>): Map<Int, Double> {
        val total = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)
        for ((vote, weight) in weighted) {
            if (weight <= 0.0) continue
            val sorted = vote.votes.entries.sortedByDescending { it.value }
            val top    = sorted.getOrNull(0)
            val second = sorted.getOrNull(1)

            // v2.4.1: keskinlik — sadece çok zayıflar (<0.50) orantılı bölünsün,
            // diğer tüm yöntemler tüm ağırlığı en iyi tahmine versin.
            if (top != null && second != null && top.value < 0.50) {
                val sum = top.value + second.value
                val ratio = top.value / sum
                total[top.key]    = (total[top.key]    ?: 0.0) + weight * ratio
                total[second.key] = (total[second.key] ?: 0.0) + weight * (1 - ratio)
                val third = sorted.getOrNull(2)
                if (third != null && top.value < 0.36) {
                    total[third.key] = (total[third.key] ?: 0.0) + weight * 0.08
                }
            } else if (top != null) {
                total[top.key] = (total[top.key] ?: 0.0) + weight
            }
        }
        val sum = total.values.sum()
        return if (sum > 0) total.mapValues { it.value / sum } else equal()
    }

    private fun computeMethodVotes(
        data: List<Int>,
        gating: List<ContextualGating.GatingResult>,
        pastEntries: List<DataEntry>
    ): List<MethodVote> {
        val votes      = mutableListOf<MethodVote>()
        val patterns   = PatternMatcher.findPatterns(data)
        val patResult  = PatternMatcher.analyzePatternVotes(data, patterns)
        val behavVotes = PatternMatcher.behaviorAnalysis(data, patterns)
        fun g(i: Int)  = gating.getOrElse(i) { ContextualGating.GatingResult(i, true, 1.0, "") }

        votes.add(buildMV(0, mergeVoteMaps(listOf(patResult.votes to 0.65, behavVotes to 0.35)), g(0)))
        votes.add(buildMV(1, RegimeDetector.analyze(data).votes, g(1)))
        votes.add(buildMV(2, PatternMatcher.findDeltaPatternVotes(data), g(2)))
        votes.add(buildMV(3, PatternMatcher.findMirrorPatternVotes(data), g(3)))
        votes.add(buildMV(4, computeClusterShiftVotes(data, patterns), g(4)))
        votes.add(buildMV(5, computeExpectationDriftVotes(data, patterns), g(5)))
        votes.add(buildMV(6, computeWaveRepeatVotes(data), g(6)))
        votes.add(buildMV(7, ogd.compute(data), g(7)))
        votes.add(buildMV(8, bayesian.compute(data), g(8)))
        votes.add(buildMV(9, metaLearner.compute(data, votes.toList(), pastEntries), g(9)))
        votes.add(buildMV(10, qLearning.compute(data), g(10)))
        votes.add(buildMV(11, transformer.compute(data), g(11)))
        votes.add(buildMV(12, markov.compute(data), g(12)))
        return votes
    }

    private fun buildMV(index: Int, votes: Map<Int, Double>, gating: ContextualGating.GatingResult): MethodVote {
        val sorted = votes.entries.sortedByDescending { it.value }
        return MethodVote(
            methodIndex      = index,
            methodName       = DataEntry.METHOD_NAMES[index],
            votes            = votes,
            topPrediction    = sorted[0].key,
            secondPrediction = sorted.getOrNull(1)?.key,
            confidence       = sorted[0].value,
            isActive         = gating.isActive,
            activityLevel    = gating.activityLevel
        )
    }

    private fun extractRecentPerformance(pastEntries: List<DataEntry>): List<Pair<Int, Boolean>> =
        pastEntries.takeLast(50).flatMap { entry ->
            (0 until DataEntry.METHOD_COUNT).mapNotNull { idx ->
                if (!getMethodActive(entry, idx)) null
                else Pair(idx, getMethodCorrect(entry, idx))
            }
        }

    private fun getMethodCorrect(e: DataEntry, i: Int): Boolean = when (i) {
        0->e.method1Correct;  1->e.method2Correct;  2->e.method3Correct;  3->e.method4Correct
        4->e.method5Correct;  5->e.method6Correct;  6->e.method7Correct;  7->e.method8Correct
        8->e.method9Correct;  9->e.method10Correct; 10->e.method11Correct;11->e.method12Correct
        12->e.method13Correct; else->false
    }

    private fun getMethodActive(e: DataEntry, i: Int): Boolean = when (i) {
        0->e.method1Active;  1->e.method2Active;  2->e.method3Active;  3->e.method4Active
        4->e.method5Active;  5->e.method6Active;  6->e.method7Active;  7->e.method8Active
        8->e.method9Active;  9->e.method10Active; 10->e.method11Active;11->e.method12Active
        12->e.method13Active; else->true
    }

    private fun resolveFinalPrediction(
        votes: Map<Int, Double>,
        multiScale: MultiHorizonEnsemble.MultiScaleResult?,
        anomaly: AnomalyDetector.AnomalyResult?
    ): FinalResolution {
        var confidence = votes.values.maxOrNull() ?: 0.25
        // v2.4.1: showDouble threshold düşürüldü; zaten tier sistemi karar veriyor,
        // burada sadece second prediction'ın makul bir aday olmasını sağlıyoruz.
        var showDouble = confidence < 0.50
        if (anomaly != null) {
            confidence *= anomaly.confidenceAdjustment
            showDouble  = showDouble || anomaly.shouldShowDouble
        }
        val sorted = votes.entries.sortedByDescending { it.value }
        var top    = sorted[0].key
        var second = sorted.getOrNull(1)?.key
        val margin = confidence - (sorted.getOrNull(1)?.value ?: 0.0)
        if (margin < 0.08) showDouble = true

        if (multiScale != null && multiScale.horizonBreakdown.isNotEmpty()) {
            if (multiScale.consensusType == "CONFLICT_RESOLVED" || multiScale.regimeTransitionWarning) {
                val msTop = multiScale.finalPrediction
                val msSecond = multiScale.secondPrediction
                val msConf = multiScale.confidence
                val blended = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)
                for ((k, v) in votes) blended[k] = (blended[k] ?: 0.0) + v * 0.6
                blended[msTop] = (blended[msTop] ?: 0.0) + msConf * 0.4
                if (msSecond != null) blended[msSecond] = (blended[msSecond] ?: 0.0) + msConf * 0.2
                val bSum = blended.values.sum()
                val bNorm = blended.mapValues { it.value / bSum }
                val bSorted = bNorm.entries.sortedByDescending { it.value }
                top = bSorted[0].key
                second = bSorted.getOrNull(1)?.key
                confidence = bSorted[0].value
                showDouble = confidence < 0.50 || (bSorted[0].value - (bSorted.getOrNull(1)?.value ?: 0.0)) < 0.10
                if (anomaly != null) {
                    confidence *= anomaly.confidenceAdjustment
                    showDouble = showDouble || anomaly.shouldShowDouble
                }
            }
        }
        return FinalResolution(top, second, confidence, showDouble)
    }

    private fun calculateMetaConfidence(
        votes: List<MethodVote>,
        weighted: List<Pair<MethodVote, Double>>,
        context: WeightedContext,
        anomaly: AnomalyDetector.AnomalyResult?
    ): Double {
        val active = votes.filter { it.isActive }
        val agreement = if (active.size < 2) 0.5
        else {
            val totalW = weighted.filter { it.first.isActive }.sumOf { it.second }
            if (totalW <= 0) 0.5
            else {
                val perVote = mutableMapOf<Int, Double>()
                for ((mv, w) in weighted) {
                    if (!mv.isActive) continue
                    perVote[mv.topPrediction] = (perVote[mv.topPrediction] ?: 0.0) + w
                }
                (perVote.values.maxOrNull() ?: 0.0) / totalW
            }
        }
        val groupAgreement = computeCorrelationPenalty(active)
        val base = 0.25 + 0.65 * agreement - 0.1 * groupAgreement
        val actBonus = when {
            active.size >= 10 -> 0.05
            active.size >= 7 -> 0.0
            active.size >= 4 -> -0.08
            else -> -0.18
        }
        val anomPen = anomaly?.overallSeverity?.times(-0.25) ?: 0.0
        val entropyPen = computeVoteEntropyPenalty(weighted)
        return minOf(maxOf(base + actBonus + anomPen - entropyPen * 0.1, 0.1), 0.95)
    }

    private fun computeCorrelationPenalty(active: List<MethodVote>): Double {
        val groups = listOf(
            listOf(0, 3, 5), listOf(1, 2, 4, 6), listOf(7, 11), listOf(8, 12), listOf(9, 10)
        )
        var penalty = 0.0
        for (g in groups) {
            val activeInGroup = active.filter { it.methodIndex in g }
            if (activeInGroup.size >= 2) {
                val preds = activeInGroup.map { it.topPrediction }.distinct().size
                if (preds == 1) penalty += 0.15
            }
        }
        return penalty.coerceAtMost(0.4)
    }

    private fun computeVoteEntropyPenalty(weighted: List<Pair<MethodVote, Double>>): Double {
        val total = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)
        for ((mv, w) in weighted) {
            if (!mv.isActive) continue
            total[mv.topPrediction] = (total[mv.topPrediction] ?: 0.0) + w
        }
        val s = total.values.sum().coerceAtLeast(1e-9)
        var entropy = 0.0
        for (v in total.values) {
            val p = v / s
            if (p > 0) entropy -= p * kotlin.math.ln(p) / kotlin.math.ln(4.0)
        }
        return entropy
    }

    private fun computeClusterShiftVotes(data: List<Int>, patterns: List<PatternMatcher.PatternMatch>): Map<Int, Double> {
        val rd = computeDensity(data.takeLast(250))
        val pd = if (patterns.isNotEmpty()) computePatternDensity(data, patterns.maxByOrNull { it.patternLength }!!) else equal()
        val v  = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)
        for (k in 1..4) v[k] = (rd[k] ?: 0.25) * 0.75 + (pd[k] ?: 0.25) * 0.25
        return normalizeVotes(v)
    }

    private fun computeDensity(data: List<Int>): Map<Int, Double> {
        if (data.isEmpty()) return equal()
        val f = mutableMapOf(1 to 0, 2 to 0, 3 to 0, 4 to 0)
        data.forEach { if (it in 1..4) f[it] = (f[it] ?: 0) + 1 }
        val rw = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)
        for ((i, v) in data.withIndex()) {
            if (v in 1..4) rw[v] = (rw[v] ?: 0.0) + PatternMatcher.recencyFactor(data.size - 1 - i, data.size)
        }
        val tot = rw.values.sum()
        return if (tot > 0) rw.mapValues { it.value / tot } else f.mapValues { it.value / data.size.toDouble() }
    }

    private fun computePatternDensity(data: List<Int>, pattern: PatternMatcher.PatternMatch): Map<Int, Double> {
        val v = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)
        for (pos in pattern.matchPositions) {
            val ap = pos + pattern.patternLength
            if (ap < data.size - pattern.patternLength) {
                val nv = data[ap]; if (nv in 1..4) v[nv] = (v[nv] ?: 0.0) + 1.0
            }
        }
        return normalizeVotes(v)
    }

    private fun computeExpectationDriftVotes(data: List<Int>, patterns: List<PatternMatcher.PatternMatch>): Map<Int, Double> {
        if (patterns.isEmpty() || data.size < 10) return equal()
        val v = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)
        for (pattern in patterns) {
            if (pattern.matchPositions.isEmpty()) continue
            val ac = mutableMapOf(1 to 0, 2 to 0, 3 to 0, 4 to 0)
            for (pos in pattern.matchPositions) {
                val ap = pos + pattern.patternLength
                if (ap < data.size - pattern.patternLength) {
                    val nv = data[ap]; if (nv in 1..4) ac[nv] = (ac[nv] ?: 0) + 1
                }
            }
            val total = ac.values.sum().toDouble(); if (total == 0.0) continue
            val pw = pattern.patternLength.toDouble() / 10.0
            for ((k, count) in ac) {
                val rec = PatternMatcher.recencyFactor(data.size - pattern.matchPositions.last(), data.size)
                v[k] = (v[k] ?: 0.0) + (count / total) * pw * rec
            }
        }
        return normalizeVotes(v)
    }

    private fun computeWaveRepeatVotes(data: List<Int>): Map<Int, Double> {
        val wv = computeWaveVotes(data)
        val sv = RegimeDetector.getStreakBreakVotes(data)
        val inlineMarkov = inlineOrder1Votes(data)
        val v  = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)
        for ((k, x) in wv) v[k] = (v[k] ?: 0.0) + x * 0.4
        for ((k, x) in sv) v[k] = (v[k] ?: 0.0) + x * 0.35
        for ((k, x) in inlineMarkov) v[k] = (v[k] ?: 0.0) + x * 0.25
        return normalizeVotes(v)
    }

    private fun inlineOrder1Votes(data: List<Int>): Map<Int, Double> {
        if (data.size < 4) return equal()
        val last = data.last()
        val counts = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)
        for (i in 0 until data.size - 1) {
            if (data[i] == last) {
                val nxt = data[i + 1]
                if (nxt in 1..4) {
                    val rec = PatternMatcher.recencyFactor(data.size - (i + 1), data.size)
                    counts[nxt] = (counts[nxt] ?: 0.0) + rec
                }
            }
        }
        val t = counts.values.sum()
        if (t < 1.0) return equal()
        return normalizeVotes(counts)
    }

    private fun computeWaveVotes(data: List<Int>): Map<Int, Double> {
        if (data.size < 4) return equal()
        val v = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)
        for (i in 2 until data.size - 1) {
            val d1 = data[i] - data[i-1]; val d2 = data[i-1] - data[i-2]
            if (kotlin.math.abs(d1) in 1..3 && kotlin.math.abs(d2) in 1..3) {
                val nv = data[i+1]; if (nv in 1..4) {
                    val rec = PatternMatcher.recencyFactor(data.size - i, data.size)
                    v[nv] = (v[nv] ?: 0.0) + rec
                }
            }
        }
        return normalizeVotes(v)
    }

    private fun normalizeVotes(v: Map<Int, Double>): Map<Int, Double> {
        val t = v.values.sum(); if (t == 0.0) return equal()
        return v.mapValues { it.value / t }
    }

    private fun mergeVoteMaps(vww: List<Pair<Map<Int, Double>, Double>>): Map<Int, Double> {
        val r = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0); var tw = 0.0
        for ((votes, w) in vww) { for ((k, v) in votes) r[k] = (r[k] ?: 0.0) + v * w; tw += w }
        if (tw == 0.0) return equal()
        return r.mapValues { it.value / tw }
    }

    private fun equal() = mapOf(1 to 0.25, 2 to 0.25, 3 to 0.25, 4 to 0.25)

    /**
     * Format ensemble prediction (v7.2: her zaman tahmin vardır, "--" yok).
     * SINGLE → "pri"; DOUBLE → "pri/sec".
     */
    fun formatPrediction(r: EnsembleResult): String = when (r.tier) {
        "SINGLE" -> "${r.finalPrediction}"
        "DOUBLE" -> if (r.secondPrediction != null) "${r.finalPrediction}/${r.secondPrediction}" else "${r.finalPrediction}"
        else -> if (r.secondPrediction != null) "${r.finalPrediction}/${r.secondPrediction}" else "${r.finalPrediction}"
    }

    fun formatConfidence(r: EnsembleResult): String = "%${(r.confidence * 100).toInt()}"
    fun formatMetaConfidence(r: EnsembleResult): String = "[${(r.metaConfidence * 100).toInt()}]"

    data class FinalResolution(val finalPrediction: Int, val secondPrediction: Int?, val confidence: Double, val showDouble: Boolean)
}
