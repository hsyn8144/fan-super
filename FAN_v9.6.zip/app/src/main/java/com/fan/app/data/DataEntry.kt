package com.fan.app.data

data class DataEntry(
    val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val value: Int,
    // ── Ensemble ──────────────────────────────────────────────────────
    val ensemblePrediction: Int = 0,
    val ensembleSecondary: Int = 0,
    val ensembleIsDouble: Boolean = false,
    val ensembleTier: String = "DOUBLE",
    val ensembleCorrect: Boolean = false,
    val ensembleTotalAccuracy: Double = 0.0,
    val ensembleAccuracy: Double = 0.0,
    val ensembleSecCorrect: Boolean = false,
    val ensembleSecAccuracy: Double = 0.0,
    val ensembleConfidence: Double = 0.0,
    // ── Kalıp Arama her zaman çiftli ───────────────────────────────────
    val kalipPrediction: Int = 0,
    val kalipSecondary: Int = 0,
    val kalipIsDouble: Boolean = true,
    val kalipCorrect: Boolean = false,
    val kalipSecCorrect: Boolean = false,
    val kalipAccuracy: Double = 0.0,
    // ── Yan tahmin ────────────────────────────────────────────────────
    val sidePrediction: String = "",
    val sideCorrect: Boolean = false,
    val sideAccuracy: Double = 0.0,
    val sideConfidence: Double = 0.0,
    // ── Rejim ve sistem ───────────────────────────────────────────────
    val currentRegime: String = "KAOS",
    val detectedPattern: String = "NONE",
    val regimeSequence: String = "",
    val anomalyFlags: String = "",
    val confidenceAdjusted: Boolean = false,
    val metaConfidence: Double = 0.0,
    // ── 13 yöntemin tahmin/doğruluk/aktiflik ──────────────────────────
    val method1Prediction: Int = 0,  val method1Correct: Boolean = false,  val method1Accuracy: Double = 0.0,  val method1Active: Boolean = true,
    val method2Prediction: Int = 0,  val method2Correct: Boolean = false,  val method2Accuracy: Double = 0.0,  val method2Active: Boolean = true,
    val method3Prediction: Int = 0,  val method3Correct: Boolean = false,  val method3Accuracy: Double = 0.0,  val method3Active: Boolean = true,
    val method4Prediction: Int = 0,  val method4Correct: Boolean = false,  val method4Accuracy: Double = 0.0,  val method4Active: Boolean = true,
    val method5Prediction: Int = 0,  val method5Correct: Boolean = false,  val method5Accuracy: Double = 0.0,  val method5Active: Boolean = true,
    val method6Prediction: Int = 0,  val method6Correct: Boolean = false,  val method6Accuracy: Double = 0.0,  val method6Active: Boolean = true,
    val method7Prediction: Int = 0,  val method7Correct: Boolean = false,  val method7Accuracy: Double = 0.0,  val method7Active: Boolean = true,
    val method8Prediction: Int = 0,  val method8Correct: Boolean = false,  val method8Accuracy: Double = 0.0,  val method8Active: Boolean = true,
    val method9Prediction: Int = 0,  val method9Correct: Boolean = false,  val method9Accuracy: Double = 0.0,  val method9Active: Boolean = true,
    val method10Prediction: Int = 0, val method10Correct: Boolean = false, val method10Accuracy: Double = 0.0, val method10Active: Boolean = true,
    val method11Prediction: Int = 0, val method11Correct: Boolean = false, val method11Accuracy: Double = 0.0, val method11Active: Boolean = true,
    val method12Prediction: Int = 0, val method12Correct: Boolean = false, val method12Accuracy: Double = 0.0, val method12Active: Boolean = true,
    val method13Prediction: Int = 0, val method13Correct: Boolean = false, val method13Accuracy: Double = 0.0, val method13Active: Boolean = true,
    // ── Her bir yöntemin güveni (yeni v7.2, CSV inceleme için) ────────
    val conf1: Double = 0.0, val conf2: Double = 0.0, val conf3: Double = 0.0,
    val conf4: Double = 0.0, val conf5: Double = 0.0, val conf6: Double = 0.0,
    val conf7: Double = 0.0, val conf8: Double = 0.0, val conf9: Double = 0.0,
    val conf10: Double = 0.0, val conf11: Double = 0.0, val conf12: Double = 0.0,
    val conf13: Double = 0.0,
    val kalipConfidence: Double = 0.0
) {
    companion object {
        const val METHOD_COUNT = 13

        val METHOD_NAMES = listOf(
            "Kalip_Arama",      // 0
            "Rejim_Tespiti",    // 1
            "Fark_Dizisi",      // 2
            "Ayna_Kalip",       // 3
            "Kume_Kaymasi",     // 4
            "Beklenti_Sapma",   // 5
            "Dalga_Tekrar",     // 6
            "Online_Gradient",  // 7
            "Bayesian",         // 8
            "Meta_Ogrenme",     // 9
            "Q_Learning",       // 10
            "Mini_Transformer", // 11
            "Markov"            // 12
        )

        val METHOD_GROUP_FIT = mapOf(
            0  to listOf("TEKRAR", "YON"),
            1  to listOf("TEKRAR", "YON", "SALINIMM"),
            2  to listOf("YON", "SALINIMM"),
            3  to listOf("TEKRAR", "SALINIMM"),
            4  to listOf("YON", "SALINIMM"),
            5  to listOf("TEKRAR", "YON"),
            6  to listOf("TEKRAR", "SALINIMM"),
            7  to listOf("YON", "KAOS"),
            8  to listOf("KAOS", "TEKRAR"),
            9  to listOf("TEKRAR", "YON", "KAOS"),
            10 to listOf("KAOS", "SALINIMM"),
            11 to listOf("YON", "SALINIMM", "KAOS"),
            12 to listOf("TEKRAR", "SALINIMM", "YON", "KAOS")
        )

        val METHOD_REGIME_FIT = mapOf(
            0  to listOf("REGULAR", "REPEAT"),
            1  to listOf("REGULAR", "WAVE", "REPEAT"),
            2  to listOf("WAVE", "REGULAR"),
            3  to listOf("REGULAR", "REPEAT", "MIXED"),
            4  to listOf("REGULAR", "WAVE"),
            5  to listOf("REGULAR", "MIXED"),
            6  to listOf("WAVE", "REPEAT"),
            7  to listOf("WAVE", "CHAOS", "REPEAT"),
            8  to listOf("CHAOS", "MIXED", "REGULAR"),
            9  to listOf("REGULAR", "MIXED", "CHAOS"),
            10 to listOf("CHAOS", "MIXED", "WAVE"),
            11 to listOf("REGULAR", "WAVE", "CHAOS"),
            12 to listOf("REGULAR", "CHAOS", "WAVE", "REPEAT", "MIXED")
        )
    }
}
