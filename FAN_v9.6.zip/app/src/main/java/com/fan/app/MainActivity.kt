package com.fan.app

import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import com.fan.app.data.CsvManager
import com.fan.app.data.DataEntry
import com.fan.app.data.PythonBridge
import com.fan.app.data.PythonResult
import com.fan.app.engine.Ensemble
import com.fan.app.engine.PredictionEngine
import com.fan.app.engine.SidePrediction
import com.fan.app.overlay.OverlayService
import com.fan.app.ui.MethodStatsDialog
import com.fan.app.ui.SettingsDialog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : AppCompatActivity() {

    companion object {
        private const val REQUEST_STORAGE = 9001
    }

    private lateinit var csvManager: CsvManager
    private lateinit var engine: PredictionEngine
    private lateinit var prefs: SharedPreferences
    private val handler = Handler(Looper.getMainLooper())
    private var pyPollRunnable: Runnable? = null

    private lateinit var tvOverlayStatus: TextView
    private lateinit var btnOverlayToggle: Button
    private lateinit var tvTotalCount: TextView
    private lateinit var tvCorrectCount: TextView
    private lateinit var tvAccuracy: TextView
    private lateinit var progressAccuracy: ProgressBar
    private lateinit var tvMetaConfidence: TextView
    private lateinit var tvCurrentRegime: TextView
    private lateinit var tvAnomalyStatus: TextView
    private lateinit var tvEnsemblePrediction: TextView
    private lateinit var tvKalipPrediction: TextView
    private lateinit var tvSidePrediction: TextView
    private lateinit var tvPyPrediction: TextView
    private lateinit var tvPySidePrediction: TextView
    private lateinit var tvSideAnyAcc: TextView
    private lateinit var tvPyAnyAcc: TextView
    private lateinit var tvWarmupInfo: TextView
    private lateinit var tvRecentValues: TextView
    private lateinit var tvTierInfo: TextView
    private var tvTitleVersion: TextView? = null
    private var tvTitleModeSub: TextView? = null
    private var dividerBeforePy: View? = null
    private var dividerBeforeMeta: View? = null
    private var dividerKStats: View? = null
    private var viewAccuracyRow: View? = null
    private var viewCorrectCount: View? = null
    private var viewProgress: View? = null
    private lateinit var modeGroup: RadioGroup

    private val overlayPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (Settings.canDrawOverlays(this)) { startOverlayService() }
        else { Toast.makeText(this, "Overlay izni verilmedi", Toast.LENGTH_SHORT).show(); updateOverlayStatus() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        csvManager = CsvManager(this)
        prefs = getSharedPreferences("fan_settings", MODE_PRIVATE)

        // v8.0: içeride veri yoksa Download/fan|FAN/fan_data.csv'den otomatik yükle
        csvManager.ensureFileExists()
        val publicData = PythonBridge.readDataFromPublicFolder()
        val internalText = csvManager.readFullText()
        // İçerideki veri gerçek satır sayısı (header hariç)
        val internalDataLines = internalText.lines().count { it.isNotBlank() && !it.startsWith("id|") }
        val internalHasData = internalDataLines > 0
        // Dışarıdaki veri satır sayısı
        val publicDataLines = publicData?.lines()?.count { it.isNotBlank() && !it.startsWith("id|") } ?: 0
        // İçerisi boş ya da dışarıda belirgin şekilde daha fazla veri varsa dışarıdan yükle
        if (!internalHasData && !publicData.isNullOrBlank()) {
            csvManager.writeFullText(publicData)
            csvManager.invalidateCache()
        } else if (publicData != null && publicDataLines > internalDataLines + 5) {
            // Dışarıdaki veri belirgin şekilde daha yeni/fazla ise onu kullan
            csvManager.writeFullText(publicData)
            csvManager.invalidateCache()
        }

        engine = PredictionEngine(csvManager)

        initViews()
        setupListeners()
        applyPendingClear()
        applyModeFromPrefs()

        // Depolama izni iste (Download/FAN klasörü için)
        ensureStoragePermission()

        // Açılışta public klasöre sync
        syncCsvToPublicAndToast()
    }

    private fun ensureStoragePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                try {
                    val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                        data = Uri.parse("package:$packageName")
                    }
                    startActivityForResult(intent, REQUEST_STORAGE)
                } catch (_: Exception) {
                    val intent = Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
                    startActivityForResult(intent, REQUEST_STORAGE)
                }
            }
        }
    }

    private fun syncCsvToPublicAndToast() {
        if (prefs.getBoolean("csv_download_sync", true)) {
            lifecycleScope.launch {
                val ok = withContext(Dispatchers.IO) {
                    try {
                        csvManager.ensureFileExists()
                        PythonBridge.syncDataToPublicFolder(
                            this@MainActivity, csvManager.readFullText())
                    } catch (e: Exception) {
                        Log.e("FAN_Main", "Sync hatasi: ${e.message}", e)
                        false
                    }
                }
                Log.d("FAN_Main", "CSV sync: $ok")
                refreshStats()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        updateOverlayStatus()
        // İzin verildiyse açılışta hemen sync yap
        syncCsvToPublicAndToast()
        refreshStats()
        startPyPolling()
    }

    override fun onPause() {
        super.onPause()
        pyPollRunnable?.let { handler.removeCallbacks(it) }
    }

    private fun initViews() {
        tvOverlayStatus = findViewById(R.id.tvOverlayStatus)
        btnOverlayToggle = findViewById(R.id.btnOverlayToggle)
        tvTotalCount = findViewById(R.id.tvTotalCount)
        tvCorrectCount = findViewById(R.id.tvCorrectCount)
        tvAccuracy = findViewById(R.id.tvAccuracy)
        progressAccuracy = findViewById(R.id.progressAccuracy)
        tvMetaConfidence = findViewById(R.id.tvMetaConfidence)
        tvCurrentRegime = findViewById(R.id.tvCurrentRegime)
        tvAnomalyStatus = findViewById(R.id.tvAnomalyStatus)
        tvEnsemblePrediction = findViewById(R.id.tvEnsemblePrediction)
        tvSidePrediction = findViewById(R.id.tvSidePrediction)
        tvSideAnyAcc = findViewById(R.id.tvSideAnyAcc)
        tvWarmupInfo = findViewById(R.id.tvWarmupInfo)
        tvRecentValues = findViewById(R.id.tvRecentValues)
        tvTierInfo = findViewById(R.id.tvTierInfo)

        // v8.7: yeni ek satırlar
        tvKalipPrediction = ensureTextView(R.id.tvKalipPrediction, "🎯 Kalıp: --", Color.parseColor("#FFB74D"))
        tvPyPrediction = ensureTextView(R.id.tvPyPrediction, "🐍 Python: --", Color.parseColor("#A5D6A7"))
        tvPySidePrediction = ensureTextView(R.id.tvPySidePrediction, "🐍 Py Yan: --", Color.parseColor("#81C784"))
        tvPyAnyAcc = ensureTextView(R.id.tvPyAnyAcc, "Py Any: --", Color.parseColor("#81C784"))

        // Başlık ve ayıraçlar
        tvTitleVersion = findViewById(R.id.tvTitleVersion)
        tvTitleModeSub = findViewById(R.id.tvTitleModeSub)
        dividerBeforePy = findViewById(R.id.dividerBeforePy)
        dividerBeforeMeta = findViewById(R.id.dividerBeforeMeta)
        dividerKStats = findViewById(R.id.dividerKStats)

        modeGroup = ensureRadioGroup()
    }

    private fun ensureTextView(id: Int, defaultText: String, color: Int): TextView {
        val existing = findViewById<TextView?>(id)
        if (existing != null) return existing
        val tv = TextView(this).apply {
            text = defaultText; textSize = 16f; setTextColor(color)
            setPadding(0, 8, 0, 8)
            tag = id
        }
        // Ana layout'a ekle (basit yaklaşım: mevcut container'ın içine)
        val container = findViewById<LinearLayout>(R.id.predictionContainer)
            ?: findViewById<LinearLayout>(R.id.mainContainer)
        container?.addView(tv)
        return tv
    }

    private fun ensureRadioGroup(): RadioGroup {
        val existing = findViewById<RadioGroup?>(R.id.modeGroup)
        if (existing != null) return existing
        val rg = RadioGroup(this).apply {
            id = R.id.modeGroup
            orientation = RadioGroup.HORIZONTAL
            setPadding(0, 16, 0, 8)
        }
        val mK = android.widget.RadioButton(this).apply { text = "🔵 Kotlin"; id = R.id.modeKotlin }
        val mH = android.widget.RadioButton(this).apply { text = "⚡ Hibrit"; id = R.id.modeHybrid }
        val mP = android.widget.RadioButton(this).apply { text = "🐍 Python"; id = R.id.modePython }
        rg.addView(mK); rg.addView(mH); rg.addView(mP)
        val container = findViewById<LinearLayout>(R.id.mainContainer)
            ?: findViewById<LinearLayout>(R.id.predictionContainer)
        container?.addView(rg, 0)
        return rg
    }

    private fun setupListeners() {
        btnOverlayToggle.setOnClickListener {
            if (OverlayService.isRunning) stopOverlay() else startOverlay()
        }

        modeGroup.setOnCheckedChangeListener { _, checkedId ->
            val mode = when (checkedId) {
                R.id.modePython -> PythonBridge.MODE_PYTHON
                R.id.modeHybrid -> PythonBridge.MODE_HYBRID
                R.id.modeKotlin -> PythonBridge.MODE_KOTLIN
                else -> when (checkedId) {
                    1003 -> PythonBridge.MODE_PYTHON
                    1002 -> PythonBridge.MODE_HYBRID
                    else -> PythonBridge.MODE_KOTLIN
                }
            }
            prefs.edit().putInt("run_mode", mode).apply()
            refreshStats()
            sendOverlayCommand(OverlayService.ACTION_APPLY_SETTINGS)
        }

        // Varsayılan mod
        when (prefs.getInt("run_mode", PythonBridge.MODE_KOTLIN)) {
            PythonBridge.MODE_PYTHON -> modeGroup.check(R.id.modePython)
            PythonBridge.MODE_HYBRID -> modeGroup.check(R.id.modeHybrid)
            else -> modeGroup.check(R.id.modeKotlin)
        }

        findViewById<Button>(R.id.btnRefreshStats).setOnClickListener { refreshStats() }
        findViewById<Button>(R.id.btnQuick1).setOnClickListener { quickEntry(1) }
        findViewById<Button>(R.id.btnQuick2).setOnClickListener { quickEntry(2) }
        findViewById<Button>(R.id.btnQuick3).setOnClickListener { quickEntry(3) }
        findViewById<Button>(R.id.btnQuick4).setOnClickListener { quickEntry(4) }
        findViewById<Button>(R.id.btnMethodStats).setOnClickListener { showMethodStatsDialog() }
        findViewById<Button>(R.id.btnSettings).setOnClickListener {
            SettingsDialog(this).apply {
                setOnDismissListener {
                    sendOverlayCommand(OverlayService.ACTION_APPLY_SETTINGS)
                    applyModeFromPrefs()
                }
            }.show()
        }
        findViewById<Button>(R.id.btnExport).setOnClickListener { exportData() }
        findViewById<Button>(R.id.btnClearData).setOnClickListener { showClearConfirmDialog() }
    }

    private fun applyModeFromPrefs() {
        when (prefs.getInt("run_mode", PythonBridge.MODE_KOTLIN)) {
            PythonBridge.MODE_PYTHON -> modeGroup.check(R.id.modePython)
            PythonBridge.MODE_HYBRID -> modeGroup.check(R.id.modeHybrid)
            else -> modeGroup.check(R.id.modeKotlin)
        }
        refreshStats()
    }

    private fun applyPendingClear() {
        if (prefs.getBoolean("pending_app_clear", false)) {
            prefs.edit().remove("pending_app_clear").apply()
            engine.clearAll()
            // Public klasörü silme, sadece içeriyi sıfırla
            refreshStats()
            Toast.makeText(this, "Uygulama içi veriler sıfırlandı.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            overlayPermissionLauncher.launch(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        startOverlayService()
    }
    private fun startOverlayService() {
        try { startForegroundService(Intent(this, OverlayService::class.java)) }
        catch (e: Exception) { Toast.makeText(this, "Overlay başlatılamadı: ${e.message}", Toast.LENGTH_LONG).show() }
        updateOverlayStatus()
    }
    private fun stopOverlay() { stopService(Intent(this, OverlayService::class.java)); updateOverlayStatus() }

    private fun updateOverlayStatus() {
        val running = OverlayService.isRunning
        tvOverlayStatus.text = if (running) getString(R.string.overlay_status_on) else getString(R.string.overlay_status_off)
        btnOverlayToggle.text = if (running) getString(R.string.overlay_stop) else getString(R.string.overlay_start)
        btnOverlayToggle.backgroundTintList = ColorStateList.valueOf(
            ContextCompat.getColor(this, if (running) R.color.colorError else R.color.colorPrimary))
    }

    private fun quickEntry(value: Int) {
        lifecycleScope.launch {
            try {
                engine.onNewValue(value)
                // Önce Kotlin'in kendi tahminini ekrana yansıt
                refreshStatsInternal()
                sendOverlayCommand(OverlayService.ACTION_REFRESH)
                // Public klasöre anında sync (yeni veriyi Python görsün)
                if (prefs.getBoolean("csv_download_sync", true)) {
                    withContext(Dispatchers.IO) {
                        csvManager.ensureFileExists()
                        PythonBridge.syncDataToPublicFolder(
                            this@MainActivity, csvManager.readFullText())
                    }
                    // Kısa bir süre bekleyip Python sonucunu da anında okumayı dene
                    // (Python 0.8 sn'de kontrol ediyor, 1.2 sn sonra Python güncel olur)
                    handler.postDelayed({
                        refreshStats()
                        sendOverlayCommand(OverlayService.ACTION_REFRESH)
                    }, 1300)
                }
                Toast.makeText(this@MainActivity, "$value girildi", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "Hata: ${e.message}", Toast.LENGTH_LONG).show()
                Log.e("FAN_Main", "quickEntry hatasi", e)
            }
        }
    }

    private fun refreshStats() { lifecycleScope.launch { refreshStatsInternal() } }

    private suspend fun refreshStatsInternal() {
        val stats = engine.getStats()
        val mode = prefs.getInt("run_mode", PythonBridge.MODE_KOTLIN)
        val showK = mode == PythonBridge.MODE_KOTLIN || mode == PythonBridge.MODE_HYBRID
        val showP = mode == PythonBridge.MODE_PYTHON || mode == PythonBridge.MODE_HYBRID
        val isK = mode == PythonBridge.MODE_KOTLIN
        val isP = mode == PythonBridge.MODE_PYTHON
        val isH = mode == PythonBridge.MODE_HYBRID

        // ── Başlık mod etiketi ──────────────────────────────────
        tvTitleVersion?.text = when {
            isK -> "FAN v9.6 Kotlin"
            isP -> "FAN v9.6 Python"
            else -> "FAN v9.6 Hibrit"
        }
        tvTitleModeSub?.apply {
            text = PythonBridge.modeName(mode)
            setTextColor(when {
                isP -> Color.parseColor("#A5D6A7")
                isK -> Color.parseColor("#64B5F6")
                else -> Color.parseColor("#81C784")
            })
        }

        tvTotalCount.text = "Toplam Kayıt: ${stats.totalCount}"

        // Warmup her modda görünür (veri eksikliği moddan bağımsız)
        val warmupRemaining = maxOf(0, 51 - stats.totalCount)
        if (warmupRemaining > 0) {
            tvWarmupInfo.visibility = android.view.View.VISIBLE
            tvWarmupInfo.text = "⚙ Öğrenme modu: $warmupRemaining veri daha (ilk 50 veri sayılmaz)"
            tvWarmupInfo.setTextColor(Color.parseColor("#FF9800"))
        } else {
            tvWarmupInfo.visibility = android.view.View.VISIBLE
            tvWarmupInfo.text = if (isP) "✓ Python aktif" else "✓ Aktif tahmin modu"
            tvWarmupInfo.setTextColor(Color.parseColor("#4CAF50"))
        }

        // ── Kotlin istatistik satırı (doğruluk/ilerleme) ────────
        val kpct = if (stats.evaluatedCount > 0)
            (stats.accuracy * 100).toInt().coerceIn(0, 100) else 0
        val sideAnyPct = (stats.sideAnyAccuracy * 100).toInt()

        // Python modunda Kotlin'in doğruluk/ileri/doğru satırlarını gösterme
        val kStatsVis = if (showK) android.view.View.VISIBLE else android.view.View.GONE
        tvAccuracy.visibility = kStatsVis
        progressAccuracy.visibility = kStatsVis
        tvCorrectCount.visibility = kStatsVis
        dividerKStats?.visibility = kStatsVis
        tvTierInfo.visibility = if (showK) android.view.View.VISIBLE else android.view.View.GONE
        tvMetaConfidence.visibility = if (showK) android.view.View.VISIBLE else android.view.View.GONE
        tvCurrentRegime.visibility = if (showK) android.view.View.VISIBLE else android.view.View.GONE
        tvAnomalyStatus.visibility = if (showK) android.view.View.VISIBLE else android.view.View.GONE
        // Kotlin tahmin satırları
        tvEnsemblePrediction.visibility = if (showK) android.view.View.VISIBLE else android.view.View.GONE
        tvKalipPrediction.visibility = if (showK) android.view.View.VISIBLE else android.view.View.GONE
        tvSidePrediction.visibility = if (showK) android.view.View.VISIBLE else android.view.View.GONE
        tvSideAnyAcc.visibility = if (showK) android.view.View.VISIBLE else android.view.View.GONE
        // Python tahmin satırları
        tvPyPrediction.visibility = if (showP) android.view.View.VISIBLE else android.view.View.GONE
        tvPySidePrediction.visibility = if (showP) android.view.View.VISIBLE else android.view.View.GONE
        tvPyAnyAcc.visibility = if (showP) android.view.View.VISIBLE else android.view.View.GONE
        // Ayıraçlar
        dividerBeforePy?.visibility = when {
            isH -> android.view.View.VISIBLE
            else -> android.view.View.GONE
        }
        dividerBeforeMeta?.visibility = if (showK) android.view.View.VISIBLE else android.view.View.GONE

        if (showK) {
            tvAccuracy.text = "🔵 Ensemble: %$kpct"
            progressAccuracy.progress = kpct
            tvCorrectCount.text = "Doğru: ${stats.correctCount}/${stats.evaluatedCount} (çiftli dahil: ${stats.totalCorrectCount})"
            tvSideAnyAcc.text = "★ K Yan: ${sideAnyPct}%"
            tvSideAnyAcc.setTextColor(if (sideAnyPct >= 75) Color.parseColor("#4CAF50") else pctColor(sideAnyPct))
        }

        val currentPred = engine.getCurrentPrediction()
        val result = currentPred.ensembleResult
        tvRecentValues.text = currentPred.recentValues.joinToString("  ")

        if (showK && result != null) {
            tvMetaConfidence.text = "Meta Güven: ${(result.metaConfidence * 100).toInt()}%"
            tvCurrentRegime.text = "Rejim: ${formatRegime(result.currentRegime)}"
            val anomalyCount = result.anomalyInfo?.anomalies?.size ?: 0
            if (anomalyCount > 0) {
                tvAnomalyStatus.text = "⚠ $anomalyCount Anomali"
                tvAnomalyStatus.setTextColor(ContextCompat.getColor(this, R.color.colorError))
            } else {
                tvAnomalyStatus.text = "✓ Normal"
                tvAnomalyStatus.setTextColor(ContextCompat.getColor(this, R.color.colorAccent))
            }
            val ensPredStr = Ensemble.formatPrediction(result)
            val ensConfStr = Ensemble.formatConfidence(result)
            tvEnsemblePrediction.text = "🔵 Kotlin: $ensPredStr  $ensConfStr"
            when (result.tier) {
                "SINGLE" -> {
                    tvEnsemblePrediction.setTextColor(Color.parseColor("#4CAF50"))
                    tvTierInfo.text = "✓ Tekil (emin)"
                    tvTierInfo.setTextColor(Color.parseColor("#4CAF50"))
                }
                else -> {
                    tvEnsemblePrediction.setTextColor(Color.parseColor("#FF9800"))
                    tvTierInfo.text = "⚡ Çiftli tahmin"
                    tvTierInfo.setTextColor(Color.parseColor("#FF9800"))
                }
            }
            val kT = if (result.kalipSecondary != null && result.kalipSecondary > 0)
                "${result.kalipPrediction}/${result.kalipSecondary}" else "${result.kalipPrediction}"
            tvKalipPrediction.text = "🎯 Kalıp: $kT"
            val sideStr = result.sideFormatted.ifBlank { "T•K" }
            tvSidePrediction.text = "★ K Yan: $sideStr"
            val sideColor = if (sideStr.contains("=")) Color.parseColor("#4CAF50") else Color.parseColor("#CE93D8")
            tvSidePrediction.setTextColor(sideColor)
        } else if (showK) {
            tvMetaConfidence.text = "Meta Güven: --"
            tvCurrentRegime.text = "Rejim: --"
            tvAnomalyStatus.text = "--"
            tvAnomalyStatus.setTextColor(ContextCompat.getColor(this, R.color.colorTextSecondary))
            tvEnsemblePrediction.text = "🔵 Kotlin: --"
            tvEnsemblePrediction.setTextColor(Color.parseColor("#9E9E9E"))
            tvKalipPrediction.text = "🎯 Kalıp: --"
            tvSidePrediction.text = "★ K Yan: --"
            tvTierInfo.text = ""
        }

        // ── Python sonucu ───────────────────────────────────────
        val py = PythonBridge.readLastPythonResult()
        if (showP && py.hasPrediction) {
            val pyStr = if (py.secondary != null) "${py.primary}/${py.secondary}" else "${py.primary}"
            tvPyPrediction.text = "🐍 Python: $pyStr  %${(py.confidence * 100).toInt()}"
            tvPyPrediction.setTextColor(Color.parseColor("#A5D6A7"))
            tvPySidePrediction.text = "🐍 Py Yan: ${py.sideFormatted.ifBlank { "--" }}  %${(py.sideConfidence * 100).toInt()}"
            tvPySidePrediction.setTextColor(
                if (py.sideFormatted.contains("=")) Color.parseColor("#4CAF50") else Color.parseColor("#81C784"))
            val pya = if (py.evaluatedCount > 0) (py.anyAccuracy * 100).toInt() else 0
            tvPyAnyAcc.text = "🐍 Py Any: ${if (pya > 0) "%$pya" else "--"}"
            // Python modunda doğruluk ilerlemesini Python'un skoruyla göster
            if (isP) {
                tvAccuracy.visibility = android.view.View.VISIBLE
                progressAccuracy.visibility = android.view.View.VISIBLE
                tvCorrectCount.visibility = android.view.View.VISIBLE
                tvAccuracy.text = "🐍 Python: %${pya}"
                tvAccuracy.setTextColor(Color.parseColor("#A5D6A7"))
                progressAccuracy.progress = pya.coerceIn(0, 100)
                progressAccuracy.progressTintList = ColorStateList.valueOf(Color.parseColor("#4CAF50"))
                tvCorrectCount.text = "Python değerlendirilen: ${py.evaluatedCount}"
            } else {
                progressAccuracy.progressTintList = ColorStateList.valueOf(
                    ContextCompat.getColor(this, R.color.colorAccent))
            }
        } else if (showP) {
            tvPyPrediction.text = "🐍 Py: -- (Termux'ta fan_live.py başlatın)"
            tvPyPrediction.setTextColor(Color.parseColor("#9E9E9E"))
            tvPySidePrediction.text = "🐍 PyYan: --"
            tvPySidePrediction.setTextColor(Color.parseColor("#9E9E9E"))
            tvPyAnyAcc.text = ""
            if (isP) {
                tvAccuracy.visibility = android.view.View.VISIBLE
                progressAccuracy.visibility = android.view.View.VISIBLE
                tvCorrectCount.visibility = android.view.View.VISIBLE
                tvAccuracy.text = "🐍 Python: --"
                progressAccuracy.progress = 0
                tvCorrectCount.text = "Python bekleniyor..."
            }
        }
    }

    private fun pctColor(pct: Int): Int = when {
        pct >= 50 -> Color.parseColor("#4CAF50")
        pct >= 35 -> Color.parseColor("#FF9800")
        pct >= 25 -> Color.parseColor("#FFC107")
        else -> Color.parseColor("#F44336")
    }
    private fun formatRegime(regime: String): String = regime.split("_").joinToString(" · ")

    private fun showMethodStatsDialog() {
        lifecycleScope.launch {
            try {
                val stats = engine.getStats()
                val py = withContext(Dispatchers.IO) { PythonBridge.readLastPythonResult() }
                Log.d("FAN_Main", "Python sonucu: pri=${py.primary} sec=${py.secondary} conf=${py.confidence} " +
                    "ev=${py.evaluatedCount} priAcc=${py.priAccuracy} anyAcc=${py.anyAccuracy} " +
                    "side=${py.sideAnyAccuracy} stratN=${py.stratStats.size} hasPred=${py.hasPrediction}")
                val activeStats = withContext(Dispatchers.IO) {
                    val allEntries = csvManager.readAllEntries()
                    val lastEntry = allEntries.lastOrNull() ?: return@withContext null
                    (0 until DataEntry.METHOD_COUNT).map { idx ->
                        val name = DataEntry.METHOD_NAMES[idx].replace("_", " ")
                        val isActive = when (idx) {
                            0 -> lastEntry.method1Active; 1 -> lastEntry.method2Active; 2 -> lastEntry.method3Active
                            3 -> lastEntry.method4Active; 4 -> lastEntry.method5Active; 5 -> lastEntry.method6Active
                            6 -> lastEntry.method7Active; 7 -> lastEntry.method8Active; 8 -> lastEntry.method9Active
                            9 -> lastEntry.method10Active; 10 -> lastEntry.method11Active; 11 -> lastEntry.method12Active
                            12 -> lastEntry.method13Active; else -> true
                        }
                        Triple(name, if (isActive) 1 else 0, if (isActive) 1 else 0)
                    }
                }
                val ensembleRow = Triple("Ensemble", stats.correctCount, stats.evaluatedWithPrediction)
                val kalipRow = Triple("Kalıp Arama (çiftli)",
                    (stats.kalipAccuracy * stats.evaluatedCount).toInt(), stats.evaluatedCount)
                val sideRow = Triple("★ Yan Tahmin", (stats.sideAnyAccuracy * stats.evaluatedCount).toInt(), stats.evaluatedCount)
                val allRows = listOf(ensembleRow) + stats.methodStats + listOf(kalipRow, sideRow)

                val summary = MethodStatsDialog.SummaryStats(
                    ensembleAcc = stats.accuracy,
                    ensembleTotalAcc = if (stats.evaluatedCount > 0)
                        stats.totalCorrectCount.toDouble() / stats.evaluatedCount else 0.0,
                    kalipAcc = stats.kalipAccuracy,
                    sideAnyAcc = stats.sideAnyAccuracy,
                    evaluatedCount = stats.evaluatedCount,
                    correctCount = stats.correctCount,
                    noPredictionCount = 0,
                    pythonPriAcc = py.priAccuracy,
                    pythonAnyAcc = py.anyAccuracy,
                    pythonSideAnyAcc = py.sideAnyAccuracy,
                    pythonEvaluatedCount = py.evaluatedCount,
                    runMode = prefs.getInt("run_mode", PythonBridge.MODE_KOTLIN)
                )
                MethodStatsDialog(this@MainActivity, allRows, activeStats, summary, py).show()
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "Hata: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun exportData() {
        try {
            // Public klasöre son kopyayı da at
            lifecycleScope.launch {
                withContext(Dispatchers.IO) {
                    csvManager.ensureFileExists()
                    PythonBridge.syncDataToPublicFolder(
                        this@MainActivity, csvManager.readFullText())
                }
            }
            val uri = FileProvider.getUriForFile(this, "$packageName.provider", csvManager.exportFile())
            startActivity(Intent.createChooser(
                Intent(Intent.ACTION_SEND).apply {
                    type = "text/csv"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }, "CSV Dışa Aktar"))
        } catch (e: Exception) { Toast.makeText(this, "Hata: ${e.message}", Toast.LENGTH_LONG).show() }
    }

    private fun showClearConfirmDialog() {
        val options = arrayOf(
            "Sadece uygulama içi veriyi sıfırla (Download/FAN/ korunur)",
            "Download/FAN/ klasörünü de sıfırla (3 onay, GERİ ALINAMAZ)",
            "İptal"
        )
        AlertDialog.Builder(this)
            .setTitle("Verileri Temizle")
            .setItems(options) { dlg, which ->
                when (which) {
                    0 -> {
                        // Uygulama içi: tek onay yeterli, klasör dokunulmaz
                        engine.clearAll()
                        refreshStats()
                        sendOverlayCommand(OverlayService.ACTION_REFRESH)
                        Toast.makeText(this, "Uygulama içi veriler silindi (klasör korundu).", Toast.LENGTH_SHORT).show()
                    }
                    1 -> confirmFolderClear_step1()
                    else -> dlg.dismiss()
                }
            }.show()
    }

    private fun confirmFolderClear_step1() {
        AlertDialog.Builder(this)
            .setTitle("⚠️ DİKKAT (1/3)")
            .setMessage("Download/FAN/ klasöründeki TÜM veriler (ana CSV + Python log) GERİ ALINAMAYACAK şekilde silinecek.\n\nDevam etmek istiyor musun?")
            .setPositiveButton("Evet") { _, _ -> confirmFolderClear_step2() }
            .setNegativeButton("İptal", null).show()
    }
    private fun confirmFolderClear_step2() {
        AlertDialog.Builder(this)
            .setTitle("⚠️ SON KARAR (2/3)")
            .setMessage("Bu işlem verilerinizi KALICI olarak silecek. Emin misiniz?")
            .setPositiveButton("Evet, sil") { _, _ -> confirmFolderClear_step3() }
            .setNegativeButton("İptal", null).show()
    }
    private fun confirmFolderClear_step3() {
        AlertDialog.Builder(this)
            .setTitle("⛔ SON UYARI (3/3)")
            .setMessage("GERİ DÖNÜŞ YOK. \"SİL\" butonuna basarsan veriler tamamen gider.")
            .setPositiveButton("SİL") { _, _ ->
                engine.clearAll()
                PythonBridge.deletePublicData()
                refreshStats()
                sendOverlayCommand(OverlayService.ACTION_REFRESH)
                Toast.makeText(this, "Tüm veriler silindi (klasör yapısı korundu).", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("İptal", null).show()
    }

    private fun sendOverlayCommand(action: String) {
        if (!OverlayService.isRunning) return
        try { startService(Intent(this, OverlayService::class.java).apply { this.action = action }) } catch (_: Exception) {}
    }

    private fun startPyPolling() {
        pyPollRunnable?.let { handler.removeCallbacks(it) }
        val runnable = object : Runnable {
            override fun run() {
                refreshStats()
                sendOverlayCommand(OverlayService.ACTION_REFRESH)
                handler.postDelayed(this, 1500)
            }
        }
        pyPollRunnable = runnable
        handler.postDelayed(runnable, 800)
    }
}
