package com.fan.app.engine

import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/**
 * Yan tahmin motoru — v7.2
 *
 * 9 yöntemli küçük ensemble + online öğrenme + half-memory:
 *   1. binary (klasik ikili n-gram + mirror + Markov + streak + position + bias)
 *   2. full_ngram (tam-değer 1-4 n-gram)
 *   3. markov (order 1+2)
 *   4. mirror (ayna/ters pattern)
 *   5. delta (fark dizisi)
 *   6. streak (seri kırılması)
 *   7. position (döngüler)
 *   8. bias (son 60 verinin eğilimi)
 *   9. binyPattern (ikili eksenli kalıp arama, maks 20 uzunluk, tüm veride)
 *
 * v7.2 ÇIKTI MANTIĞI (filtre KALDIRILDI — hiçbir zaman "--"):
 *   - Her iki eksen de ≥0.65     → çapraz + sayı: "T•B=3", "C•K=2" vb. (KESİN)
 *   - Diğer tüm durumlar         → çift harf: "T•B" (en iyi iki tahmin)
 *   Artık tek harf ya da "--" gösterilmez.
 *
 * Sayı eşleşmesi: 1=KT, 2=KC, 3=BT, 4=BC
 */
object SidePrediction {

    enum class OddEven { ODD, EVEN }
    enum class SmallBig { SMALL, BIG }

    // Tier constants (v7.2: filtre yok — her zaman tahmin)
    // <0.65: çiftli (pri/sec); ≥0.65: tekil
    private const val TIER_NO_PRED = 0.0      // asla kullanma (filtre kaldırıldı)
    private const val TIER_CROSS = 0.65       // ≥0.65 her iki eksen → çapraz+sayı
    // 0.0–0.65: çift harf (T•B) ya da tek harf (göreceli güçlü taraf);
    // Her zaman tahmin gösterilir, "--" kalktı.

    data class SidePredictionResult(
        val oddEvenPrediction: OddEven,
        val oddEvenConfidence: Double,
        val oddEvenSecond: OddEven?,
        val smallBigPrediction: SmallBig,
        val smallBigConfidence: Double,
        val smallBigSecond: SmallBig?,
        val oeAccuracyEma: Double = 0.5,
        val sbAccuracyEma: Double = 0.5,
        val anyAccuracyEma: Double = 0.5,
        val bothAccuracyEma: Double = 0.5,
        val oeMethodBreakdown: Map<String, Double> = emptyMap(),
        val sbMethodBreakdown: Map<String, Double> = emptyMap()
    )

    // ── Helpers ──────────────────────────────────────────────────────────────
    fun Int.toOddEven(): OddEven = if (this % 2 != 0) OddEven.ODD else OddEven.EVEN
    fun Int.toSmallBig(): SmallBig = if (this <= 2) SmallBig.SMALL else SmallBig.BIG
    private fun toBit(v: Int, axis: Int): Int = when (axis) {
        0 -> if (v % 2 != 0) 1 else 0  // OE: 1=T(odd), 0=C(even)
        else -> if (v > 2) 1 else 0     // SB: 1=B, 0=K
    }

    private fun lettersToNumber(sbLetter: String, oeLetter: String): Int? {
        val key = sbLetter + oeLetter
        return when (key) {
            "KT" -> 1
            "KC" -> 2
            "BT" -> 3
            "BC" -> 4
            else -> null
        }
    }

    private fun recencyFactor(distance: Int, totalSize: Int): Double {
        if (totalSize <= 1) return 1.0
        return exp(-RECENCY_DECAY * distance.toDouble() / totalSize.toDouble())
    }

    /** Yan için recency: daha keskin — yeni veriler öne çıkıyor */
    private fun recencyFactorBinary(distance: Int, totalSize: Int): Double {
        if (totalSize <= 1) return 1.0
        return exp(-3.5 * distance.toDouble() / totalSize.toDouble())
    }

    private fun normalizeVotes(v: Map<Int, Double>): Map<Int, Double> {
        val t = v.values.sum()
        if (t <= 0) return mapOf(1 to 0.25, 2 to 0.25, 3 to 0.25, 4 to 0.25)
        return v.mapValues { (it.value / t).coerceIn(0.02, 0.92) }
    }

    private fun normalizeBinary(v: Map<Int, Double>): Map<Int, Double> {
        val t = v.values.sum()
        if (t <= 0) return mapOf(0 to 0.5, 1 to 0.5)
        val p1 = (v[1]!! / t).coerceIn(1 - CAP, CAP)
        return mapOf(0 to 1 - p1, 1 to p1)
    }

    // ── 4-valued side methods ───────────────────────────────────────────────

    private fun methodFullNgram(data: List<Int>): Map<Int, Double> {
        val votes = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)
        var tw = 0.0
        for (n in 1..5) {
            if (data.size < n + 2) continue
            val pat = data.takeLast(n)
            val cnt = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)
            var mc = 0
            for (j in 0..data.size - n - 1) {
                if (data.subList(j, j + n) == pat) {
                    val nx = data[j + n]
                    if (nx in 1..4) {
                        val r = recencyFactor(data.size - (j + n), data.size)
                        cnt[nx] = (cnt[nx] ?: 0.0) + r
                        mc++
                        if (mc >= MAX_PATTERN_MATCHES) break
                    }
                }
            }
            val tot = cnt.values.sum()
            if (tot >= 1.5) {
                val w = (6 - n) * 0.22 + min(tot / 8.0, 0.7)
                for ((k, v) in cnt) votes[k] = (votes[k] ?: 0.0) + (v / tot) * w
                tw += w
            }
        }
        if (tw < 0.5) return uniform4()
        return normalizeVotes(votes)
    }

    private fun methodMarkov(data: List<Int>): Map<Int, Double> {
        val votes = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)
        if (data.size >= 3) {
            val last = data.last()
            val cnt = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)
            for (j in 0 until data.size - 1) {
                if (data[j] == last) {
                    val nx = data[j + 1]
                    if (nx in 1..4) cnt[nx] = (cnt[nx] ?: 0.0) + recencyFactor(data.size - (j + 1), data.size)
                }
            }
            val t = cnt.values.sum()
            if (t >= 1.5) for ((k, v) in cnt) votes[k] = (votes[k] ?: 0.0) + (v / t) * 1.0
        }
        if (data.size >= 4) {
            val l1 = data[data.size - 1]; val l2 = data[data.size - 2]
            val cnt = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)
            for (j in 0 until data.size - 2) {
                if (data[j] == l2 && data[j + 1] == l1) {
                    val nx = data[j + 2]
                    if (nx in 1..4) cnt[nx] = (cnt[nx] ?: 0.0) + recencyFactor(data.size - (j + 2), data.size)
                }
            }
            val t = cnt.values.sum()
            if (t >= 1.0) for ((k, v) in cnt) votes[k] = (votes[k] ?: 0.0) + (v / t) * 0.7
        }
        val tot = votes.values.sum()
        if (tot < 0.5) return uniform4()
        return normalizeVotes(votes)
    }

    private fun methodMirror(data: List<Int>): Map<Int, Double> {
        val votes = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)
        var tw = 0.0
        for (n in 2..5) {
            if (data.size < n + 2) continue
            val pat = data.takeLast(n).reversed()
            val cnt = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)
            var mc = 0
            for (j in 0..data.size - n - 1) {
                if (data.subList(j, j + n) == pat) {
                    val nx = data[j + n]
                    if (nx in 1..4) {
                        val r = recencyFactor(data.size - (j + n), data.size) * 0.5
                        cnt[nx] = (cnt[nx] ?: 0.0) + r
                        mc++
                        if (mc >= MAX_PATTERN_MATCHES) break
                    }
                }
            }
            val tot = cnt.values.sum()
            if (tot >= 1.0) {
                val w = ((6 - n) * 0.22 + min(tot / 8.0, 0.7)) * 0.5
                for ((k, v) in cnt) votes[k] = (votes[k] ?: 0.0) + (v / tot) * w
                tw += w
            }
        }
        if (tw < 0.3) return uniform4()
        return normalizeVotes(votes)
    }

    private fun methodDelta(data: List<Int>): Map<Int, Double> {
        if (data.size < 4) return uniform4()
        val deltas = data.zipWithNext { a, b ->
            val d = b - a
            when { d > 3 -> d - 4; d < -3 -> d + 4; else -> d }
        }
        val votes = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)
        val last = data.last(); var tw = 0.0
        for (n in 2..minOf(6, deltas.size - 1)) {
            val pat = deltas.takeLast(n)
            for (j in 0..deltas.size - n - 1) {
                if (deltas.subList(j, j + n) == pat) {
                    val nd = deltas[j + n]
                    val pred = ((last - 1 + nd).mod(4)) + 1
                    val r = recencyFactor(deltas.size - (j + n), deltas.size)
                    val w = n.toDouble() / 10.0
                    votes[pred] = (votes[pred] ?: 0.0) + w * r
                    tw += w * r
                }
            }
        }
        if (tw < 0.5) return uniform4()
        return normalizeVotes(votes)
    }

    private fun methodStreak(data: List<Int>): Map<Int, Double> {
        if (data.size < 3) return uniform4()
        val v = data.last(); var streak = 1
        for (j in data.size - 2 downTo 0) { if (data[j] == v) streak++ else break }
        val votes = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)
        for (i in streak until data.size) {
            var j = i - 1; var c = 0
            while (j >= 0 && data[j] == v) { c++; j-- }
            if (c == streak && i < data.size) {
                val nx = data[i]
                if (nx in 1..4 && nx != v) {
                    val r = recencyFactor(data.size - i, data.size)
                    votes[nx] = (votes[nx] ?: 0.0) + r
                }
            }
        }
        val tot = votes.values.sum()
        if (tot < 1.0) {
            val cnt = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)
            for (j in 0 until data.size - 1) {
                if (data[j] == v) {
                    val nx = data[j + 1]
                    if (nx in 1..4 && nx != v) cnt[nx] = (cnt[nx] ?: 0.0) + recencyFactor(data.size - (j + 1), data.size)
                }
            }
            val t = cnt.values.sum()
            if (t < 0.5) return uniform4()
            for ((k, vv) in cnt) votes[k] = (votes[k] ?: 0.0) + vv / t * 0.7
            return normalizeVotes(votes)
        }
        return normalizeVotes(votes)
    }

    private fun methodBinaryAxis(data: List<Int>): Map<Int, Double> {
        val oeVote = binaryAxisVote(data.map { toBit(it, 0) }, oeState)
        val sbVote = binaryAxisVote(data.map { toBit(it, 1) }, sbState)
        val pT = oeVote[1]!!; val pB = sbVote[1]!!
        return mapOf(1 to (1 - pB) * pT, 2 to (1 - pB) * (1 - pT),
                    3 to pB * pT,        4 to pB * (1 - pT)).let { normalizeVotes(it) }
    }

    private fun methodPosition(data: List<Int>): Map<Int, Double> {
        val votes = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)
        var tw = 0.0
        for (period in 2..8) {
            if (data.size < period * 2) continue
            val pi = data.size % period; var tot = 0; val cnt = mutableMapOf(1 to 0, 2 to 0, 3 to 0, 4 to 0); var k = pi
            while (k < data.size - 1) { val nv=data[k+1]; if(nv in 1..4) cnt[nv]=(cnt[nv]?:0)+1; tot++; k+=period }
            if (tot >= 3) {
                val dom = cnt.maxByOrNull { it.value }?.key ?: 1
                val conf = (cnt[dom] ?: 0).toDouble() / tot
                if (conf >= 0.45) { votes[dom] = (votes[dom] ?: 0.0) + conf * 0.10; tw += 0.10 }
            }
        }
        if (tw < 0.1) return uniform4()
        return normalizeVotes(votes)
    }

    private fun methodBias(data: List<Int>): Map<Int, Double> {
        val recent = data.takeLast(minOf(60, data.size))
        if (recent.size < 10) return uniform4()
        val bOe = mutableMapOf(0 to 0.0, 1 to 0.0); val bSb = mutableMapOf(0 to 0.0, 1 to 0.0)
        var oeRw = 0.0; var sbRw = 0.0
        for ((i, x) in recent.withIndex()) {
            val r = recencyFactor(recent.size - 1 - i, recent.size)
            bOe[toBit(x,0)] = (bOe[toBit(x,0)] ?: 0.0) + r
            bSb[toBit(x,1)] = (bSb[toBit(x,1)] ?: 0.0) + r
            oeRw += r; sbRw += r
        }
        val pT = if (oeRw>0) (bOe[1]!!/oeRw) else 0.5; val pB = if (sbRw>0) (bSb[1]!!/sbRw) else 0.5
        val pTs=0.5+(pT-0.5)*0.6; val pBs=0.5+(pB-0.5)*0.6
        return mapOf(1 to (1-pBs)*pTs, 2 to (1-pBs)*(1-pTs),
                    3 to pBs*pTs,     4 to pBs*(1-pTs)).let { normalizeVotes(it) }
    }

    // ── YENİ v7.1: Binary pattern matcher her iki eksen için ────────────────
    // Maks 20 uzunluk, tüm veride arar, en uzun en yüksek skor, alt patternler bonus.
    private data class BinaryPatternHit(val length: Int, val nextBit: Int, val position: Int)

    /**
     * İkili (0/1) dizi üzerinde uzun pattern arama.
     * @param series 0/1 dizisi (örn T/C için 1/0)
     * @return p(1) — 1 gelme olasılığı
     */
    private fun binaryPatternAxisVote(series: List<Int>): Map<Int, Double> {
        if (series.size < 3) return mapOf(0 to 0.5, 1 to 0.5)
        // Her uzunluk için (20'den aşağı, veri boyunca) arama yap
        val maxLen = minOf(BINARY_PATTERN_MAX, series.size - 1)
        val votes = mutableMapOf(0 to 0.0, 1 to 0.0)
        var tw = 0.0

        // En uzundan kısaya ara, bulunan her n için skor ekle
        for (len in maxLen downTo 2) {
            val pat = series.takeLast(len)
            var score0 = 0.0; var score1 = 0.0; var matches = 0
            // Tüm veride ara (pencere sınırı yok)
            for (j in 0..series.size - len - 1) {
                if (series.subList(j, j + len) == pat) {
                    val nx: Int = series[j + len]
                    val r: Double = recencyFactorBinary(series.size - (j + len), series.size)
                    // En uzun pattern daha yüksek ağırlık (len^1.25 / 14)
                    val w: Double = (len.toDouble().pow(1.25)) / 14.0
                    if (nx == 1) score1 += r * w else score0 += r * w
                    tw += r * w
                    matches++
                    if (matches >= 40) break  // performans
                }
            }
            if (matches >= 1) {
                // Bulunan pattern'ler için ana skor
                votes[0] = (votes[0] ?: 0.0) + score0
                votes[1] = (votes[1] ?: 0.0) + score1
                // Alt pattern bonusu: bulunan en uzun pattern'in bir alt (len-1)'i için
                // ayrıca küçük bir katkı (güveni artırmak için)
                if (len >= 6) {
                    votes[0] = votes[0]!! * 1.03
                    votes[1] = votes[1]!! * 1.03
                }
            }
        }
        if (tw < 0.1) return mapOf(0 to 0.5, 1 to 0.5)
        val t = votes[0]!! + votes[1]!!
        return if (t > 0) {
            val p1 = (votes[1]!! / t).coerceIn(1 - CAP, CAP)
            mapOf(0 to 1 - p1, 1 to p1)
        } else mapOf(0 to 0.5, 1 to 0.5)
    }

    /** Bu binyPattern yöntemi 4-değerli oylar döndürür (diğer 8 yöntemle birleştirmek için). */
    private fun methodBinaryPattern(data: List<Int>): Map<Int, Double> {
        val oeSeries = data.map { toBit(it, 0) }
        val sbSeries = data.map { toBit(it, 1) }
        val oeVote = binaryPatternAxisVote(oeSeries)
        val sbVote = binaryPatternAxisVote(sbSeries)
        val pT = oeVote[1]!!; val pB = sbVote[1]!!
        return mapOf(
            1 to (1 - pB) * pT,
            2 to (1 - pB) * (1 - pT),
            3 to pB * pT,
            4 to pB * (1 - pT)
        ).let { normalizeVotes(it) }
    }

    // ── Generic binary axis vote (eski yöntem, binary yöntemi için) ────────
    private fun binaryAxisVote(series: List<Int>, state: AxisState): Map<Int, Double> {
        val votes = mutableMapOf(0 to 0.0, 1 to 0.0)
        var tw = 0.0
        for (n in 1..5) {
            if (series.size < n + 2) continue
            val pat = series.takeLast(n)
            val rc = mutableMapOf(0 to 0.0, 1 to 0.0); var mc = 0
            for (j in 0..series.size - n - 1) {
                if (series.subList(j, j + n) == pat) {
                    rc[series[j + n]] = (rc[series[j + n]] ?: 0.0) + recencyFactor(series.size - (j + n), series.size)
                    mc++
                    if (mc >= MAX_PATTERN_MATCHES) break
                }
            }
            val rt = rc[0]!! + rc[1]!!
            if (rt >= 2) {
                val w = (6 - n) * NGRAM_W + min(rt/10.0, 0.7)
                votes[0] = (votes[0] ?: 0.0) + (rc[0]!!/rt)*w
                votes[1] = (votes[1] ?: 0.0) + (rc[1]!!/rt)*w
                tw += w
            }
            val rev = pat.reversed()
            val rrc = mutableMapOf(0 to 0.0, 1 to 0.0)
            for (j in 0..series.size - n - 1) {
                if (series.subList(j, j + n) == rev)
                    rrc[series[j+n]] = (rrc[series[j+n]]?:0.0) + recencyFactor(series.size-(j+n), series.size) * MIRROR_SCALE
            }
            val rt2 = rrc[0]!! + rrc[1]!!
            if (rt2 >= 1) {
                val wm = ((6-n)*NGRAM_W + min(rt2/10.0,0.7))*MIRROR_SCALE
                votes[0] = (votes[0]?:0.0) + (rrc[0]!!/rt2)*wm; votes[1] = (votes[1]?:0.0) + (rrc[1]!!/rt2)*wm
                tw += wm
            }
        }
        for (order in 1..2) {
            if (series.size < order + 1) continue
            val ctx = series.takeLast(order); val cnt = mutableMapOf(0 to 0.0, 1 to 0.0)
            for (j in 0..series.size - order - 1) {
                if (series.subList(j, j+order) == ctx)
                    cnt[series[j+order]] = (cnt[series[j+order]]?:0.0) + recencyFactor(series.size-(j+order), series.size)
            }
            val t = cnt[0]!!+cnt[1]!!
            if (t >= 1.5) { val w = MARKOV_W/order; votes[0]=(votes[0]?:0.0)+(cnt[0]!!/t)*w; votes[1]=(votes[1]?:0.0)+(cnt[1]!!/t)*w; tw+=w }
        }
        if (series.size >= 2) {
            var streak=1; val v=series.last()
            for (j in series.size-2 downTo 0) { if(series[j]==v) streak++ else break }
            val opp=1-v
            val revP=when{streak>=6->0.70; streak==5->0.62; streak==4->0.56; streak==3->0.50; streak==2->0.44; else->0.42}
            val w=STREAK_W; votes[v]=(votes[v]?:0.0)+(1-revP)*w; votes[opp]=(votes[opp]?:0.0)+revP*w; tw+=w
        }
        for (period in 2..8) {
            if (series.size<period*2) continue
            val pi=series.size%period; var tot=0; val pc=mutableMapOf(0 to 0,1 to 0); var k=pi
            while(k<series.size-1){pc[series[k+1]]=(pc[series[k+1]]?:0)+1;tot++;k+=period}
            if(tot>=3){val dom=if(pc[0]!!>=pc[1]!!)0 else 1; val conf=maxOf(pc[0]!!,pc[1]!!).toDouble()/tot
                if(conf>=POS_CONF){votes[dom]=(votes[dom]?:0.0)+conf*POS_W; tw+=POS_W}}
        }
        val recent=series.takeLast(minOf(60, series.size))
        if(recent.isNotEmpty()){var rw=0.0; val bc=mutableMapOf(0 to 0.0,1 to 0.0)
            for((i,x) in recent.withIndex()){val r=recencyFactor(recent.size-1-i, recent.size); bc[x]=(bc[x]?:0.0)+r; rw+=r}
            if(rw>0){val b1=bc[1]!!/rw; val b1s=0.5+(b1-0.5)*0.6; val w=GLOBAL_BIAS_W
                votes[1]=(votes[1]?:0.0)+b1s*w; votes[0]=(votes[0]?:0.0)+(1-b1s)*w; tw+=w}}
        val shift=antiBiasShift(state)
        votes[1]=(votes[1]?:0.0)+shift; votes[0]=(votes[0]?:0.0)-shift
        if(tw<0.1) return mapOf(0 to 0.5,1 to 0.5)
        val t=votes[0]!!+votes[1]!!; val p1=if(t>0) votes[1]!!/t else 0.5
        return mapOf(0 to (1-p1).coerceIn(1-CAP, CAP), 1 to p1.coerceIn(1-CAP, CAP))
    }

    private fun uniform4() = mapOf(1 to 0.25, 2 to 0.25, 3 to 0.25, 4 to 0.25)

    // ── Anti-bias state ─────────────────────────────────────────────────────
    private const val ANTI_BIAS_WINDOW = 25
    private data class AxisState(
        val recentPred: ArrayDeque<Int> = ArrayDeque(),
        val recentCorrect: ArrayDeque<Int> = ArrayDeque()
    )
    private val oeState = AxisState()
    private val sbState = AxisState()

    private fun recordAxis(state: AxisState, predBit: Int, actualBit: Int) {
        state.recentPred.addLast(predBit); state.recentCorrect.addLast(if(predBit==actualBit)1 else 0)
        while(state.recentPred.size>ANTI_BIAS_WINDOW) state.recentPred.removeFirst()
        while(state.recentCorrect.size>ANTI_BIAS_WINDOW) state.recentCorrect.removeFirst()
    }

    private fun antiBiasShift(state: AxisState): Double {
        if(state.recentPred.size<10) return 0.0
        var a1n=0;var a1d=0;var a0n=0;var a0d=0
        val itp=state.recentPred.iterator(); val itc=state.recentCorrect.iterator()
        while(itp.hasNext() && itc.hasNext()){val p=itp.next(); val c=itc.next()
            if(p==1){a1n+=c;a1d++}else{a0n+=c;a0d++}}
        if(a1d<4||a0d<4) return 0.0
        val acc1=a1n.toDouble()/a1d; val acc0=a0n.toDouble()/a0d
        return (acc0-acc1)*ANTI_BIAS_GAIN
    }

    // ── Online method weighting ────────────────────────────────────────────
    private data class SideMethodTracker(
        var ema: Double = 0.35, var samples: Int = 0
    ) {
        fun update(correct: Boolean, alpha: Double = 0.15) {
            ema = ema*(1-alpha) + (if(correct)1.0 else 0.0)*alpha; samples++
        }
        val weight: Double get() = when {
            samples < 5 -> 1.0   // v7.1: warmup 5 (8'den düşürüldü, hızlı adapte)
            ema >= 0.30 -> 0.5 + ema * 1.5
            else -> 0.2 + ema * 1.0
        }.coerceIn(0.15, 2.2)
    }

    private val methodTrackers = mutableMapOf<String, SideMethodTracker>()
    private fun tracker(name: String) = methodTrackers.getOrPut(name) { SideMethodTracker() }

    // v7.1: 9 yöntem
    private val METHOD_NAMES = listOf(
        "binary", "full_ngram", "markov", "mirror", "delta",
        "streak", "position", "bias", "binyPattern"
    )

    // ── Accuracy EMAs ──────────────────────────────────────────────────────
    private data class AxisPerf(
        var correctEma: Double = 0.5, var anyCorrectEma: Double = 0.5,
        var bothCorrectEma: Double = 0.5, var samples: Int = 0
    )
    private val oePerf = AxisPerf(); private val sbPerf = AxisPerf()

    // ── Public API ─────────────────────────────────────────────────────────
    fun analyze(data: List<Int>, regimeGroup: String = "KAOS"): SidePredictionResult {
        if (data.size < 3) return SidePredictionResult(
            OddEven.ODD, 0.5, OddEven.EVEN, SmallBig.SMALL, 0.5, SmallBig.BIG
        )

        val methodVotes = mapOf(
            "binary"      to methodBinaryAxis(data),
            "full_ngram"  to methodFullNgram(data),
            "markov"      to methodMarkov(data),
            "mirror"      to methodMirror(data),
            "delta"       to methodDelta(data),
            "streak"      to methodStreak(data),
            "position"    to methodPosition(data),
            "bias"        to methodBias(data),
            "binyPattern" to methodBinaryPattern(data)  // YENİ
        )

        val combined = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)
        var totW = 0.0
        for ((name, votes) in methodVotes) {
            val w = tracker(name).weight
            for ((k, v) in votes) combined[k] = (combined[k] ?: 0.0) + v * w
            totW += w
        }
        if (totW < 0.1) return SidePredictionResult(
            OddEven.ODD, 0.5, OddEven.EVEN, SmallBig.SMALL, 0.5, SmallBig.BIG
        )
        val baseVotes = combined.mapValues { (it.value / totW).coerceIn(0.02, 0.92) }

        // v7.1: binary axis vote (eski) + yeni binaryPattern + 4-değerli marjinali birleştir
        val binOe = binaryAxisVote(data.map { toBit(it, 0) }, oeState)
        val binSb = binaryAxisVote(data.map { toBit(it, 1) }, sbState)
        val bpOe = binaryPatternAxisVote(data.map { toBit(it, 0) })
        val bpSb = binaryPatternAxisVote(data.map { toBit(it, 1) })
        val pT_bin = binOe[1]!!; val pB_bin = binSb[1]!!
        val pT_bp  = bpOe[1]!!;  val pB_bp  = bpSb[1]!!
        val pT_full = (baseVotes[1] ?: 0.0) + (baseVotes[3] ?: 0.0)
        val pB_full = (baseVotes[3] ?: 0.0) + (baseVotes[4] ?: 0.0)

        // Blend: binary n-gram %35 + binary pattern %25 + full marjinal %40
        val pT = (1 - BLEND_FULL) * (0.58 * pT_bin + 0.42 * pT_bp) + BLEND_FULL * pT_full
        val pB = (1 - BLEND_FULL) * (0.58 * pB_bin + 0.42 * pB_bp) + BLEND_FULL * pB_full

        val oePred = if (pT >= 0.5) OddEven.ODD else OddEven.EVEN
        val sbPred = if (pB >= 0.5) SmallBig.BIG else SmallBig.SMALL
        val oeConf = maxOf(pT, 1 - pT)
        val sbConf = maxOf(pB, 1 - pB)

        // Second prediction: eğer zayıfsa
        val oeSecond = if (oeConf < TIER_CROSS) (if (oePred==OddEven.ODD) OddEven.EVEN else OddEven.ODD) else null
        val sbSecond = if (sbConf < TIER_CROSS) (if (sbPred==SmallBig.BIG) SmallBig.SMALL else SmallBig.BIG) else null

        // Half-memory düzeltmesi
        val sbLetter = if (sbPred==SmallBig.BIG) "B" else "K"
        val oeLetter = if (oePred==OddEven.ODD) "T" else "C"
        val sbHA = halfAcc(sbHalf, sbLetter); val oeHA = halfAcc(oeHalf, oeLetter)
        var sbConfAdj = sbConf; var oeConfAdj = oeConf
        if (sbHA != null) { sbConfAdj = (sbConf-0.5)*(0.5+sbHA)+0.5; sbConfAdj=sbConfAdj.coerceIn(0.40,0.92) }
        if (oeHA != null) { oeConfAdj = (oeConf-0.5)*(0.5+oeHA)+0.5; oeConfAdj=oeConfAdj.coerceIn(0.40,0.92) }

        return SidePredictionResult(
            oddEvenPrediction = oePred, oddEvenConfidence = oeConfAdj, oddEvenSecond = oeSecond,
            smallBigPrediction = sbPred, smallBigConfidence = sbConfAdj, smallBigSecond = sbSecond,
            oeAccuracyEma = oePerf.correctEma, sbAccuracyEma = sbPerf.correctEma,
            anyAccuracyEma = (oePerf.anyCorrectEma+sbPerf.anyCorrectEma)/2,
            bothAccuracyEma = oePerf.bothCorrectEma,
            oeMethodBreakdown = emptyMap(), sbMethodBreakdown = emptyMap()
        )
    }

    fun updatePerformance(result: SidePredictionResult, actual: Int, regimeGroup: String) {
        val ema = 0.08
        val oeBit = if (actual.toOddEven()==OddEven.ODD) 1 else 0
        val sbBit = if (actual.toSmallBig()==SmallBig.BIG) 1 else 0
        val predOe = if (result.oddEvenPrediction==OddEven.ODD) 1 else 0
        val predSb = if (result.smallBigPrediction==SmallBig.BIG) 1 else 0
        val oeCorrect = predOe == oeBit; val sbCorrect = predSb == sbBit
        val anyCorrect = oeCorrect || sbCorrect; val bothCorrect = oeCorrect && sbCorrect
        oePerf.correctEma = oePerf.correctEma*(1-ema)+(if(oeCorrect)1.0 else 0.0)*ema
        oePerf.anyCorrectEma = oePerf.anyCorrectEma*(1-ema)+(if(anyCorrect)1.0 else 0.0)*ema
        oePerf.bothCorrectEma = oePerf.bothCorrectEma*(1-ema)+(if(bothCorrect)1.0 else 0.0)*ema
        oePerf.samples++
        sbPerf.correctEma = sbPerf.correctEma*(1-ema)+(if(sbCorrect)1.0 else 0.0)*ema
        sbPerf.anyCorrectEma = sbPerf.anyCorrectEma*(1-ema)+(if(anyCorrect)1.0 else 0.0)*ema
        sbPerf.bothCorrectEma = sbPerf.bothCorrectEma*(1-ema)+(if(bothCorrect)1.0 else 0.0)*ema
        sbPerf.samples++
        recordAxis(oeState, predOe, oeBit); recordAxis(sbState, predSb, sbBit)
    }

    fun updatePerformanceWithData(prevData: List<Int>, result: SidePredictionResult, actual: Int, regimeGroup: String) {
        updatePerformance(result, actual, regimeGroup)

        val isOdd = actual % 2 != 0; val isBig = actual > 2
        val sbLetter = if (result.smallBigPrediction==SmallBig.BIG) "B" else "K"
        val oeLetter = if (result.oddEvenPrediction==OddEven.ODD) "T" else "C"

        val sbCross = result.smallBigConfidence >= TIER_CROSS
        val oeCross = result.oddEvenConfidence >= TIER_CROSS

        val sbHit = (sbLetter=="B" && isBig) || (sbLetter=="K" && !isBig)
        val oeHit = (oeLetter=="T" && isOdd) || (oeLetter=="C" && !isOdd)

        // v7.2: her zaman çiftli tahmin (filtre yok), half-memory her iki harf için de güncellenir
        recordHalf(sbHalf, sbLetter, sbHit, isDouble = !sbCross)
        recordHalf(oeHalf, oeLetter, oeHit, isDouble = !oeCross)

        if (prevData.size >= 4) {
            val mVotes = mapOf(
                "binary"      to methodBinaryAxis(prevData),
                "full_ngram"  to methodFullNgram(prevData),
                "markov"      to methodMarkov(prevData),
                "mirror"      to methodMirror(prevData),
                "delta"       to methodDelta(prevData),
                "streak"      to methodStreak(prevData),
                "position"    to methodPosition(prevData),
                "bias"        to methodBias(prevData),
                "binyPattern" to methodBinaryPattern(prevData)
            )
            for ((name, votes) in mVotes) {
                val top = votes.maxByOrNull { it.value }?.key ?: 1
                tracker(name).update(top == actual)
            }
        }
    }

    // ── Half-memory ────────────────────────────────────────────────────────
    private data class HalfMemory(
        var correctK:Int=0, var totalK:Int=0, var correctB:Int=0, var totalB:Int=0,
        var correctT:Int=0, var totalT:Int=0, var correctC:Int=0, var totalC:Int=0
    )
    private val sbHalf = HalfMemory(); private val oeHalf = HalfMemory()
    private const val HALF_WINDOW = 30

    private fun recordHalf(mem: HalfMemory, letter: String, hit: Boolean, isDouble: Boolean) {
        if (!isDouble) return
        when (letter) {
            "K" -> { mem.totalK = HALF_WINDOW.coerceAtMost(mem.totalK+1); if (hit) mem.correctK=minOf(mem.correctK+1, mem.totalK) }
            "B" -> { mem.totalB = HALF_WINDOW.coerceAtMost(mem.totalB+1); if (hit) mem.correctB=minOf(mem.correctB+1, mem.totalB) }
            "T" -> { mem.totalT = HALF_WINDOW.coerceAtMost(mem.totalT+1); if (hit) mem.correctT=minOf(mem.correctT+1, mem.totalT) }
            "C" -> { mem.totalC = HALF_WINDOW.coerceAtMost(mem.totalC+1); if (hit) mem.correctC=minOf(mem.correctC+1, mem.totalC) }
        }
    }

    private fun halfAcc(mem: HalfMemory, letter: String): Double? {
        val (c,t) = when(letter) {
            "K"->mem.correctK to mem.totalK; "B"->mem.correctB to mem.totalB
            "T"->mem.correctT to mem.totalT; "C"->mem.correctC to mem.totalC
            else->return null
        }
        if (t<6) return null
        return c.toDouble()/t
    }

    data class FourBool(val both: Boolean, val oe: Boolean, val sb: Boolean, val any: Boolean)

/**
 * Doğruluk kontrolü (v7.2: her zaman tahmin var, filtre yok):
 * - any = OE veya SB'den herhangi biri tuttu
 * - both = ikisi de tuttu (çapraz formda "sayı"yı bilmek)
 * - oe/sb = kendi ekseninde
 */
fun checkCorrect(result: SidePredictionResult, actual: Int): FourBool {
    val oeMatch = result.oddEvenPrediction == actual.toOddEven()
    val sbMatch = result.smallBigPrediction == actual.toSmallBig()
    return FourBool(
        both = oeMatch && sbMatch,
        oe = oeMatch,
        sb = sbMatch,
        any = oeMatch || sbMatch
    )
}

/**
 * Yan tahmin formatı (v7.2 filtre YOK, her zaman tahmin):
 * - Her iki eksen de ≥0.65    → "T•B=3" (çapraz + sayı, kesin)
 * - Diğer tüm durumlar       → "T•B" (çift harf, en iyi iki tahmin)
 * Artık tek harf ya da "--" yok — her zaman çift harf gösterilir.
 */
fun formatSidePrediction(result: SidePredictionResult): String {
    val sbLetter = if (result.smallBigPrediction==SmallBig.SMALL) "K" else "B"
    val oeLetter = if (result.oddEvenPrediction==OddEven.ODD) "T" else "C"
    val sbStrong = result.smallBigConfidence >= TIER_CROSS
    val oeStrong = result.oddEvenConfidence >= TIER_CROSS
    return if (sbStrong && oeStrong) {
        val num = lettersToNumber(sbLetter, oeLetter)
        if (num != null) "$oeLetter•$sbLetter=$num" else "$oeLetter•$sbLetter"
    } else {
        "$oeLetter•$sbLetter"
    }
}

    fun reset() {
        oePerf.correctEma=0.5; oePerf.anyCorrectEma=0.5; oePerf.bothCorrectEma=0.5; oePerf.samples=0
        sbPerf.correctEma=0.5; sbPerf.anyCorrectEma=0.5; sbPerf.bothCorrectEma=0.5; sbPerf.samples=0
        oeState.recentPred.clear(); oeState.recentCorrect.clear()
        sbState.recentPred.clear(); sbState.recentCorrect.clear()
        methodTrackers.clear()
        sbHalf.correctK=0;sbHalf.totalK=0;sbHalf.correctB=0;sbHalf.totalB=0
        oeHalf.correctT=0;oeHalf.totalT=0;oeHalf.correctC=0;oeHalf.totalC=0
    }

    fun getAnyAccuracy(): Double = (oePerf.anyCorrectEma+sbPerf.anyCorrectEma)/2
    fun getOeAccuracy(): Double = oePerf.correctEma
    fun getSbAccuracy(): Double = sbPerf.correctEma
    fun getBothAccuracy(): Double = (oePerf.bothCorrectEma+sbPerf.bothCorrectEma)/2

    /** Debug/inspection: son N veride hangi yöntem ne diyor, skorlar ne. */
    fun explain(data: List<Int>): String {
        if (data.size < 3) return "Yetersiz veri"
        val mVotes = mapOf(
            "binary(n-gram)"  to methodBinaryAxis(data),
            "full n-gram"     to methodFullNgram(data),
            "markov 1+2"      to methodMarkov(data),
            "mirror"          to methodMirror(data),
            "delta pattern"   to methodDelta(data),
            "streak break"    to methodStreak(data),
            "position cycle"  to methodPosition(data),
            "bias"            to methodBias(data),
            "binyPattern(yeni)" to methodBinaryPattern(data)
        )
        val sb = StringBuilder()
        sb.append("--- Yan tahmin bileşenleri ---\n")
        val res = analyze(data)
        val sbL = if (res.smallBigPrediction==SmallBig.SMALL) "K" else "B"
        val oeL = if (res.oddEvenPrediction==OddEven.ODD) "T" else "C"
        sb.append("Ana sonuç: ${formatSidePrediction(res)}  (OE=%${(res.oddEvenConfidence*100).toInt()} SB=%${(res.smallBigConfidence*100).toInt()})\n\n")
        sb.append("Yöntemler (ağırlıkla):\n")
        for ((name, votes) in mVotes) {
            val sorted = votes.entries.sortedByDescending { it.value }
            val top = sorted[0]
            val sec = sorted.getOrNull(1)
            val w = tracker(name).weight
            val pred = "${top.key}(%${(top.value*100).toInt()})" +
                      if (sec != null) "/${sec.key}(%${(sec.value*100).toInt()})" else ""
            sb.append("  • $name: $pred  [ağırlık=%.2f]\n".format(w))
        }
        return sb.toString()
    }

    // ── Sabitler ──────────────────────────────────────────────────────────
    private const val RECENCY_DECAY  = 1.6
    private const val NGRAM_W        = 0.22
    private const val MIRROR_SCALE   = 0.50
    private const val MARKOV_W       = 1.00
    private const val STREAK_W       = 0.25
    private const val GLOBAL_BIAS_W  = 0.04
    private const val POS_W          = 0.08
    private const val POS_CONF       = 0.50
    private const val CAP            = 0.94
    private const val ANTI_BIAS_GAIN = 0.25
    private const val BLEND_FULL     = 0.40  // biraz daha binary tarafa
    private const val MAX_PATTERN_MATCHES = 30
    private const val BINARY_PATTERN_MAX = 20  // v7.1: ikili pattern en fazla 20 uzunluk
}
