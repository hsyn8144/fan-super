package com.fan.app.data

/**
 * Python tarafının fan_python_log.csv'ye yazdığı en son tahmin sonucu.
 *
 * CSV formatı (v8.1, başlıksız, | ile ayrılmış, 19 kolon):
 *   ts|pri|sec|conf|side_fmt|side_conf|oe_conf|sb_conf|
 *   kpri|ksec|kconf|evaluated|pri_acc|any_acc|side_any_acc|
 *   strat_pri|strat_any|strat_n|weights_summary
 *
 * strat_pri / strat_any / strat_n: virgülle ayrılmış 9 sayı (9 strateji).
 */
data class PythonResult(
    val timestamp: Long = 0L,
    val primary: Int = 0,
    val secondary: Int? = null,
    val confidence: Double = 0.25,
    val sideFormatted: String = "",
    val sideConfidence: Double = 0.50,
    val oeConfidence: Double = 0.50,
    val sbConfidence: Double = 0.50,
    val kalipPrimary: Int = 0,
    val kalipSecondary: Int? = null,
    val kalipConfidence: Double = 0.25,
    val evaluatedCount: Int = 0,
    val priAccuracy: Double = 0.0,
    val anyAccuracy: Double = 0.0,
    val sideAnyAccuracy: Double = 0.0,
    /** 9 stratejinin her biri için (pri_hits, any_hits, n) */
    val stratStats: List<Triple<Int, Int, Int>> = emptyList(),
    val weightsSummary: String = ""
) {
    val hasPrediction: Boolean get() = primary in 1..4

    companion object {
        val EMPTY = PythonResult()

        /** Python tarafındaki 13 stratejinin Türkçe isimleri (sıra önemli — fan_live.py v9.5 ile eşleşmeli) */
        val STRATEGY_NAMES = listOf(
            "Kalıp (Py)",
            "Markov-3 (Py)",
            "N-gram 5 (Py)",
            "Delta (Py)",
            "Streak (Py)",
            "Bias/Sıklık (Py)",
            "PPM-6 (Py)",
            "Binary Axis (Py)",
            "Biny Pattern (Py)",
            "Mini LSTM (Py)",
            "kNN-DTW (Py)",
            "HMM (Py)",
            "SGD Meta (Py)"
        )
    }
}
