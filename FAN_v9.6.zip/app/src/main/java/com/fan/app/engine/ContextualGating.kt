package com.fan.app.engine

import com.fan.app.data.DataEntry

object ContextualGating {

    enum class GateType {
        PATTERN_RELIABILITY,
        FREQUENCY_STABILITY,
        WAVE_COHERENCE,
        REGIME_FIT,
        RECENT_PERFORMANCE
    }

    data class GatingResult(
        val methodIndex: Int,
        val isActive: Boolean,
        val activityLevel: Double,
        val reason: String
    )

    data class GatingContext(
        val data: List<Int>,
        val regime: RegimeDetector.RegimeType,
        val regimeSubType: String,
        val pattern: RegimeDetector.PatternInfo,
        val streak: Pair<Int, Int>,
        val recentPerformance: List<Pair<Int, Boolean>>
    )

    data class CheckResult(
        val isActive: Boolean,
        val score: Double,
        val detail: String
    )

    fun evaluateAllMethods(context: GatingContext): List<GatingResult> {
        return (0 until DataEntry.METHOD_COUNT).map { methodIndex ->
            evaluateMethod(methodIndex, context)
        }
    }

    fun evaluateMethod(methodIndex: Int, context: GatingContext): GatingResult {
        val suitableRegimes = DataEntry.METHOD_REGIME_FIT[methodIndex] ?: listOf("REGULAR")
        val regimeFit = context.regime.name in suitableRegimes

        val checks = listOf(
            checkPatternReliability(methodIndex, context),
            checkFrequencyStability(methodIndex, context),
            checkWaveCoherence(methodIndex, context),
            checkRegimeFit(methodIndex, context, suitableRegimes),
            checkRecentPerformance(methodIndex, context)
        )

        val activeChecks = checks.count { it.isActive }
        // Weighted average instead of step function for smoother activity levels
        val avgScore = checks.map { it.score }.average()
        val activityLevel = when {
            avgScore >= 0.8 -> 1.0
            avgScore >= 0.65 -> 0.8
            avgScore >= 0.5 -> 0.5
            avgScore >= 0.35 -> 0.3
            else -> 0.15
        }

        // Less aggressive cutoff: require both regime fit AND decent scores to be active,
        // OR very high scores even without regime fit (during transitions)
        val isActive = activityLevel >= 0.4 || (regimeFit && activityLevel >= 0.25)

        val reason = buildReason(checks, regimeFit, avgScore)

        return GatingResult(methodIndex, isActive, activityLevel, reason)
    }

    private fun checkPatternReliability(methodIndex: Int, context: GatingContext): CheckResult {
        if (methodIndex !in listOf(0, 4, 5)) return CheckResult(true, 1.0, "Kalıp yöntemi değil")

        val pattern = context.pattern
        val isReliable = when {
            pattern.type == "STRONG_PERIODIC" -> true
            pattern.type == "MODERATE_PERIODIC" && pattern.length >= 4 -> true
            pattern.type == "WEAK_PERIODIC" && methodIndex == 0 -> false
            else -> false
        }

        return CheckResult(
            isReliable,
            if (isReliable) pattern.strength else 0.3,
            "Kalıp: ${pattern.type}, güç: ${String.format("%.2f", pattern.strength)}"
        )
    }

    private fun checkFrequencyStability(methodIndex: Int, context: GatingContext): CheckResult {
        if (methodIndex != 1) return CheckResult(true, 1.0, "Frekans yöntemi değil")

        val recent = context.data.takeLast(50)
        val freq = recent.groupBy { it }.mapValues { it.value.size }
        val maxFreq = freq.values.maxOrNull() ?: 0
        val imbalance = maxFreq.toDouble() / recent.size

        val isStable = imbalance in 0.2..0.45
        return CheckResult(
            isStable,
            if (isStable) 1.0 else 0.5,
            "Frekans dengesi: ${String.format("%.2f", imbalance)}"
        )
    }

    private fun checkWaveCoherence(methodIndex: Int, context: GatingContext): CheckResult {
        if (methodIndex !in listOf(3, 6, 9, 10)) return CheckResult(true, 1.0, "Dalga yöntemi değil")

        val deltas = context.data.zipWithNext { a, b -> b - a }
        if (deltas.size < 3) return CheckResult(false, 0.0, "Yetersiz delta")

        val signChanges = deltas.zipWithNext { a, b -> if (a * b < 0) 1 else 0 }.sum()
        val coherence = signChanges.toDouble() / maxOf(deltas.size - 1, 1)

        val isCoherent = coherence >= 0.25
        return CheckResult(
            isCoherent,
            0.5 + 0.5 * coherence.coerceIn(0.0, 1.0),
            "Dalga tutarlılığı: ${String.format("%.2f", coherence)}"
        )
    }

    private fun checkRegimeFit(methodIndex: Int, context: GatingContext, suitableRegimes: List<String>): CheckResult {
        val fit = context.regime.name in suitableRegimes
        val fitScore = if (fit) 1.0 else 0.35

        val subTypeBonus = when {
            context.regimeSubType.contains("STRONG") && fit -> 0.15
            context.regimeSubType.contains("EXTREME") && methodIndex in listOf(9, 10) -> 0.2
            else -> 0.0
        }

        return CheckResult(
            fit,
            minOf(fitScore + subTypeBonus, 1.0),
            "Rejim uyumu: ${context.regime.name} ${if (fit) "✓" else "✗"}, alt tip: ${context.regimeSubType}"
        )
    }

    private fun checkRecentPerformance(methodIndex: Int, context: GatingContext): CheckResult {
        val recent = context.recentPerformance.filter { it.first == methodIndex }
        // Need at least 8 samples, use EMA-like weighting
        if (recent.size < 8) return CheckResult(true, 0.7, "Yetersiz geçmiş (${recent.size})")

        val window = recent.takeLast(15)
        val totalWeight = window.indices.sumOf { idx ->
            (idx + 1).toDouble() / window.size  // linear weights favoring recent
        }
        val weightedCorrect = window.indices.sumOf { idx ->
            val weight = (idx + 1).toDouble() / window.size
            if (window[idx].second) weight else 0.0
        }
        val accuracy = weightedCorrect / totalWeight

        val isGood = accuracy >= 0.35
        return CheckResult(
            isGood,
            (0.3 + 0.7 * accuracy).coerceIn(0.0, 1.0),
            "Son ${window.size} tahminde ağırlıklı doğruluk: ${String.format("%.0f", accuracy * 100)}%"
        )
    }

    private fun buildReason(checks: List<CheckResult>, regimeFit: Boolean, avgScore: Double): String {
        val passed = checks.count { it.isActive }
        val failed = checks.filter { !it.isActive }.map { it.detail }.take(2)
        return "$passed/5 kontrol geçti (skor: ${String.format("%.2f", avgScore)}). ${if (failed.isNotEmpty()) "Eksikler: ${failed.joinToString(", ")}" else ""} Rejim uyumu: ${if (regimeFit) "Evet" else "Hayır"}"
    }

    fun applyEmergencyActivation(results: List<GatingResult>): List<GatingResult> {
        val activeCount = results.count { it.isActive }

        return if (activeCount < 4) {
            results.map { result ->
                if (!result.isActive) {
                    result.copy(
                        isActive = true,
                        activityLevel = maxOf(result.activityLevel, 0.25),
                        reason = result.reason + " [ACİL AKTİVASYON]"
                    )
                } else result
            }
        } else results
    }
}
