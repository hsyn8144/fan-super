package com.fan.app.engine

class OnlineGradientDescent {

    private val featureSize = 20
    private val weights = Array(4) { DoubleArray(featureSize) { 0.0 } }
    private val bias = DoubleArray(4) { 0.0 }
    private var baseLr = 0.02
    private var trainedUpTo = 0

    private val predHistory = ArrayDeque<Int>(30)

    fun compute(data: List<Int>): Map<Int, Double> {
        if (data.size < 4) return equal()

        // Incremental learning
        if (trainedUpTo < data.size - 1) {
            val startTrain = maxOf(3, trainedUpTo)
            for (i in startTrain until data.size - 1) {
                val features = extractFeatures(data, i)
                // Adaptive learning rate: higher early, lower later; higher during chaos
                val recency = 1.0 / (1.0 + (data.size - i) * 0.01)
                val lr = baseLr * (0.5 + recency)
                learn(features, data[i + 1], lr)
            }
            trainedUpTo = data.size - 1
        }

        val features = extractFeatures(data, data.size - 1)
        return predictWithDiversity(features)
    }

    private fun extractFeatures(data: List<Int>, idx: Int): DoubleArray {
        val f = DoubleArray(featureSize)
        val v = data[idx]
        f[0] = (v - 2.5) / 1.5
        f[1] = if (idx > 0) (data[idx] - data[idx-1]).toDouble() / 3.0 else 0.0
        f[2] = if (idx > 1) (data[idx-1] - data[idx-2]).toDouble() / 3.0 else 0.0
        f[3] = if (idx > 2) (data[idx-2] - data[idx-3]).toDouble() / 3.0 else 0.0
        // Frequency last 10
        val win = data.subList(maxOf(0, idx - 9), idx + 1)
        for (k in 1..4) f[3 + k] = win.count { it == k }.toDouble() / win.size
        // Streak
        var streak = 1
        for (j in idx - 1 downTo maxOf(0, idx - 6)) { if (data[j] == v) streak++ else break }
        f[8] = streak.toDouble() / 6.0
        // Parity and half
        f[9] = (v % 2).toDouble()
        f[10] = if (v <= 2) 0.0 else 1.0
        // Position cycles
        f[11] = (idx % 2).toDouble()
        f[12] = (idx % 3).toDouble() / 3.0
        f[13] = (idx % 4).toDouble() / 4.0
        // Reversal feature
        f[14] = if (idx > 1 && data[idx] != data[idx-1] && data[idx-1] != data[idx-2]) 1.0 else 0.0
        f[15] = v.toDouble() / 4.0
        f[16] = if (idx > 0 && data[idx] == data[idx-1]) 1.0 else 0.0
        // Distance features (opposite value, adjacent)
        f[17] = if (kotlin.math.abs(v - (if (idx > 0) data[idx-1] else v)) == 3) 1.0 else 0.0
        f[18] = if (kotlin.math.abs(v - (if (idx > 0) data[idx-1] else v)) == 1) 1.0 else 0.0
        // Bias (always 1.0 baked into weights[0])
        f[19] = 1.0
        return f
    }

    private fun rawScores(f: DoubleArray): DoubleArray =
        DoubleArray(4) { cls ->
            bias[cls] + f.indices.sumOf { j -> weights[cls][j] * f[j] }
        }

    private fun softmax(scores: DoubleArray): DoubleArray {
        val mx = scores.max()
        val ex = DoubleArray(4) { kotlin.math.exp(scores[it] - mx) }
        val s = ex.sum().coerceAtLeast(1e-9)
        return DoubleArray(4) { ex[it] / s }
    }

    private fun learn(f: DoubleArray, target: Int, lr: Double) {
        val probs = softmax(rawScores(f))
        // L2 regularization
        val reg = 0.0003
        for (cls in 0..3) {
            val t = if (cls == target - 1) 1.0 else 0.0
            val err = t - probs[cls]
            bias[cls] += lr * err - lr * reg * bias[cls]
            for (j in f.indices) weights[cls][j] += lr * err * f[j] - lr * reg * weights[cls][j]
        }
    }

    private fun predictWithDiversity(f: DoubleArray): Map<Int, Double> {
        if (f.isEmpty()) return equal()
        val scores = try { rawScores(f) } catch (_: Exception) { return equal() }
        val probs = softmax(scores)
        val adjusted = try { diversityAdjust(probs) } catch (_: Exception) { probs }

        val top = adjusted.indices.maxByOrNull { adjusted[it] } ?: 0
        if (predHistory.size >= 30) predHistory.removeFirst()
        predHistory.addLast(top + 1)

        val total = adjusted.sum().coerceAtLeast(1e-9)
        return mapOf(1 to adjusted[0]/total, 2 to adjusted[1]/total, 3 to adjusted[2]/total, 4 to adjusted[3]/total)
    }

    private fun diversityAdjust(probs: DoubleArray): DoubleArray {
        if (predHistory.size < 12) return probs
        val recent = predHistory.toList().takeLast(12)
        val freq = DoubleArray(4) { k -> recent.count { it == k + 1 }.toDouble() / recent.size }
        val result = DoubleArray(4)
        for (k in 0..3) {
            // Softer diversity penalty — don't kill strong signals
            val penalty = when {
                freq[k] > 0.7 -> 0.6
                freq[k] > 0.5 -> 0.8
                else -> 1.0
            }
            result[k] = probs[k] * penalty
        }
        return result
    }

    fun reset() {
        for (i in 0 until 4) {
            weights[i].fill(0.0)
            bias[i] = 0.0
        }
        trainedUpTo = 0
        predHistory.clear()
    }

    private fun equal() = mapOf(1 to 0.25, 2 to 0.25, 3 to 0.25, 4 to 0.25)
}
