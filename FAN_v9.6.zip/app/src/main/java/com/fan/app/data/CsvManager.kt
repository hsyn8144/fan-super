package com.fan.app.data

import android.content.Context
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.*

class CsvManager(private val context: Context) {

    private val fileName = "fan_data.csv"
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
    private val csvFile: File get() = File(context.filesDir, fileName)

    private var cachedEntries: MutableList<DataEntry>? = null
    private var cachedFileLength: Long = -1L

    /**
     * v2.4: CSV formatı GERİYE DÖNÜK UYUMLU — eski sütunlar (kombine_*)
     * yerinde duruyor ama her zaman 0/HAYIR yazılıyor. Kombine yöntemi artık
     * hesaplanmıyor; kaldırıldı.
     */
    private val header: String get() {
        val sb = StringBuilder()
        sb.append("id|tarih|sayi")
        sb.append("|ensemble_tahmin|ensemble_dogru|ensemble_toplam_basari|ensemble_basari|ensemble_sec_dogru|ensemble_sec_basari|ensemble_guven")
        sb.append("|kombine_tahmin|kombine_dogru|kombine_basari|kombine_sec_dogru|kombine_sec_basari")
        sb.append("|kalip_tahmin|kalip_dogru|kalip_basari|kalip_guven")
        sb.append("|yan_tahmin|yan_dogru|yan_basari|yan_guven")
        sb.append("|rejim|kalip|rejim_dizisi|anomali|guven_ayarli|meta_guven")
        for (name in DataEntry.METHOD_NAMES) {
            sb.append("|${name}_tahmin|${name}_dogru|${name}_basari|${name}_aktif|${name}_guven")
        }
        sb.append("\n")
        return sb.toString()
    }

    fun ensureFileExists() {
        if (!csvFile.exists()) { csvFile.createNewFile(); csvFile.writeText(header) }
    }

    fun appendEntry(entry: DataEntry) {
        ensureFileExists()
        FileWriter(csvFile, true).use { it.append(entryToLine(entry)).append("\n") }
        synchronized(this) {
            if (cachedEntries != null) cachedEntries!!.add(entry)
            cachedFileLength = csvFile.length()
        }
        // Python/Termux için Download kopyası (açıksa)
        syncToDownloadIfEnabled()
    }

    fun updateLastEntry(entry: DataEntry) {
        val lines = csvFile.readLines().toMutableList()
        if (lines.size < 2) return
        lines[lines.size - 1] = entryToLine(entry)
        csvFile.writeText(lines.joinToString("\n") + "\n")
        synchronized(this) {
            if (cachedEntries != null && cachedEntries!!.isNotEmpty()) {
                cachedEntries!![cachedEntries!!.size - 1] = entry
            }
            cachedFileLength = csvFile.length()
        }
        syncToDownloadIfEnabled()
    }

    fun readAllEntries(): List<DataEntry> {
        ensureFileExists()
        synchronized(this) {
            val currentLen = csvFile.length()
            if (cachedEntries != null && cachedFileLength == currentLen) {
                return cachedEntries!!
            }
            val lines = csvFile.readLines()
            val parsed = if (lines.size <= 1) mutableListOf()
            else lines.drop(1).filter { it.isNotBlank() }.mapNotNull { parseLine(it) }.toMutableList()
            cachedEntries = parsed
            cachedFileLength = currentLen
            return parsed
        }
    }

    fun invalidateCache() {
        synchronized(this) {
            cachedEntries = null
            cachedFileLength = -1L
        }
    }

    fun readValues(): List<Int> = readAllEntries().map { it.value }

    fun deleteLastEntry() {
        val lines = csvFile.readLines().toMutableList()
        if (lines.size <= 1) return
        lines.removeAt(lines.size - 1)
        csvFile.writeText(lines.joinToString("\n") + "\n")
        invalidateCache()
        syncToDownloadIfEnabled()
    }

    fun clearAll() {
        csvFile.writeText(header)
        invalidateCache()
        syncToDownloadIfEnabled()
    }

    fun exportFile(): File = csvFile
    fun getTotalCount(): Int = readAllEntries().size

    /** İçerideki CSV'nin tam metni (public klasör senkronu ve import için). */
    fun readFullText(): String { ensureFileExists(); return csvFile.readText() }

    /**
     * Veriyi dışarıdan (public klasörden veya importtan) içeriğine yaz.
     * Cache'i temizler.
     */
    fun writeFullText(content: String) {
        csvFile.writeText(content)
        invalidateCache()
    }

    /**
     * CSV'nin güncel kopyasını Download/FAN/fan_data.csv'ye yazar.
     * Tüm Download klasörü yollarını dener (cihaz/ROM farklılıkları için).
     */
    fun syncToDownload(ctx: Context): Boolean {
        return try {
            ensureFileExists()
            PythonBridge.syncDataToPublicFolder(ctx, csvFile.readText())
        } catch (e: Exception) { false }
    }

    private fun syncToDownloadIfEnabled() {
        try {
            val sp = context.getSharedPreferences("fan_settings", Context.MODE_PRIVATE)
            if (sp.getBoolean("csv_download_sync", true)) { // v8.0: varsayılan AÇIK
                syncToDownload(context)
            }
        } catch (_: Exception) {}
    }


    /**
     * Returns (primary hits, any-hits, total evaluated).
     * v7.2: filtre yok; tüm tahminler değerlendirilir.
     */
    fun getEnsembleStats(): Triple<Int, Int, Int> {
        val entries = readAllEntries().drop(50)
        if (entries.isEmpty()) return Triple(0, 0, 0)
        var primary = 0; var total = 0
        for (e in entries) {
            if (e.ensemblePrediction == 0 && !e.ensembleIsDouble) continue  // çok eski/boş kayıt
            if (e.ensembleCorrect) primary++
            if (e.ensembleCorrect || e.ensembleSecCorrect) total++
        }
        return Triple(primary, total, entries.size)
    }

    fun getMethodStats(): List<Triple<String, Int, Int>> {
        val entries = readAllEntries().drop(50)
        if (entries.isEmpty()) return emptyList()
        return (0 until DataEntry.METHOD_COUNT).map { i ->
            val name = DataEntry.METHOD_NAMES[i].replace("_", " ")
            val active = entries.filter { getMethodActive(it, i) }
            val correct = active.count { getMethodCorrect(it, i) }
            Triple(name, correct, if (active.isNotEmpty()) active.size else entries.size)
        }.sortedByDescending { if (it.third > 0) it.second.toDouble() / it.third else 0.0 }
    }

    private fun getMethodCorrect(e: DataEntry, i: Int): Boolean = when (i) {
        0->e.method1Correct; 1->e.method2Correct; 2->e.method3Correct; 3->e.method4Correct
        4->e.method5Correct; 5->e.method6Correct; 6->e.method7Correct; 7->e.method8Correct
        8->e.method9Correct; 9->e.method10Correct; 10->e.method11Correct; 11->e.method12Correct
        12->e.method13Correct; else->false
    }

    private fun getMethodActive(e: DataEntry, i: Int): Boolean = when (i) {
        0->e.method1Active; 1->e.method2Active; 2->e.method3Active; 3->e.method4Active
        4->e.method5Active; 5->e.method6Active; 6->e.method7Active; 7->e.method8Active
        8->e.method9Active; 9->e.method10Active; 10->e.method11Active; 11->e.method12Active
        12->e.method13Active; else->true
    }

    private fun entryToLine(e: DataEntry): String {
        val sb = StringBuilder()
        val ensTahmin = when (e.ensembleTier) {
            "DOUBLE" -> if (e.ensembleSecondary > 0) "${e.ensemblePrediction}/${e.ensembleSecondary}" else "${e.ensemblePrediction}"
            else /* SINGLE */ -> "${e.ensemblePrediction}"
        }
        val kombTahmin = "0"
        val kalipTahmin = if (e.kalipSecondary > 0) "${e.kalipPrediction}/${e.kalipSecondary}" else "${e.kalipPrediction}"

        sb.append("${e.id}|${dateFormat.format(Date(e.timestamp))}|${e.value}")
        // Ensemble + ensemble_guven
        sb.append("|$ensTahmin|${d(e.ensembleCorrect)}|${p(e.ensembleTotalAccuracy)}|${p(e.ensembleAccuracy)}|${d(e.ensembleSecCorrect)}|${p(e.ensembleSecAccuracy)}|${p(e.ensembleConfidence)}")
        // Kombine (compat)
        sb.append("|$kombTahmin|HAYIR|%0|HAYIR|%0")
        // Kalip + kalip_guven
        sb.append("|$kalipTahmin|${d(e.kalipCorrect)}|${p(e.kalipAccuracy)}|${p(e.kalipConfidence)}")
        // Yan + yan_guven
        sb.append("|${e.sidePrediction}|${d(e.sideCorrect)}|${p(e.sideAccuracy)}|${p(e.sideConfidence)}")
        // Rejim/meta_guven
        sb.append("|${e.currentRegime}|${e.detectedPattern}|${e.regimeSequence}|${e.anomalyFlags}|${d(e.confidenceAdjusted)}|${p(e.metaConfidence)}")
        // 13 yöntem: her biri için tahmin|doğru|başarı|aktif|güven
        sb.append("|${e.method1Prediction}|${d(e.method1Correct)}|${p(e.method1Accuracy)}|${d(e.method1Active)}|${p(e.conf1)}")
        sb.append("|${e.method2Prediction}|${d(e.method2Correct)}|${p(e.method2Accuracy)}|${d(e.method2Active)}|${p(e.conf2)}")
        sb.append("|${e.method3Prediction}|${d(e.method3Correct)}|${p(e.method3Accuracy)}|${d(e.method3Active)}|${p(e.conf3)}")
        sb.append("|${e.method4Prediction}|${d(e.method4Correct)}|${p(e.method4Accuracy)}|${d(e.method4Active)}|${p(e.conf4)}")
        sb.append("|${e.method5Prediction}|${d(e.method5Correct)}|${p(e.method5Accuracy)}|${d(e.method5Active)}|${p(e.conf5)}")
        sb.append("|${e.method6Prediction}|${d(e.method6Correct)}|${p(e.method6Accuracy)}|${d(e.method6Active)}|${p(e.conf6)}")
        sb.append("|${e.method7Prediction}|${d(e.method7Correct)}|${p(e.method7Accuracy)}|${d(e.method7Active)}|${p(e.conf7)}")
        sb.append("|${e.method8Prediction}|${d(e.method8Correct)}|${p(e.method8Accuracy)}|${d(e.method8Active)}|${p(e.conf8)}")
        sb.append("|${e.method9Prediction}|${d(e.method9Correct)}|${p(e.method9Accuracy)}|${d(e.method9Active)}|${p(e.conf9)}")
        sb.append("|${e.method10Prediction}|${d(e.method10Correct)}|${p(e.method10Accuracy)}|${d(e.method10Active)}|${p(e.conf10)}")
        sb.append("|${e.method11Prediction}|${d(e.method11Correct)}|${p(e.method11Accuracy)}|${d(e.method11Active)}|${p(e.conf11)}")
        sb.append("|${e.method12Prediction}|${d(e.method12Correct)}|${p(e.method12Accuracy)}|${d(e.method12Active)}|${p(e.conf12)}")
        sb.append("|${e.method13Prediction}|${d(e.method13Correct)}|${p(e.method13Accuracy)}|${d(e.method13Active)}|${p(e.conf13)}")
        return sb.toString()
    }

    private fun parseLine(line: String): DataEntry? {
        return try {
            val c = line.split("|")
            if (c.size < 10) return null
            // Format algılama: eski formatta ens_guven (index 9) yok → ensemble 3-8, kombine 9-13...
            // Yeni formatta ensemble 3-9 (10 alan), kombine 10-14, kalip 15-18, yan 19-22, rejim/meta 23-28,
            // sonra 13 yöntem: her biri 5 alan (tahmin,doğru,başarı,aktif,güven) → 13*5=65, toplam 28+65=93+
            // Eski formattaysa tahminen 77 kolondur (yöntemler 4 alan → 13*4=52, toplam 25+52=77).
            val isNewFormat = c.size >= 90
            val ensRaw = c.getOrNull(3)?.trim() ?: "0"
            val (ensPri, ensSec) = parseTahmin(ensRaw.let { if (it == "--") "0" else it })
            val ensIsDouble = ensSec > 0
            val ensTier = if (ensIsDouble) "DOUBLE" else if (ensPri > 0) "SINGLE" else "DOUBLE"
            // Kombine
            parseTahmin(c.getOrNull(if (isNewFormat) 10 else 9) ?: "0")
            val kalipIdx = if (isNewFormat) 15 else 14
            val (kalipPri, kalipSec) = parseTahmin(c.getOrNull(kalipIdx) ?: "0")
            val sideIdx = if (isNewFormat) 19 else 17
            val metaIdx = if (isNewFormat) 28 else c.size - 1
            // Method blok başlangıcı
            val methodBase = if (isNewFormat) 29 else 25
            val methodStride = if (isNewFormat) 5 else 4

            DataEntry(
                id = c[0].trim().toLongOrNull() ?: 0,
                timestamp = try { dateFormat.parse(c[1].trim())?.time ?: 0 } catch (e: Exception) { 0 },
                value = c[2].trim().toIntOrNull() ?: return null,
                ensemblePrediction    = ensPri,
                ensembleSecondary     = ensSec,
                ensembleIsDouble      = ensIsDouble,
                ensembleTier          = ensTier,
                ensembleCorrect       = pb(c.getOrNull(4)),
                ensembleTotalAccuracy = pp(c.getOrNull(5)),
                ensembleAccuracy      = pp(c.getOrNull(6)),
                ensembleSecCorrect    = pb(c.getOrNull(7)),
                ensembleSecAccuracy   = pp(c.getOrNull(8)),
                ensembleConfidence    = if (isNewFormat) pp(c.getOrNull(9)) else pp(c.getOrNull(6)),
                kalipPrediction       = kalipPri,
                kalipSecondary        = kalipSec,
                kalipIsDouble         = kalipSec > 0,
                kalipCorrect          = pb(c.getOrNull(kalipIdx+1)),
                kalipAccuracy         = pp(c.getOrNull(kalipIdx+2)),
                kalipConfidence       = if (isNewFormat) pp(c.getOrNull(kalipIdx+3)) else 0.0,
                sidePrediction        = c.getOrNull(sideIdx)?.trim() ?: "",
                sideCorrect           = pb(c.getOrNull(sideIdx+1)),
                sideAccuracy          = pp(c.getOrNull(sideIdx+2)),
                sideConfidence        = if (isNewFormat) pp(c.getOrNull(sideIdx+3)) else 0.0,
                currentRegime         = c.getOrNull(if (isNewFormat) 23 else 20)?.trim() ?: "KAOS",
                detectedPattern       = c.getOrNull(if (isNewFormat) 24 else 21)?.trim() ?: "NONE",
                regimeSequence        = c.getOrNull(if (isNewFormat) 25 else 22)?.trim() ?: "",
                anomalyFlags          = c.getOrNull(if (isNewFormat) 26 else 23)?.trim() ?: "",
                confidenceAdjusted    = pb(c.getOrNull(if (isNewFormat) 27 else 24)),
                metaConfidence        = if (isNewFormat) pp(c.getOrNull(28)) else 0.0,
                method1Prediction  = c.getOrNull(methodBase+0)?.trim()?.toIntOrNull() ?: 0,
                method1Correct     = pb(c.getOrNull(methodBase+1)),
                method1Accuracy    = pp(c.getOrNull(methodBase+2)),
                method1Active      = pb2(c.getOrNull(methodBase+3)),
                conf1              = if (isNewFormat) pp(c.getOrNull(methodBase+4)) else 0.0,
                method2Prediction  = c.getOrNull(methodBase+methodStride+0)?.trim()?.toIntOrNull() ?: 0,
                method2Correct     = pb(c.getOrNull(methodBase+methodStride+1)),
                method2Accuracy    = pp(c.getOrNull(methodBase+methodStride+2)),
                method2Active      = pb2(c.getOrNull(methodBase+methodStride+3)),
                conf2              = if (isNewFormat) pp(c.getOrNull(methodBase+methodStride+4)) else 0.0,
                method3Prediction  = c.getOrNull(methodBase+2*methodStride+0)?.trim()?.toIntOrNull() ?: 0,
                method3Correct     = pb(c.getOrNull(methodBase+2*methodStride+1)),
                method3Accuracy    = pp(c.getOrNull(methodBase+2*methodStride+2)),
                method3Active      = pb2(c.getOrNull(methodBase+2*methodStride+3)),
                conf3              = if (isNewFormat) pp(c.getOrNull(methodBase+2*methodStride+4)) else 0.0,
                method4Prediction  = c.getOrNull(methodBase+3*methodStride+0)?.trim()?.toIntOrNull() ?: 0,
                method4Correct     = pb(c.getOrNull(methodBase+3*methodStride+1)),
                method4Accuracy    = pp(c.getOrNull(methodBase+3*methodStride+2)),
                method4Active      = pb2(c.getOrNull(methodBase+3*methodStride+3)),
                conf4              = if (isNewFormat) pp(c.getOrNull(methodBase+3*methodStride+4)) else 0.0,
                method5Prediction  = c.getOrNull(methodBase+4*methodStride+0)?.trim()?.toIntOrNull() ?: 0,
                method5Correct     = pb(c.getOrNull(methodBase+4*methodStride+1)),
                method5Accuracy    = pp(c.getOrNull(methodBase+4*methodStride+2)),
                method5Active      = pb2(c.getOrNull(methodBase+4*methodStride+3)),
                conf5              = if (isNewFormat) pp(c.getOrNull(methodBase+4*methodStride+4)) else 0.0,
                method6Prediction  = c.getOrNull(methodBase+5*methodStride+0)?.trim()?.toIntOrNull() ?: 0,
                method6Correct     = pb(c.getOrNull(methodBase+5*methodStride+1)),
                method6Accuracy    = pp(c.getOrNull(methodBase+5*methodStride+2)),
                method6Active      = pb2(c.getOrNull(methodBase+5*methodStride+3)),
                conf6              = if (isNewFormat) pp(c.getOrNull(methodBase+5*methodStride+4)) else 0.0,
                method7Prediction  = c.getOrNull(methodBase+6*methodStride+0)?.trim()?.toIntOrNull() ?: 0,
                method7Correct     = pb(c.getOrNull(methodBase+6*methodStride+1)),
                method7Accuracy    = pp(c.getOrNull(methodBase+6*methodStride+2)),
                method7Active      = pb2(c.getOrNull(methodBase+6*methodStride+3)),
                conf7              = if (isNewFormat) pp(c.getOrNull(methodBase+6*methodStride+4)) else 0.0,
                method8Prediction  = c.getOrNull(methodBase+7*methodStride+0)?.trim()?.toIntOrNull() ?: 0,
                method8Correct     = pb(c.getOrNull(methodBase+7*methodStride+1)),
                method8Accuracy    = pp(c.getOrNull(methodBase+7*methodStride+2)),
                method8Active      = pb2(c.getOrNull(methodBase+7*methodStride+3)),
                conf8              = if (isNewFormat) pp(c.getOrNull(methodBase+7*methodStride+4)) else 0.0,
                method9Prediction  = c.getOrNull(methodBase+8*methodStride+0)?.trim()?.toIntOrNull() ?: 0,
                method9Correct     = pb(c.getOrNull(methodBase+8*methodStride+1)),
                method9Accuracy    = pp(c.getOrNull(methodBase+8*methodStride+2)),
                method9Active      = pb2(c.getOrNull(methodBase+8*methodStride+3)),
                conf9              = if (isNewFormat) pp(c.getOrNull(methodBase+8*methodStride+4)) else 0.0,
                method10Prediction = c.getOrNull(methodBase+9*methodStride+0)?.trim()?.toIntOrNull() ?: 0,
                method10Correct    = pb(c.getOrNull(methodBase+9*methodStride+1)),
                method10Accuracy   = pp(c.getOrNull(methodBase+9*methodStride+2)),
                method10Active     = pb2(c.getOrNull(methodBase+9*methodStride+3)),
                conf10             = if (isNewFormat) pp(c.getOrNull(methodBase+9*methodStride+4)) else 0.0,
                method11Prediction = c.getOrNull(methodBase+10*methodStride+0)?.trim()?.toIntOrNull() ?: 0,
                method11Correct    = pb(c.getOrNull(methodBase+10*methodStride+1)),
                method11Accuracy   = pp(c.getOrNull(methodBase+10*methodStride+2)),
                method11Active     = pb2(c.getOrNull(methodBase+10*methodStride+3)),
                conf11             = if (isNewFormat) pp(c.getOrNull(methodBase+10*methodStride+4)) else 0.0,
                method12Prediction = c.getOrNull(methodBase+11*methodStride+0)?.trim()?.toIntOrNull() ?: 0,
                method12Correct    = pb(c.getOrNull(methodBase+11*methodStride+1)),
                method12Accuracy   = pp(c.getOrNull(methodBase+11*methodStride+2)),
                method12Active     = pb2(c.getOrNull(methodBase+11*methodStride+3)),
                conf12             = if (isNewFormat) pp(c.getOrNull(methodBase+11*methodStride+4)) else 0.0,
                method13Prediction = c.getOrNull(methodBase+12*methodStride+0)?.trim()?.toIntOrNull() ?: 0,
                method13Correct    = pb(c.getOrNull(methodBase+12*methodStride+1)),
                method13Accuracy   = pp(c.getOrNull(methodBase+12*methodStride+2)),
                method13Active     = pb2(c.getOrNull(methodBase+12*methodStride+3)),
                conf13             = if (isNewFormat) pp(c.getOrNull(methodBase+12*methodStride+4)) else 0.0
            )
        } catch (e: Exception) { null }
    }

    private fun parseTahmin(s: String): Pair<Int, Int> {
        val t = s.trim()
        return if ("/" in t) {
            val p = t.split("/")
            (p[0].toIntOrNull() ?: 0) to (p[1].toIntOrNull() ?: 0)
        } else (t.toIntOrNull() ?: 0) to 0
    }

    private fun pb(v: String?): Boolean = v?.trim()?.uppercase().let { it == "EVET" || it == "1" || it == "TRUE" }
    private fun pb2(v: String?): Boolean = v?.trim()?.uppercase()?.let { it == "EVET" || it == "1" || it == "TRUE" } ?: true
    private fun pp(v: String?): Double = v?.trim()?.removeSuffix("%")?.toDoubleOrNull()?.div(100.0) ?: 0.0
    private fun d(v: Boolean): String = if (v) "EVET" else "HAYIR"
    private fun p(v: Double): String = String.format(Locale.US, "%%%d", (v * 100).toInt())
}
