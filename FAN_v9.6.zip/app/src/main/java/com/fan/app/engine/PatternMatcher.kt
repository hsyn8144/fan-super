package com.fan.app.engine

import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.abs

object PatternMatcher {

    // v7.1: max matches artırıldı (alt patternlerle birlikte çok eşleşme olabilir)
    private const val MAX_MATCHES = 30

    // v7.1: Maks pattern uzunluğu dinamik
    const val MAX_PATTERN_LENGTH_HARDCAP = 25
    const val MAX_SEARCH_WINDOW = 2000
    private const val PATTERN_WEIGHT_SCALE = 12.0  // uzunluk başına ağırlık ölçeği

    data class PatternMatch(
        val patternLength: Int,
        val matchPositions: List<Int>,
        val contextBefore: List<List<Int>>,
        val contextAfter: List<List<Int>>
    )

    data class VoteResult(
        val votes: Map<Int, Double>,
        val confidence: Double,
        val topPrediction: Int,
        val secondPrediction: Int
    )

    /**
     * v7.1: Veri sayısına göre dinamik max pattern uzunluğu
     *   0-50  → 10
     *   51-100 → 15
     *   101-150 → 25
     *   151+ → 25
     */
    fun maxPatternLength(dataSize: Int): Int = when {
        dataSize <= 50 -> 10
        dataSize <= 100 -> 15
        else -> MAX_PATTERN_LENGTH_HARDCAP
    }

    /**
     * v7.1: Recency factor daha keskin — yeni veriler ~3x daha ağırlıklı
     * (d/ts ~0.05 gibi yeni verilerde factor ≈0.90, eski verilerde 0.15-0.20 civarı)
     */
    fun recencyFactor(distance: Int, totalSize: Int): Double {
        if (totalSize <= 1) return 1.0
        val normalized = distance.toDouble() / totalSize.toDouble()
        return exp(-3.0 * normalized)  // v2.x'de 2.0 idi
    }

    /**
     * Ana pattern bulucu (ensemble'ın kalıp arama için kullandığı).
     * En uzundan kısaya doğru arar; bulunan her uzunluk için sonuç döndürür.
     * v7.1: Arama penceresi 2000, max uzunluk dinamik.
     */
    fun findPatterns(data: List<Int>): List<PatternMatch> {
        if (data.size < 2) return emptyList()
        val results = mutableListOf<PatternMatch>()
        val dataLen = data.size
        val maxLen = minOf(maxPatternLength(dataLen), dataLen - 1)

        for (len in maxLen downTo 2) {
            val pattern = data.takeLast(len)
            // Son MAX_SEARCH_WINDOW giriş içinde ara
            val searchWindow = data.dropLast(len).takeLast(MAX_SEARCH_WINDOW)
            val matches = findPatternInHistory(searchWindow, pattern)
            val limitedMatches = if (matches.size > MAX_MATCHES)
                matches.takeLast(MAX_MATCHES) else matches
            if (limitedMatches.isNotEmpty()) {
                val offset = data.size - len - searchWindow.size
                val absolutePositions = limitedMatches.map { it + offset }
                val contextBefore = absolutePositions.map { pos ->
                    val start = maxOf(0, pos - 8)
                    data.subList(start, pos)
                }
                val contextAfter = absolutePositions.map { pos ->
                    val end = minOf(data.size - len, pos + len)
                    val afterEnd = minOf(data.size - len, end + 8)
                    if (end < data.size - len) data.subList(end, minOf(afterEnd, data.size - len))
                    else emptyList()
                }
                results.add(PatternMatch(len, absolutePositions, contextBefore, contextAfter))
            }
        }
        return results
    }

    private fun findPatternInHistory(history: List<Int>, pattern: List<Int>): List<Int> {
        if (history.size < pattern.size) return emptyList()
        val positions = mutableListOf<Int>()
        for (i in 0..history.size - pattern.size) {
            if (history.subList(i, i + pattern.size) == pattern) {
                positions.add(i)
            }
        }
        return positions
    }

    fun analyzePatternVotes(
        data: List<Int>,
        patterns: List<PatternMatch>,
        recencyWeight: Boolean = true
    ): VoteResult {
        val votes = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)
        val dataSize = data.size
        val maxLen = patterns.maxOfOrNull { it.patternLength } ?: 10

        for (match in patterns) {
            // v7.1: Uzun pattern bonusu (n/12 temel + ekstra uzunluk bonusu)
            val baseW = match.patternLength.toDouble() / PATTERN_WEIGHT_SCALE
            // 10+ uzun patternler için ekstra 1.5x çarpan
            val lengthBonus = if (match.patternLength >= 10) 1.5 else if (match.patternLength >= 6) 1.2 else 1.0
            val weight = baseW * lengthBonus
            for ((idx, pos) in match.matchPositions.withIndex()) {
                val afterPos = pos + match.patternLength
                if (afterPos < dataSize - match.patternLength) {
                    val nextVal = data[afterPos]
                    if (nextVal in 1..4) {
                        val recency = if (recencyWeight) recencyFactor(dataSize - afterPos, dataSize) else 1.0
                        votes[nextVal] = (votes[nextVal] ?: 0.0) + weight * recency
                        // En yeni eşleşmeye proximity bonus
                        val proximityWeight = 1.5 / (idx + 1)  // v2.3'te 1.0 idi
                        votes[nextVal] = (votes[nextVal] ?: 0.0) + proximityWeight * recency * 0.6
                    }
                }
            }
        }

        val total = votes.values.sum()
        if (total == 0.0) return VoteResult(
            mapOf(1 to 0.25, 2 to 0.25, 3 to 0.25, 4 to 0.25),
            0.25, 1, 2
        )

        val normalized = votes.mapValues { it.value / total }
        val sorted = normalized.entries.sortedByDescending { it.value }

        return VoteResult(
            votes = normalized,
            confidence = sorted[0].value,
            topPrediction = sorted[0].key,
            secondPrediction = sorted.getOrNull(1)?.key ?: sorted[0].key
        )
    }

    fun behaviorAnalysis(
        data: List<Int>,
        patterns: List<PatternMatch>
    ): Map<Int, Double> {
        val votes = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)
        if (patterns.isEmpty()) return votes

        val bestPattern = patterns.maxByOrNull { it.patternLength * it.matchPositions.size } ?: return votes

        for (pos in bestPattern.matchPositions) {
            val afterPos = pos + bestPattern.patternLength
            if (afterPos >= data.size - bestPattern.patternLength) continue

            val historicalNext = data.subList(afterPos, minOf(afterPos + 8, data.size - bestPattern.patternLength))
            val currentPrev = data.subList(maxOf(0, data.size - bestPattern.patternLength - 8), data.size - bestPattern.patternLength)

            val similarity = computeSequenceSimilarity(historicalNext, currentPrev)

            if (afterPos < data.size - bestPattern.patternLength) {
                val predictedNext = data[afterPos]
                if (predictedNext in 1..4) {
                    votes[predictedNext] = (votes[predictedNext] ?: 0.0) + similarity
                }
            }
        }

        val total = votes.values.sum()
        if (total == 0.0) return votes
        return votes.mapValues { it.value / total }
    }

    private fun computeSequenceSimilarity(seq1: List<Int>, seq2: List<Int>): Double {
        if (seq1.isEmpty() || seq2.isEmpty()) return 0.5
        val minLen = minOf(seq1.size, seq2.size)
        var score = 0.0
        for (i in 0 until minLen) {
            val diff = abs(seq1[i] - seq2[i])
            score += when (diff) {
                0 -> 1.0
                1 -> 0.7
                2 -> 0.4
                else -> 0.1
            }
        }
        return score / minLen
    }

    fun computeDeltaPattern(data: List<Int>): List<Int> {
        if (data.size < 2) return emptyList()
        return data.zipWithNext { a, b ->
            val delta = b - a
            when {
                delta > 3 -> delta - 4
                delta < -3 -> delta + 4
                else -> delta
            }
        }
    }

    fun findDeltaPatternVotes(data: List<Int>): Map<Int, Double> {
        val deltas = computeDeltaPattern(data)
        if (deltas.size < 4) return mapOf(1 to 0.25, 2 to 0.25, 3 to 0.25, 4 to 0.25)

        val votes = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)
        val maxLen = minOf(10, deltas.size - 1)
        val lastVal = data.last()

        for (len in maxLen downTo 2) {
            val deltaPattern = deltas.takeLast(len)
            for (i in 0..deltas.size - len - 1) {
                if (deltas.subList(i, i + len) == deltaPattern) {
                    val nextDelta = deltas[i + len]
                    val predictedVal = ((lastVal - 1 + nextDelta).mod(4)) + 1
                    if (predictedVal in 1..4) {
                        val weight = len.toDouble() / 10.0
                        val recency = recencyFactor(deltas.size - i, deltas.size)
                        votes[predictedVal] = (votes[predictedVal] ?: 0.0) + weight * recency
                    }
                }
            }
        }

        val total = votes.values.sum()
        if (total == 0.0) return mapOf(1 to 0.25, 2 to 0.25, 3 to 0.25, 4 to 0.25)
        return votes.mapValues { it.value / total }
    }

    fun findMirrorPatternVotes(data: List<Int>): Map<Int, Double> {
        val votes = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)
        val maxLen = minOf(10, data.size - 1)

        for (len in maxLen downTo 2) {
            val pattern = data.takeLast(len)
            val reversedPattern = pattern.reversed()
            val history = data.dropLast(len).takeLast(MAX_SEARCH_WINDOW)

            for (i in 0..history.size - len) {
                if (history.subList(i, i + len) == reversedPattern) {
                    val afterPos = i + len
                    if (afterPos < history.size) {
                        val nextVal = history[afterPos]
                        if (nextVal in 1..4) {
                            val weight = (len.toDouble() / 10.0) * 0.5
                            val recency = recencyFactor(history.size - afterPos, history.size)
                            votes[nextVal] = (votes[nextVal] ?: 0.0) + weight * recency
                        }
                    }
                }
            }
        }

        val total = votes.values.sum()
        if (total == 0.0) return mapOf(1 to 0.25, 2 to 0.25, 3 to 0.25, 4 to 0.25)
        return votes.mapValues { it.value / total }
    }

    fun findPermutationVotes(data: List<Int>): Map<Int, Double> {
        if (data.size < 7) return mapOf(1 to 0.25, 2 to 0.25, 3 to 0.25, 4 to 0.25)

        val votes = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)
        val last6 = data.takeLast(6)
        val last6Sorted = last6.sorted()
        val history = data.dropLast(6).takeLast(MAX_SEARCH_WINDOW)

        for (i in 0..history.size - 6) {
            val window = history.subList(i, i + 6)
            val windowSorted = window.sorted()

            if (windowSorted == last6Sorted) {
                val afterPos = i + 6
                if (afterPos < history.size) {
                    val nextVal = history[afterPos]
                    if (nextVal in 1..4) {
                        val recency = recencyFactor(history.size - afterPos, history.size)
                        val reversedWindow = window.reversed()
                        val similarity = if (reversedWindow == last6) 1.5 else 1.0
                        votes[nextVal] = (votes[nextVal] ?: 0.0) + recency * similarity
                    }
                }
            }
        }

        val total = votes.values.sum()
        if (total == 0.0) return mapOf(1 to 0.25, 2 to 0.25, 3 to 0.25, 4 to 0.25)
        return votes.mapValues { it.value / total }
    }

    fun findPhaseShiftVotes(data: List<Int>): Map<Int, Double> {
        val votes = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)
        val maxLen = minOf(10, data.size - 1)

        for (shift in 1..3) {
            for (len in maxLen downTo 2) {
                if (data.size < len + shift) continue
                val pattern = data.takeLast(len)
                val history = data.dropLast(len + shift).takeLast(MAX_SEARCH_WINDOW)

                for (i in 0..history.size - len) {
                    if (history.subList(i, i + len) == pattern) {
                        val afterPos = i + len + shift
                        if (afterPos < history.size) {
                            val nextVal = history[afterPos]
                            if (nextVal in 1..4) {
                                val weight = (len.toDouble() / 10.0) * (1.0 / shift)
                                val recency = recencyFactor(history.size - afterPos, history.size)
                                votes[nextVal] = (votes[nextVal] ?: 0.0) + weight * recency
                            }
                        }
                    }
                }
            }
        }

        val total = votes.values.sum()
        if (total == 0.0) return mapOf(1 to 0.25, 2 to 0.25, 3 to 0.25, 4 to 0.25)
        return votes.mapValues { it.value / total }
    }

    fun findMosaicPatternVotes(data: List<Int>): Map<Int, Double> {
        val votes = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)
        if (data.size < 20) return mapOf(1 to 0.25, 2 to 0.25, 3 to 0.25, 4 to 0.25)

        for (blockSize in 2..10) {
            if (data.size < blockSize * 3) continue
            val numBlocks = data.size / blockSize
            val blocks = (0 until numBlocks).map { i ->
                data.subList(i * blockSize, (i + 1) * blockSize)
            }
            val lastBlock = data.takeLast(blockSize)

            for (col in 0 until blockSize) {
                val colValues = blocks.map { it[col] }
                val lastColVal = lastBlock[col]

                for (len in minOf(8, colValues.size - 1) downTo 2) {
                    val pattern = colValues.takeLast(len)
                    for (i in 0..colValues.size - len - 1) {
                        if (colValues.subList(i, i + len) == pattern) {
                            val nextVal = colValues[i + len]
                            if (nextVal in 1..4) {
                                val weight = (len.toDouble() / 10.0) / blockSize
                                val recency = recencyFactor(colValues.size - i, colValues.size)
                                votes[nextVal] = (votes[nextVal] ?: 0.0) + weight * recency
                            }
                        }
                    }
                }
            }
        }

        val total = votes.values.sum()
        if (total == 0.0) return mapOf(1 to 0.25, 2 to 0.25, 3 to 0.25, 4 to 0.25)
        return votes.mapValues { it.value / total }
    }
}
