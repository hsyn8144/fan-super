package com.fan.app.engine

class QLearningEngine {

    private val qTable = mutableMapOf<String, MutableMap<Int, Double>>()
    private val learningRate = 0.15
    private val discountFactor = 0.85
    private val epsilon = 0.08
    private var trainedUpTo = 0

    fun compute(data: List<Int>): Map<Int, Double> {
        if (data.size < 5) return equal()

        // Incremental training on new data only
        if (trainedUpTo < data.size - 1) {
            val startTrain = maxOf(3, trainedUpTo)
            for (i in startTrain until data.size - 1) {
                val state = getState(data.subList(0, i + 1))
                val action = data[i + 1]
                val nextState = getState(data.subList(0, i + 2))

                // Reward is +1 for correct prediction, -0.3 for wrong prediction,
                // but during offline training we compute retrospective reward:
                // if this action matched the eventual next value → reward = 1
                val reward = 1.0  // action == data[i+1] (by construction) → correct

                val currentQ = qTable.getOrPut(state) { mutableMapOf(1 to 0.5, 2 to 0.5, 3 to 0.5, 4 to 0.5) }
                val nextQ = qTable.getOrPut(nextState) { mutableMapOf(1 to 0.5, 2 to 0.5, 3 to 0.5, 4 to 0.5) }
                val maxNextQ = nextQ.values.maxOrNull() ?: 0.5

                val oldQ = currentQ[action] ?: 0.5
                currentQ[action] = oldQ + learningRate * (reward + discountFactor * maxNextQ - oldQ)

                // Slight penalty to actions not taken (Q-value decay toward baseline)
                for (a in 1..4) {
                    if (a != action) {
                        currentQ[a] = (currentQ[a] ?: 0.5) * 0.995
                    }
                }
            }
            trainedUpTo = data.size - 1
        }

        val state = getState(data)
        val qValues = qTable[state] ?: return equal()

        // Convert Q values to probability distribution using softmax with temperature
        val temperature = 0.3
        val shifted = qValues.mapValues { kotlin.math.exp((it.value - 0.5) / temperature) }
        val total = shifted.values.sum().coerceAtLeast(1e-9)
        return shifted.mapValues { it.value / total }
    }

    private fun getState(data: List<Int>): String {
        val last3 = data.takeLast(3).joinToString("")
        val streak = run {
            var s = 1
            val last = data.last()
            for (i in data.size - 2 downTo 0) {
                if (data[i] == last) s++ else break
            }
            minOf(s, 4)
        }
        val delta = if (data.size >= 2)
            Integer.signum(data.last() - data[data.size - 2]) + 1
        else 1
        val parity = data.last() % 2  // extra feature: odd/even of last
        val half = if (data.last() <= 2) 0 else 1  // small/big
        return "${last3}_${streak}_${delta}_${parity}_${half}"
    }

    fun reset() {
        qTable.clear()
        trainedUpTo = 0
    }

    private fun equal() = mapOf(1 to 0.25, 2 to 0.25, 3 to 0.25, 4 to 0.25)
}
