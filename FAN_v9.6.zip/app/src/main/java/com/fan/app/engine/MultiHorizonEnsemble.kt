package com.fan.app.engine

import com.fan.app.data.DataEntry

object MultiHorizonEnsemble {

    data class HorizonPrediction(
        val name: String,
        val windowSize: Int,
        val prediction: HorizonResult,
        val weight: Double,
        val confidence: Double
    )

    data class HorizonResult(
        val finalPrediction: Int,
        val secondPrediction: Int?,
        val confidence: Double,
        val showDouble: Boolean
    )

    data class MultiScaleResult(
        val finalPrediction: Int,
        val secondPrediction: Int?,
        val confidence: Double,
        val showDouble: Boolean,
        val horizonBreakdown: List<HorizonPrediction>,
        val consensusType: String,
        val regimeTransitionWarning: Boolean
    )

    /**
     * Her horizon için taze (state'siz) tahminciler kullan — farklı pencere
     * boyutları arasında state sızıntısı olmasın.
     */
    private fun computeHorizonResult(
        data: List<Int>,
        pastEntries: List<DataEntry>
    ): HorizonResult {
        if (data.size < 2) {
            return HorizonResult(1, 2, 0.25, true)
        }

        val votes = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)

        // 1) Frequency (recency-weighted)
        val freq = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)
        var fw = 0.0
        for ((i, v) in data.withIndex()) {
            if (v in 1..4) {
                val rec = PatternMatcher.recencyFactor(data.size - 1 - i, data.size)
                freq[v] = (freq[v] ?: 0.0) + rec
                fw += rec
            }
        }
        val expected = fw / 4.0
        for ((k, c) in freq) {
            votes[k] = (votes[k] ?: 0.0) + maxOf(0.0, expected - c) * 0.2
        }

        // 2) Regime analysis
        val regimeVotes = RegimeDetector.analyze(data).votes
        for ((k, v) in regimeVotes) {
            votes[k] = (votes[k] ?: 0.0) + v * 0.30
        }

        // 3) Pattern analysis
        val patterns = PatternMatcher.findPatterns(data)
        val patternResult = PatternMatcher.analyzePatternVotes(data, patterns)
        for ((k, v) in patternResult.votes) {
            votes[k] = (votes[k] ?: 0.0) + v * 0.25
        }

        // 4) Lightweight Markov (order-1, built from scratch on this window)
        val markovVotes = computeLightMarkov(data)
        for ((k, v) in markovVotes) votes[k] = (votes[k] ?: 0.0) + v * 0.30

        // 5) Streak-break signal
        val streakVotes = RegimeDetector.getStreakBreakVotes(data)
        for ((k, v) in streakVotes) votes[k] = (votes[k] ?: 0.0) + v * 0.15

        val sum = votes.values.sum()
        val normalized = if (sum > 0) votes.mapValues { it.value / sum }
        else mapOf(1 to 0.25, 2 to 0.25, 3 to 0.25, 4 to 0.25)

        val sorted = normalized.entries.sortedByDescending { it.value }
        val topConf = sorted[0].value
        val topPred = sorted[0].key
        val secondPred = sorted.getOrNull(1)?.key
        val margin = topConf - (sorted.getOrNull(1)?.value ?: 0.0)
        val showDouble = topConf < 0.55 || margin < 0.10

        return HorizonResult(topPred, secondPred, topConf, showDouble)
    }

    /** Build order-1 Markov directly (no persistent state, cheap) */
    private fun computeLightMarkov(data: List<Int>): Map<Int, Double> {
        if (data.size < 3) return mapOf(1 to 0.25, 2 to 0.25, 3 to 0.25, 4 to 0.25)
        val last = data.last()
        val counts = mutableMapOf(1 to 0.3, 2 to 0.3, 3 to 0.3, 4 to 0.3)
        var total = 1.2
        for (i in 0 until data.size - 1) {
            if (data[i] == last) {
                val nx = data[i + 1]
                if (nx in 1..4) {
                    val rec = PatternMatcher.recencyFactor(data.size - 1 - i, data.size)
                    counts[nx] = (counts[nx] ?: 0.3) + rec
                    total += rec
                }
            }
        }
        return counts.mapValues { it.value / total }
    }

    fun compute(data: List<Int>, pastEntries: List<DataEntry>): MultiScaleResult {
        if (data.size < 10) {
            val basic = computeHorizonResult(data, pastEntries)
            return MultiScaleResult(
                finalPrediction = basic.finalPrediction,
                secondPrediction = basic.secondPrediction,
                confidence = basic.confidence,
                showDouble = basic.showDouble,
                horizonBreakdown = emptyList(),
                consensusType = "INSUFFICIENT_DATA",
                regimeTransitionWarning = false
            )
        }

        val horizons = listOf(
            Triple(10, "ultra_short", 0.15),
            Triple(25, "short", 0.25),
            Triple(50, "medium", 0.25),
            Triple(100, "long", 0.20),
            Triple(data.size, "full", 0.15)
        )

        val horizonPredictions = horizons.map { (size, name, baseWeight) ->
            val windowData = data.takeLast(size)
            val prediction = computeHorizonResult(windowData, pastEntries)
            val recencyWeight = calculateRecencyWeight(size, data.size)
            val stabilityBonus = calculateStabilityBonus(windowData)
            HorizonPrediction(
                name = name,
                windowSize = size,
                prediction = prediction,
                weight = baseWeight * recencyWeight * stabilityBonus,
                confidence = prediction.confidence
            )
        }

        val consensus = analyzeConsensus(horizonPredictions)
        val regimeTransition = detectRegimeTransition(horizonPredictions, data)

        val resolved = if (consensus.hasConflict) {
            resolveConflict(horizonPredictions, data, consensus, regimeTransition)
        } else {
            ResolvedPrediction(
                prediction = consensus.dominantPrediction,
                confidence = consensus.confidence,
                second = null,
                reason = "Konsensüs var"
            )
        }

        val showDouble = shouldShowDouble(resolved, horizonPredictions)

        return MultiScaleResult(
            finalPrediction = resolved.prediction,
            secondPrediction = resolved.second,
            confidence = resolved.confidence,
            showDouble = showDouble,
            horizonBreakdown = horizonPredictions,
            consensusType = if (consensus.hasConflict) "CONFLICT_RESOLVED" else "STRONG_CONSENSUS",
            regimeTransitionWarning = regimeTransition.isTransitioning
        )
    }

    private fun calculateRecencyWeight(windowSize: Int, totalSize: Int): Double =
        1.0 + 0.5 * (windowSize.toDouble() / totalSize)

    private fun calculateStabilityBonus(data: List<Int>): Double {
        if (data.size < 20) return 1.0
        val regime = RegimeDetector.detectCurrentRegime(data)
        val entropy = RegimeDetector.computeBlockEntropy(data, minOf(data.size, 50))
        return when {
            regime == RegimeDetector.RegimeType.REGULAR && entropy < 0.7 -> 1.25
            regime == RegimeDetector.RegimeType.CHAOS && entropy > 0.8 -> 0.85
            else -> 1.0
        }
    }

    private fun analyzeConsensus(horizons: List<HorizonPrediction>): ConsensusAnalysis {
        val predictions = horizons.map { it.prediction.finalPrediction }
        val frequency = predictions.groupBy { it }.mapValues { it.value.size }
        val dominant = frequency.maxByOrNull { it.value }?.key ?: 1
        val dominantCount = frequency[dominant] ?: 0
        val hasConflict = dominantCount < (horizons.size * 0.6).toInt()
        val avgConfidence = horizons.map { it.confidence * it.weight }.average() / horizons.map { it.weight }.average()
        val confidenceVariance = horizons.map {
            val d = it.confidence - avgConfidence; d * d
        }.average()
        return ConsensusAnalysis(
            dominantPrediction = dominant,
            confidence = if (hasConflict) avgConfidence * 0.85 else avgConfidence,
            hasConflict = hasConflict,
            frequency = frequency,
            variance = confidenceVariance
        )
    }

    private fun detectRegimeTransition(
        horizons: List<HorizonPrediction>,
        data: List<Int>
    ): RegimeTransition {
        val shortTermRegime = RegimeDetector.detectCurrentRegime(data.takeLast(25))
        val longTermRegime = RegimeDetector.detectCurrentRegime(
            data.takeLast(minOf(100, data.size))
        )
        val isTransitioning = shortTermRegime != longTermRegime
        val direction = if (isTransitioning) {
            val shortPattern = RegimeDetector.detectPattern(data.takeLast(25))
            val longPattern = RegimeDetector.detectPattern(
                data.takeLast(minOf(100, data.size))
            )
            when {
                shortPattern.strength > longPattern.strength -> "STABILIZING"
                shortPattern.strength < longPattern.strength * 0.5 -> "DESTABILIZING"
                else -> "UNCERTAIN"
            }
        } else "STABLE"
        return RegimeTransition(isTransitioning, shortTermRegime, longTermRegime, direction)
    }

    private fun resolveConflict(
        horizons: List<HorizonPrediction>,
        data: List<Int>,
        consensus: ConsensusAnalysis,
        transition: RegimeTransition
    ): ResolvedPrediction {
        val shortTerm = horizons.firstOrNull { it.name == "short" } ?: horizons.first()
        val longTerm = horizons.firstOrNull { it.name == "long" } ?: horizons.last()
        return when {
            transition.isTransitioning && transition.direction == "DESTABILIZING" ->
                ResolvedPrediction(
                    shortTerm.prediction.finalPrediction,
                    shortTerm.confidence * 0.85,
                    longTerm.prediction.finalPrediction,
                    "Rejim değişimi: Kısa vade"
                )
            transition.isTransitioning && transition.direction == "STABILIZING" ->
                ResolvedPrediction(
                    longTerm.prediction.finalPrediction,
                    longTerm.confidence * 0.85,
                    shortTerm.prediction.finalPrediction,
                    "Rejim stabilizasyonu: Uzun vade"
                )
            consensus.variance > 0.08 -> {
                val w = calculateWeightedVote(horizons)
                ResolvedPrediction(w.first, w.second * 0.85, w.third, "Yüksek varyans: Ağırlıklı oylama")
            }
            else -> {
                val topTwo = consensus.frequency.entries.sortedByDescending { it.value }.take(2)
                ResolvedPrediction(
                    topTwo[0].key,
                    0.52,
                    if (topTwo.size > 1) topTwo[1].key else null,
                    "Zayıf konsensüs"
                )
            }
        }
    }

    private fun calculateWeightedVote(
        horizons: List<HorizonPrediction>
    ): Triple<Int, Double, Int?> {
        val votes = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)
        for (h in horizons) {
            val pred = h.prediction.finalPrediction
            votes[pred] = (votes[pred] ?: 0.0) + h.weight * h.confidence
            if (h.prediction.secondPrediction != null) {
                val second = h.prediction.secondPrediction
                votes[second] = (votes[second] ?: 0.0) + h.weight * h.confidence * 0.4
            }
        }
        val sorted = votes.entries.sortedByDescending { it.value }
        val total = votes.values.sum()
        return Triple(
            sorted[0].key,
            if (total > 0) sorted[0].value / total else 0.25,
            sorted.getOrNull(1)?.key
        )
    }

    private fun shouldShowDouble(
        resolved: ResolvedPrediction,
        horizons: List<HorizonPrediction>
    ): Boolean {
        if (resolved.confidence < 0.55) return true
        if (resolved.second != null &&
            resolved.confidence - (horizons.map { it.prediction.confidence }
                .minOrNull() ?: 0.0) < 0.12) return true
        return false
    }

    data class ConsensusAnalysis(
        val dominantPrediction: Int,
        val confidence: Double,
        val hasConflict: Boolean,
        val frequency: Map<Int, Int>,
        val variance: Double
    )

    data class RegimeTransition(
        val isTransitioning: Boolean,
        val shortTermRegime: RegimeDetector.RegimeType,
        val longTermRegime: RegimeDetector.RegimeType,
        val direction: String
    )

    data class ResolvedPrediction(
        val prediction: Int,
        val confidence: Double,
        val second: Int?,
        val reason: String
    )
}
