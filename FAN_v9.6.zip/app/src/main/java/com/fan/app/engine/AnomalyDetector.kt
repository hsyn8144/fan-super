package com.fan.app.engine

import com.fan.app.data.DataEntry

object AnomalyDetector {

    data class AnomalyResult(
        val anomalies: List<Anomaly>,
        val overallSeverity: Double,
        val recommendedAction: Action,
        val confidenceAdjustment: Double,
        val shouldShowDouble: Boolean
    )

    data class Anomaly(
        val type: AnomalyType,
        val severity: Double,
        val description: String,
        val affectedMethods: List<Int>
    )

    enum class AnomalyType {
        OUTLIER_VALUE,
        REGIME_SHIFT,
        PATTERN_BREAK,
        UNUSUAL_STREAK,
        FREQUENCY_SPIKE,
        ENTROPY_COLLAPSE
    }

    enum class Action {
        NORMAL,
        CAUTIOUS,
        VERY_CAUTIOUS,
        EMERGENCY
    }

    fun detect(data: List<Int>, previousData: List<Int> = emptyList()): AnomalyResult {
        val anomalies = mutableListOf<Anomaly>()

        detectOutlierValue(data, previousData)?.let { anomalies.add(it) }
        detectRegimeShift(data, previousData)?.let { anomalies.add(it) }
        detectPatternBreak(data)?.let { anomalies.add(it) }
        detectUnusualStreak(data)?.let { anomalies.add(it) }
        detectFrequencySpike(data)?.let { anomalies.add(it) }
        detectEntropyCollapse(data)?.let { anomalies.add(it) }

        val severity = calculateOverallSeverity(anomalies)
        val action = determineAction(severity, anomalies)
        val adjustment = calculateConfidenceAdjustment(severity, anomalies)
        val showDouble = shouldForceDoublePrediction(anomalies, severity)

        return AnomalyResult(
            anomalies = anomalies,
            overallSeverity = severity,
            recommendedAction = action,
            confidenceAdjustment = adjustment,
            shouldShowDouble = showDouble
        )
    }

    private fun detectOutlierValue(data: List<Int>, previous: List<Int>): Anomaly? {
        if (data.size < 2 || previous.size < 10) return null

        val lastValue = data.last()
        val prevDistribution = previous.groupBy { it }.mapValues { it.value.size }
        val prevTotal = previous.size

        val expectedProb = (prevDistribution[lastValue] ?: 0).toDouble() / prevTotal
        val transitionProb = calculateTransitionProbability(previous, lastValue)

        if (expectedProb < 0.05 && transitionProb < 0.1) {
            return Anomaly(
                type = AnomalyType.OUTLIER_VALUE,
                severity = 0.6 + 0.3 * (1.0 - expectedProb * 20),
                description = "$lastValue değeri beklenmedik (normal freq: ${String.format("%.2f", expectedProb)})",
                affectedMethods = listOf(0, 4, 5, 6)
            )
        }
        return null
    }

    private fun calculateTransitionProbability(data: List<Int>, target: Int): Double {
        if (data.size < 2) return 0.25
        val transitions = data.zipWithNext { _, b -> if (b == target) 1 else 0 }.sum()
        return transitions.toDouble() / (data.size - 1)
    }

    private fun detectRegimeShift(data: List<Int>, previous: List<Int>): Anomaly? {
        if (data.size < 25 || previous.size < 50) return null

        val currentRegime = RegimeDetector.detectCurrentRegime(data.takeLast(25))
        val previousRegime = RegimeDetector.detectCurrentRegime(previous.takeLast(50))

        if (currentRegime != previousRegime) {
            val stability = calculateRegimeStability(data.takeLast(25))
            val severity = if (stability > 0.7) 0.5 else 0.75

            return Anomaly(
                type = AnomalyType.REGIME_SHIFT,
                severity = severity,
                description = "Rejim değişimi: $previousRegime → $currentRegime (stabilite: ${String.format("%.2f", stability)})",
                affectedMethods = getMethodsForRegime(previousRegime)
            )
        }
        return null
    }

    private fun calculateRegimeStability(data: List<Int>): Double {
        if (data.size < 10) return 0.5
        val regimes = (0..data.size - 10 step 5).map { idx ->
            val end = minOf(idx + 10, data.size)
            RegimeDetector.detectCurrentRegime(data.subList(idx, end))
        }
        val uniqueRegimes = regimes.toSet().size
        return 1.0 - (uniqueRegimes - 1).toDouble() / maxOf(regimes.size - 1, 1)
    }

    private fun getMethodsForRegime(regime: RegimeDetector.RegimeType): List<Int> {
        return DataEntry.METHOD_REGIME_FIT
            .filter { (_, regimes) -> regime.name in regimes }
            .keys.toList()
    }

    private fun detectPatternBreak(data: List<Int>): Anomaly? {
        if (data.size < 20) return null

        val patterns = PatternMatcher.findPatterns(data.dropLast(1))
        if (patterns.isEmpty()) return null

        val strongestPattern = patterns.maxByOrNull { it.patternLength * it.matchPositions.size } ?: return null
        val lastValue = data.last()

        val expectedByPattern = predictFromPattern(strongestPattern, data)
        if (expectedByPattern != null && expectedByPattern != lastValue) {
            return Anomaly(
                type = AnomalyType.PATTERN_BREAK,
                severity = 0.55 + 0.2 * (strongestPattern.patternLength.toDouble() / 10),
                description = "Kalıp kırılması: ${strongestPattern.patternLength} elemanlı kalıp bozuldu (beklenen: $expectedByPattern, gelen: $lastValue)",
                affectedMethods = listOf(0, 4, 5)
            )
        }
        return null
    }

    private fun predictFromPattern(pattern: PatternMatcher.PatternMatch, data: List<Int>): Int? {
        if (pattern.matchPositions.isEmpty()) return null
        val lastPos = pattern.matchPositions.last()
        val afterPos = lastPos + pattern.patternLength
        return if (afterPos < data.size - 1) data[afterPos] else null
    }

    private fun detectUnusualStreak(data: List<Int>): Anomaly? {
        val (streakVal, streakLen) = RegimeDetector.getCurrentStreak(data)

        val expectedMaxStreak = calculateExpectedMaxStreak(data.size)
        if (streakLen > expectedMaxStreak * 1.4) {
            val severity = minOf(0.85, 0.45 + 0.08 * (streakLen - expectedMaxStreak))

            return Anomaly(
                type = AnomalyType.UNUSUAL_STREAK,
                severity = severity,
                description = "Olağanüstü seri: $streakVal değeri $streakLen kez tekrar (beklenen max: ${String.format("%.1f", expectedMaxStreak)})",
                affectedMethods = listOf(9, 10, 1, 11)
            )
        }
        return null
    }

    private fun calculateExpectedMaxStreak(totalSize: Int): Double {
        return 2.0 + kotlin.math.ln(totalSize.toDouble()) / kotlin.math.ln(2.0)
    }

    private fun detectFrequencySpike(data: List<Int>): Anomaly? {
        if (data.size < 30) return null

        val recent = data.takeLast(30)
        val freq = recent.groupBy { it }.mapValues { it.value.size }
        val maxFreq = freq.values.maxOrNull() ?: 0
        val maxValue = freq.entries.maxByOrNull { it.value }?.key ?: 0

        if (maxFreq > 15) {
            return Anomaly(
                type = AnomalyType.FREQUENCY_SPIKE,
                severity = minOf(0.75, 0.35 + 0.02 * (maxFreq - 15)),
                description = "Frekans sıçraması: $maxValue değeri $maxFreq/30 oranında (beklenen: ~7-8)",
                affectedMethods = listOf(1, 7, 8)
            )
        }
        return null
    }

    private fun detectEntropyCollapse(data: List<Int>): Anomaly? {
        if (data.size < 60) return null

        val window1 = data.takeLast(40)
        val window2 = if (data.size >= 65) data.dropLast(25).takeLast(40) else return null

        val entropy1 = RegimeDetector.computeBlockEntropy(window1, 40)
        val entropy2 = RegimeDetector.computeBlockEntropy(window2, 40)

        if (entropy1 < 0.45 && entropy2 > 0.6) {
            return Anomaly(
                type = AnomalyType.ENTROPY_COLLAPSE,
                severity = 0.70,
                description = "Entropi çöküşü: ${String.format("%.2f", entropy2)} → ${String.format("%.2f", entropy1)}",
                affectedMethods = (0..12).toList()
            )
        }
        return null
    }

    private fun calculateOverallSeverity(anomalies: List<Anomaly>): Double {
        if (anomalies.isEmpty()) return 0.0
        val maxSeverity = anomalies.maxOf { it.severity }
        val countBonus = minOf((anomalies.size - 1) * 0.08, 0.15)
        return minOf(maxSeverity + countBonus, 1.0)
    }

    private fun determineAction(severity: Double, anomalies: List<Anomaly>): Action {
        return when {
            severity >= 0.8 || anomalies.any { it.type == AnomalyType.REGIME_SHIFT && it.severity > 0.65 } -> Action.EMERGENCY
            severity >= 0.55 || anomalies.size >= 2 -> Action.VERY_CAUTIOUS
            severity >= 0.35 -> Action.CAUTIOUS
            else -> Action.NORMAL
        }
    }

    private fun calculateConfidenceAdjustment(severity: Double, anomalies: List<Anomaly>): Double {
        val baseAdjustment = when {
            severity >= 0.8 -> 0.55
            severity >= 0.55 -> 0.70
            severity >= 0.35 -> 0.85
            else -> 1.0
        }

        val specificAdjustments = anomalies.map { anomaly ->
            when (anomaly.type) {
                AnomalyType.REGIME_SHIFT -> 0.85
                AnomalyType.PATTERN_BREAK -> 0.80
                AnomalyType.ENTROPY_COLLAPSE -> 0.75
                else -> 1.0
            }
        }

        return baseAdjustment * (specificAdjustments.minOrNull() ?: 1.0)
    }

    private fun shouldForceDoublePrediction(anomalies: List<Anomaly>, severity: Double): Boolean {
        return severity >= 0.45 ||
                anomalies.any { it.type == AnomalyType.REGIME_SHIFT } ||
                anomalies.any { it.type == AnomalyType.PATTERN_BREAK && it.severity > 0.6 }
    }

    fun formatAnomalyFlags(result: AnomalyResult): String {
        return result.anomalies.joinToString(",") { "${it.type.name}:${String.format("%.2f", it.severity)}" }
    }
}
