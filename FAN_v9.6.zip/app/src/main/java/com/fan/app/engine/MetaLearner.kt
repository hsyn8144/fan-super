package com.fan.app.engine

import com.fan.app.data.DataEntry

class MetaLearner {

    data class Condition(
        val regimeType: String,
        val streakLen: Int,
        val deltaSign: Int,
        val freqBias: Int
    )

    // Persistent performance memory — NOT reset between calls!
    private val methodPerformance = mutableMapOf<Int, MutableMap<String, EmaPerf>>()

    private class EmaPerf(alpha: Double = 0.05) {
        val a = alpha
        var accuracy = 0.25
        var samples = 0
        fun update(correct: Boolean) {
            accuracy = accuracy * (1 - a) + (if (correct) 1.0 else 0.0) * a
            samples++
        }
    }

    fun compute(
        data: List<Int>,
        methodVotes: List<Ensemble.MethodVote>,
        pastEntries: List<DataEntry>
    ): Map<Int, Double> {
        if (data.size < 20 || methodVotes.isEmpty()) {
            return methodVotes.fold(mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)) { acc, mv ->
                val top = mv.votes.maxByOrNull { it.value }?.key ?: 1
                acc[top] = (acc[top] ?: 0.0) + 1.0
                acc
            }.let { normalizeVotes(it) }
        }

        val condition = extractCondition(data)
        val condKey = conditionToKey(condition)

        updatePerformance(pastEntries, condKey)

        val weightedVotes = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)

        for (mv in methodVotes) {
            val idx = mv.methodIndex
            val perf = methodPerformance[idx]?.get(condKey)
            val weight = if (perf != null && perf.samples >= 8) {
                // Accuracy range 0.25 (random) → 1.0; map to weight 0.4..2.0
                val acc = perf.accuracy
                0.4 + 1.6 * ((acc - 0.15).coerceIn(0.0, 0.85)) / 0.85
            } else {
                // Fallback: use method's own confidence
                0.7 + 0.6 * mv.confidence
            }

            // Weight by the full distribution, not just top prediction
            for ((pred, prob) in mv.votes) {
                weightedVotes[pred] = (weightedVotes[pred] ?: 0.0) + weight * prob
            }
        }

        return normalizeVotes(weightedVotes)
    }

    private fun extractCondition(data: List<Int>): Condition {
        val regime = RegimeDetector.detectCurrentRegime(data.takeLast(25))
        val (_, streak) = RegimeDetector.getCurrentStreak(data)
        val delta = if (data.size >= 2) Integer.signum(data.last() - data[data.size - 2]) else 0
        val freq = data.takeLast(20).groupBy { it }.maxByOrNull { it.value.size }?.key ?: 1
        return Condition(regime.name, minOf(streak, 5), delta, freq)
    }

    private fun conditionToKey(c: Condition): String =
        "${c.regimeType}_${c.streakLen}_${c.deltaSign}_${c.freqBias}"

    private fun updatePerformance(
        pastEntries: List<DataEntry>,
        currentCondKey: String
    ) {
        val evaluated = pastEntries.drop(50)
        if (evaluated.isEmpty()) return

        // To avoid O(n*m) work every call, only evaluate the last few entries per call
        val recent = evaluated.takeLast(5)
        for (entry in recent) {
            // Condition at the time of this entry would ideally be used,
            // but reconstructing it from history is expensive.
            // Use current condition as an approximation (works with EMA smoothing).
            for (methodIdx in 0 until DataEntry.METHOD_COUNT) {
                val correct = getMethodCorrect(entry, methodIdx)
                methodPerformance.getOrPut(methodIdx) { mutableMapOf() }
                    .getOrPut(currentCondKey) { EmaPerf() }
                    .update(correct)
            }
        }
    }

    private fun getMethodCorrect(entry: DataEntry, index: Int): Boolean =
        when (index) {
            0 -> entry.method1Correct
            1 -> entry.method2Correct
            2 -> entry.method3Correct
            3 -> entry.method4Correct
            4 -> entry.method5Correct
            5 -> entry.method6Correct
            6 -> entry.method7Correct
            7 -> entry.method8Correct
            8 -> entry.method9Correct
            9 -> entry.method10Correct
            10 -> entry.method11Correct
            11 -> entry.method12Correct
            12 -> entry.method13Correct
            else -> false
        }

    private fun normalizeVotes(votes: Map<Int, Double>): Map<Int, Double> {
        val total = votes.values.sum()
        if (total <= 0.0) return mapOf(1 to 0.25, 2 to 0.25, 3 to 0.25, 4 to 0.25)
        return votes.mapValues { it.value / total }
    }

    fun reset() {
        methodPerformance.clear()
    }
}
