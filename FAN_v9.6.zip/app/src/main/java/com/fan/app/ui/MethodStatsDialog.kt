package com.fan.app.ui

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.Window
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import com.fan.app.data.PythonBridge
import com.fan.app.data.PythonResult

class MethodStatsDialog(
    context: Context,
    private val methodStats: List<Triple<String, Int, Int>>,
    private val activeStats: List<Triple<String, Int, Int>>? = null,
    private val summaryStats: SummaryStats? = null,
    private val pyResult: PythonResult = PythonResult.EMPTY
) : Dialog(context) {

    data class SummaryStats(
        val ensembleAcc: Double,
        val ensembleTotalAcc: Double,
        val kalipAcc: Double,
        val sideAnyAcc: Double,
        val evaluatedCount: Int,
        val correctCount: Int,
        val noPredictionCount: Int = 0,
        val pythonPriAcc: Double = 0.0,
        val pythonAnyAcc: Double = 0.0,
        val pythonSideAnyAcc: Double = 0.0,
        val pythonEvaluatedCount: Int = 0,
        val runMode: Int = PythonBridge.MODE_KOTLIN
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        buildUI()
    }

    private fun buildUI() {
        val scroll = ScrollView(context)
        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(Color.parseColor("#F5F5F5"))
        }
        val title = TextView(context).apply {
            text = "Yöntem İstatistikleri (v9.6)"
            textSize = 18f; setTextColor(Color.parseColor("#212121"))
            gravity = Gravity.CENTER; setPadding(0, 0, 0, 12)
        }
        container.addView(title)

        val modeText = when (summaryStats?.runMode) {
            PythonBridge.MODE_PYTHON -> "Python Modu 🐍"
            PythonBridge.MODE_HYBRID -> "Hibrit Mod ⚡ (Kotlin + Python)"
            else -> "Kotlin Modu 🔵"
        }
        container.addView(TextView(context).apply {
            text = modeText; textSize = 11f; setTextColor(Color.parseColor("#757575"))
            gravity = Gravity.CENTER; setPadding(0, 0, 0, 12)
        })

        if (summaryStats != null) container.addView(buildSummaryCard(summaryStats))

        // ── YÖNTEM LİSTESİ ─────────────────────────────────────
        val mode = summaryStats?.runMode ?: PythonBridge.MODE_KOTLIN
        val showK = mode == PythonBridge.MODE_KOTLIN || mode == PythonBridge.MODE_HYBRID
        val showP = mode == PythonBridge.MODE_PYTHON || mode == PythonBridge.MODE_HYBRID

        if (showK) {
            container.addView(sectionHeader("🔵 KOTLIN YÖNTEMLERİ", "#1565C0"))
            container.addView(TextView(context).apply {
                text = "Yeşil: Aktif  |  Gri: Pasif"; textSize = 11f
                setTextColor(Color.parseColor("#757575")); gravity = Gravity.CENTER
                setPadding(0, 2, 0, 10)
            })
            if (methodStats.isEmpty()) {
                container.addView(TextView(context).apply {
                    text = "Henüz yeterli veri yok.\n50 veri girilmesi gerekiyor."
                    textSize = 14f; setTextColor(Color.parseColor("#757575"))
                    gravity = Gravity.CENTER; setPadding(0, 24, 0, 24)
                })
            } else {
                methodStats.forEachIndexed { index, (name, correct, total) ->
                    val isActive = activeStats?.find { it.first == name }?.third != 0
                    val forcedActive = name.startsWith("Ensemble") || name.startsWith("★") || name.startsWith("Kalıp")
                    val rank = when {
                        name.startsWith("Ensemble") -> 0
                        name.startsWith("★") -> 99
                        name.startsWith("Kalıp") -> 1
                        else -> index + 1
                    }
                    container.addView(buildMethodRow(rank, name, correct, total, isActive || forcedActive, "#1565C0"))
                }
            }
        }

        if (showK && showP) {
            val sep = View(context).apply {
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, 2
                ).apply { topMargin = 16; bottomMargin = 16 }
                setBackgroundColor(Color.parseColor("#81C784"))
            }
            container.addView(sep)
        }

        if (showP) {
            container.addView(sectionHeader("🐍 PYTHON STRATEJİLERİ", "#2E7D32"))
            val pyStrats = buildPythonMethodRows()
            if (pyStrats.isEmpty()) {
                container.addView(TextView(context).apply {
                    text = "Python henüz çalışmıyor ya da veri yok.\nTermux'ta fan_live.py'yi başlatın."
                    textSize = 13f; setTextColor(Color.parseColor("#757575"))
                    gravity = Gravity.CENTER; setPadding(0, 20, 0, 20)
                })
            } else {
                pyStrats.forEach { container.addView(it) }
            }
        }

        val closeBtn = Button(context).apply {
            text = "Kapat"; setTextColor(Color.WHITE); setBackgroundColor(Color.parseColor("#1565C0"))
            setPadding(0, 16, 0, 16)
            setOnClickListener { dismiss() }
        }
        container.addView(closeBtn, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = 24 })

        scroll.addView(container)
        setContentView(scroll)
        window?.setLayout(
            (context.resources.displayMetrics.widthPixels * 0.92).toInt(),
            android.view.WindowManager.LayoutParams.WRAP_CONTENT
        )
    }

    private fun sectionHeader(title: String, color: String): TextView {
        return TextView(context).apply {
            text = title; textSize = 13f
            setTextColor(Color.parseColor(color))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(0, 4, 0, 8)
        }
    }

    private fun buildPythonMethodRows(): List<View> {
        val rows = mutableListOf<View>()
        val n = pyResult.evaluatedCount
        val priAcc = pyResult.priAccuracy
        val anyAcc = pyResult.anyAccuracy
        val sideAcc = pyResult.sideAnyAccuracy

        // Hedge (ensemble) satırı — her zaman göster (Python çalışıyorsa)
        if (n > 0 || pyResult.hasPrediction) {
            val evalN = if (n > 0) n else 1
            val anyPct = (anyAcc * 100).toInt()
            val priPct = (priAcc * 100).toInt()
            val sidePct = (sideAcc * 100).toInt()
            rows.add(buildMethodRow(
                0,
                "🐍 Python Hedge (ensemble)",
                (anyAcc * evalN).toInt(), evalN, true, "#2E7D32",
                forcePct = anyPct,
                subtitle = "tekil %$priPct  ·  tek+çift %$anyPct  ·  yan %$sidePct  (n=${if (n>0) n else "warmup"})"
            ))
        }

        // Strateji detayları (9 ya da 13 strateji olabilir)
        val stats = pyResult.stratStats
        val names = PythonResult.STRATEGY_NAMES
        if (stats.size >= 9) {
            val nStrat = stats.size
            data class StratEntry(val priPct: Int, val anyPct: Int, val sn: Int, val name: String, val idx: Int)
            val indexed = (0 until nStrat).map { i ->
                val (pri, any, sn) = stats[i]
                val anyPct = if (sn > 0) (100.0 * any / sn).toInt() else 0
                val priPct = if (sn > 0) (100.0 * pri / sn).toInt() else 0
                val nm = if (i < names.size) names[i] else "Strat$i"
                StratEntry(priPct, anyPct, sn, nm, i)
            }.sortedByDescending { it.anyPct }
            indexed.forEachIndexed { rank, e ->
                val active = e.sn >= 5
                rows.add(buildMethodRow(
                    rank + 1,
                    e.name,
                    e.anyPct * e.sn / 100,
                    e.sn,
                    active,
                    "#2E7D32",
                    forcePct = e.anyPct,
                    subtitle = "tekil %${e.priPct}  ·  tek+çift %${e.anyPct}  (n=${e.sn})"
                ))
            }
        }
        return rows
    }

    private fun buildSummaryCard(s: SummaryStats): LinearLayout {
        val card = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#E3F2FD"))
            setPadding(16, 14, 16, 14)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = 14 }
        }
        fun pctColor(p: Int) = when {
            p >= 70 -> "#2E7D32"; p >= 50 -> "#EF6C00"; p >= 35 -> "#E65100"; else -> "#C62828"
        }
        fun addRow(title: String, pct: Int, sub: String, highlight: Boolean = false, color: String? = null) {
            val r = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 3, 0, 3) }
            val t = TextView(context).apply {
                text = title; textSize = if (highlight) 14f else 12f
                setTextColor(Color.parseColor(if (highlight) "#0D47A1" else "#37474F"))
                if (highlight) setTypeface(typeface, android.graphics.Typeface.BOLD)
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            val p = TextView(context).apply {
                text = "%$pct"; textSize = if (highlight) 15f else 13f
                setTextColor(Color.parseColor(color ?: pctColor(pct)))
                if (highlight) setTypeface(typeface, android.graphics.Typeface.BOLD)
                gravity = Gravity.END
            }
            val s2 = TextView(context).apply {
                text = "  $sub"; textSize = 10f; setTextColor(Color.parseColor("#78909C")); gravity = Gravity.END
            }
            r.addView(t); r.addView(p); r.addView(s2); card.addView(r)
        }

        val showK = s.runMode == PythonBridge.MODE_KOTLIN || s.runMode == PythonBridge.MODE_HYBRID
        val showP = s.runMode == PythonBridge.MODE_PYTHON || s.runMode == PythonBridge.MODE_HYBRID

        card.addView(TextView(context).apply {
            text = "📊 GENEL BAŞARI ÖZETİ"; textSize = 12f
            setTextColor(Color.parseColor("#0D47A1"))
            setTypeface(typeface, android.graphics.Typeface.BOLD); setPadding(0, 0, 0, 6)
        })

        if (showK) {
            addRow("🔵 Ensemble (tekil)", (s.ensembleAcc*100).toInt(),
                "${s.correctCount}/${s.evaluatedCount}", highlight = true)
            addRow("🔵 Ensemble (tek+çift)", (s.ensembleTotalAcc*100).toInt(),
                "/${s.evaluatedCount}")
            addRow("🎯 Kalıp (çiftli)", (s.kalipAcc*100).toInt(), "")
            addRow("★ Kotlin Yan", (s.sideAnyAcc*100).toInt(), "")
        }

        if (showK && showP) {
            val sep = View(context).apply {
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, 1
                ).apply { topMargin=6; bottomMargin=6 }
                setBackgroundColor(Color.parseColor("#81C784"))
            }
            card.addView(sep)
        }

        if (showP) {
            val pyN = s.pythonEvaluatedCount
            val hasPy = pyN > 0 || s.pythonAnyAcc > 0.001
            val priPct = (s.pythonPriAcc*100).toInt()
            val anyPct = (s.pythonAnyAcc*100).toInt()
            val sidePct = (s.pythonSideAnyAcc*100).toInt()
            addRow("🐍 Python Hedge (tekil)", priPct,
                if (hasPy) "($pyN degerlendirme)" else "—", highlight = true,
                color = "#2E7D32")
            addRow("🐍 Python Hedge (tek+cift)", anyPct,
                if (hasPy) "" else "veri bekleniyor", color = "#2E7D32")
            addRow("🐍 Python Yan", sidePct,
                if (hasPy) "" else "fan_live.py calistirin", color = "#2E7D32")
        }

        return card
    }

    private fun buildMethodRow(
        rank: Int, name: String, correct: Int, total: Int, isActive: Boolean,
        themeColor: String = "#1565C0",
        forcePct: Int? = null,
        subtitle: String? = null
    ): LinearLayout {
        val row = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 12, 16, 12)
            setBackgroundColor(if (isActive) Color.WHITE else Color.parseColor("#E0E0E0"))
            alpha = if (isActive) 1.0f else 0.6f
        }
        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = 8 }

        val topRow = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        val isEnsemble = name.startsWith("Ensemble") || name.startsWith("🐍")
        val isYan = name.startsWith("★")
        val isKalip = name.startsWith("Kalıp") || name.startsWith("🎯")
        val rankBadge = TextView(context).apply {
            text = when {
                isEnsemble -> "★"; isYan -> "🎯"; isKalip -> "🎯"
                rank == 1 -> "#1"; rank == 2 -> "#2"; rank == 3 -> "#3"
                else -> "•"
            }
            textSize = 13f
            setTextColor(Color.parseColor(when {
                isEnsemble -> themeColor; isYan || isKalip -> "#6A1B9A"
                rank == 1 -> "#FFD600"; rank == 2 -> "#B0BEC5"; rank == 3 -> "#FF9800"
                else -> "#90A4AE"
            }))
            setPadding(0, 0, 12, 0); gravity = Gravity.CENTER_VERTICAL
        }
        topRow.addView(rankBadge)
        val nameText = TextView(context).apply {
            text = name; textSize = 14f
            setTextColor(Color.parseColor(if (isActive) "#212121" else "#757575"))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        topRow.addView(nameText)
        val statusText = TextView(context).apply {
            text = if (isActive) "●" else "○"; textSize = 12f
            setTextColor(Color.parseColor(if (isActive) "#4CAF50" else "#9E9E9E"))
            gravity = Gravity.CENTER_VERTICAL; setPadding(0, 0, 8, 0)
        }
        topRow.addView(statusText)
        val pct = forcePct ?: (if (total > 0) ((correct.toDouble() / total) * 100).toInt() else 0)
        val accText = TextView(context).apply {
            text = "%$pct"; textSize = 15f
            setTextColor(when {
                !isActive -> Color.parseColor("#9E9E9E")
                pct >= 40 -> Color.parseColor("#4CAF50")
                pct >= 30 -> Color.parseColor("#FF9800")
                else -> Color.parseColor("#F44336")
            })
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
        }
        topRow.addView(accText)
        row.addView(topRow)

        val detailText = subtitle ?: "Doğru: $correct / $total ${if (!isActive) "(Pasif)" else ""}"
        val detail = TextView(context).apply {
            text = detailText
            textSize = 11f; setTextColor(Color.parseColor("#757575"))
            setPadding(0, 4, 0, 6)
        }
        row.addView(detail)

        val prog = ProgressBar(context, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; progress = pct.coerceIn(0, 100)
            progressTintList = android.content.res.ColorStateList.valueOf(
                when {
                    !isActive -> Color.parseColor("#BDBDBD")
                    pct >= 40 -> Color.parseColor("#4CAF50")
                    pct >= 30 -> Color.parseColor("#FF9800")
                    else -> Color.parseColor("#F44336")
                })
        }
        row.addView(prog, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 12))
        row.layoutParams = params
        return row
    }
}
