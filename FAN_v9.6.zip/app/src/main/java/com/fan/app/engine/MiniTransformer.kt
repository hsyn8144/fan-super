package com.fan.app.engine

class MiniTransformer {

    private val windowSize = 16
    private val dModel = 12
    private val numHeads = 3
    private val headDim = dModel / numHeads  // 4

    private val outputWeights = Array(4) { DoubleArray(dModel + 1) { (Math.random() - 0.5) * 0.01 } }
    private var trained = false
    private var trainedUpTo = 0
    private val baseLr = 0.004

    private val predHistory = ArrayDeque<Int>(30)

    fun compute(data: List<Int>): Map<Int, Double> {
        if (data.size < 4) return equal()

        // Incremental training
        if (trainedUpTo < data.size - 1) {
            val startTrain = maxOf(windowSize - 1, trainedUpTo)
            for (i in startTrain until data.size - 1) {
                val sub = data.subList(maxOf(0, i - windowSize + 1), i + 1)
                val pooled = forward(sub)
                val recency = 1.0 / (1.0 + (data.size - i) * 0.005)
                learn(pooled, data[i + 1], baseLr * (0.5 + recency))
            }
            trainedUpTo = data.size - 1
        }

        val sub = data.takeLast(windowSize.coerceAtMost(data.size))
        val pooled = forward(sub)
        return predictWithDiversity(pooled)
    }

    private fun forward(seq: List<Int>): DoubleArray {
        val emb = embed(seq)
        val att = attention(emb)
        val last = att.last()
        val avg = DoubleArray(dModel) { j -> att.map { it[j] }.average() }
        val maxP = DoubleArray(dModel) { j -> att.map { it[j] }.maxOrNull() ?: 0.0 }
        return DoubleArray(dModel) { j -> last[j] * 0.5 + avg[j] * 0.3 + maxP[j] * 0.2 }
    }

    private fun embed(seq: List<Int>): Array<DoubleArray> {
        return Array(seq.size) { i ->
            val v = seq[i]
            val prev = if (i > 0) seq[i - 1] else v
            val next = if (i < seq.size - 1) seq[i + 1] else v
            val pos = i.toDouble() / seq.size
            DoubleArray(dModel) { j ->
                when (j) {
                    0 -> (v - 2.5) / 1.5
                    1 -> kotlin.math.sin(i * 0.5)
                    2 -> kotlin.math.cos(i * 0.5)
                    3 -> (v - prev).toDouble() / 3.0
                    4 -> (next - v).toDouble() / 3.0
                    5 -> if (v == prev) 1.0 else 0.0
                    6 -> v.toDouble() / 4.0
                    7 -> kotlin.math.sin(v * 1.5)
                    8 -> kotlin.math.cos(v * 1.5)
                    9 -> (v % 2).toDouble()
                    10 -> if (v <= 2) 0.0 else 1.0
                    11 -> pos
                    else -> 0.0
                }
            }
        }
    }

    private fun attention(emb: Array<DoubleArray>): Array<DoubleArray> {
        val n = emb.size
        val out = Array(n) { DoubleArray(dModel) }
        for (h in 0 until numHeads) {
            val off = h * headDim
            for (i in 0 until n) {
                val scores = DoubleArray(n)
                // Causal masking: j can only attend to positions <= i
                for (j in 0..i) {
                    var dot = 0.0
                    for (k in 0 until headDim) dot += emb[i][off + k] * emb[j][off + k]
                    scores[j] = dot / kotlin.math.sqrt(headDim.toDouble())
                }
                // Mask future
                for (j in i+1 until n) scores[j] = Double.NEGATIVE_INFINITY

                val mx = scores.take(i+1).maxOrNull() ?: Double.NEGATIVE_INFINITY
                val ex = DoubleArray(n) { if (it <= i) kotlin.math.exp(scores[it] - mx) else 0.0 }
                val s = ex.sum().coerceAtLeast(1e-9)
                val w = DoubleArray(n) { ex[it] / s }
                for (k in 0 until headDim) {
                    var weighted = 0.0
                    for (j in 0..i) weighted += w[j] * emb[j][off + k]
                    out[i][off + k] += weighted / numHeads
                }
            }
        }
        return out
    }

    private fun rawScores(vec: DoubleArray): DoubleArray =
        DoubleArray(4) { cls ->
            outputWeights[cls][0] + vec.indices.sumOf { j -> outputWeights[cls][j + 1] * vec[j] }
        }

    private fun learn(vec: DoubleArray, target: Int, lr: Double) {
        val scores = rawScores(vec)
        val mx = scores.max()
        val ex = DoubleArray(4) { kotlin.math.exp(scores[it] - mx) }
        val s = ex.sum().coerceAtLeast(1e-9)
        val probs = DoubleArray(4) { ex[it] / s }
        val reg = 0.0002
        for (cls in 0..3) {
            val t = if (cls == target - 1) 1.0 else 0.0
            val err = t - probs[cls]
            outputWeights[cls][0] += lr * err - lr * reg * outputWeights[cls][0]
            for (j in vec.indices) outputWeights[cls][j + 1] += lr * err * vec[j] - lr * reg * outputWeights[cls][j + 1]
        }
        trained = true
    }

    private fun predictWithDiversity(vec: DoubleArray): Map<Int, Double> {
        if (!trained) return equal()
        val scores = rawScores(vec)
        val mx = scores.max()
        val ex = DoubleArray(4) { kotlin.math.exp(scores[it] - mx) }
        val s = ex.sum().coerceAtLeast(1e-9)
        val probs = DoubleArray(4) { ex[it] / s }

        val adjusted = diversityAdjust(probs)
        val top = adjusted.indices.maxByOrNull { adjusted[it] }!! + 1
        if (predHistory.size >= 30) predHistory.removeFirst()
        predHistory.addLast(top)

        val total = adjusted.sum().coerceAtLeast(1e-9)
        return mapOf(1 to adjusted[0]/total, 2 to adjusted[1]/total, 3 to adjusted[2]/total, 4 to adjusted[3]/total)
    }

    private fun diversityAdjust(probs: DoubleArray): DoubleArray {
        if (predHistory.size < 12) return probs
        val recent = predHistory.toList().takeLast(12)
        val freq = DoubleArray(4) { k -> recent.count { it == k + 1 }.toDouble() / recent.size }
        val result = DoubleArray(4)
        for (k in 0..3) {
            val penalty = when {
                freq[k] > 0.65 -> 0.65
                freq[k] > 0.5 -> 0.8
                else -> 1.0
            }
            result[k] = probs[k] * penalty
        }
        return result
    }

    fun reset() {
        for (i in 0 until 4) {
            outputWeights[i].fill(0.0)
            outputWeights[i][0] = (Math.random() - 0.5) * 0.01
        }
        trained = false
        trainedUpTo = 0
        predHistory.clear()
    }

    private fun equal() = mapOf(1 to 0.25, 2 to 0.25, 3 to 0.25, 4 to 0.25)
}
