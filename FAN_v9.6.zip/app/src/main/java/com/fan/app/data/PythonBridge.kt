package com.fan.app.data

import android.content.Context
import android.os.Build
import android.os.Environment
import android.util.Log
import java.io.File

/**
 * Python Bridge v8.1: Download/FAN/ klasörü ile iletişim.
 *
 * Klasör yapısı:
 *   Download/FAN/fan_data.csv          → Kotlin yazar, Python okur
 *   Download/FAN/fan_python_log.csv    → Python yazar, Kotlin okur
 */
object PythonBridge {

    private const val TAG = "FAN_PyBridge"
    private const val FOLDER_NAME = "FAN"
    private const val DATA_FILE = "fan_data.csv"
    private const val PY_LOG_FILE = "fan_python_log.csv"
    private const val LEGACY_LIVE_FILE = "fan_data_live.csv"

    const val MODE_KOTLIN = 0
    const val MODE_HYBRID = 1
    const val MODE_PYTHON = 2

    fun modeName(mode: Int): String = when (mode) {
        MODE_KOTLIN -> "Kotlin"
        MODE_HYBRID -> "Hibrit"
        MODE_PYTHON -> "Python"
        else -> "Kotlin"
    }

    /** Download klasörünü bulmak için birden çok yol dener (farklı cihaz/ROM'lar).
     * Büyük/Küçük harf duyarlı dosya sistemleri için hem "FAN" hem "fan" klasörü denenir. */
    private fun downloadRoots(): List<File> {
        val roots = mutableListOf<File>()
        try {
            @Suppress("DEPRECATION")
            val pub = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            roots.add(pub)
        } catch (_: Exception) {}
        roots.add(File("/storage/emulated/0/Download"))
        roots.add(File("/sdcard/Download"))
        roots.add(File("/mnt/sdcard/Download"))
        return roots.distinctBy { it.absolutePath }
    }

    private fun fanFolders(): List<File> {
        val out = mutableListOf<File>()
        for (root in downloadRoots()) {
            for (name in listOf("FAN", "fan")) {
                try { out.add(File(root, name)) } catch (_: Exception) {}
            }
        }
        return out
    }

    private fun fanFolder(): File? {
        // Önce mevcut olanı döndür
        for (dir in fanFolders()) {
            try { if (dir.exists() && dir.isDirectory) return dir } catch (_: Exception) {}
        }
        // Yoksa "FAN" ismiyle oluşturmaya çalış
        for (dir in fanFolders()) {
            try {
                if (dir.mkdirs() || (dir.exists() && dir.isDirectory)) return dir
            } catch (_: Exception) {}
        }
        return null
    }

    private fun dataCandidates(): List<File> {
        val out = mutableListOf<File>()
        for (dir in fanFolders()) {
            out.add(File(dir, DATA_FILE))
        }
        // Legacy
        for (root in downloadRoots()) {
            out.add(File(root, LEGACY_LIVE_FILE))
        }
        return out
    }
    private fun logCandidates(): List<File> {
        val out = mutableListOf<File>()
        for (dir in fanFolders()) {
            out.add(File(dir, PY_LOG_FILE))
        }
        return out
    }

    /** İç CSV'yi Download/fan|FAN klasörüne yaz (tüm mümkün yollara). */
    fun syncDataToPublicFolder(ctx: Context, csvContent: String): Boolean {
        val okTargets = mutableListOf<String>()
        for (dir in fanFolders()) {
            try {
                if (!dir.exists()) {
                    if (!dir.mkdirs()) continue
                }
                val f = File(dir, DATA_FILE)
                f.writeText(csvContent, Charsets.UTF_8)
                okTargets.add(f.absolutePath)
            } catch (e: Exception) {
                Log.w(TAG, "Yazma hatasi $dir: ${e.message}")
            }
        }
        // Legacy (v7.2)
        for (root in downloadRoots()) {
            try {
                File(root, LEGACY_LIVE_FILE).writeText(csvContent, Charsets.UTF_8)
            } catch (_: Exception) {}
        }
        if (okTargets.isNotEmpty()) {
            Log.d(TAG, "CSV yazildi: $okTargets (${csvContent.length} byte)")
        }
        return okTargets.isNotEmpty()
    }

    /** Download/fan|FAN/fan_data.csv'nin içeriğini oku. */
    fun readDataFromPublicFolder(): String? {
        for (f in dataCandidates()) {
            try {
                if (f.exists() && f.length() > 0L) {
                    val txt = f.readText(Charsets.UTF_8)
                    if (txt.isNotBlank()) {
                        Log.d(TAG, "Veri okundu: ${f.absolutePath} (${f.length()} byte)")
                        return txt
                    }
                }
            } catch (_: Exception) {}
        }
        return null
    }

    /** Klasördeki CSV'leri sil (fan/ ve FAN/ ikisini de). */
    fun deletePublicData(): Boolean {
        var any = false
        for (f in dataCandidates()) {
            try { if (f.exists()) { f.delete(); any = true } } catch (_: Exception) {}
        }
        for (f in logCandidates()) {
            try { if (f.exists()) { f.delete(); any = true } } catch (_: Exception) {}
        }
        return any
    }

    /** Python'un son tahminini (fan_python_log.csv son satırı) oku.
     *  Birden fazla klasörde (FAN/fan) log varsa en güncel olanı (en yüksek timestamp) seçer. */
    fun readLastPythonResult(): PythonResult {
        var best: PythonResult = PythonResult.EMPTY
        var bestTs: Long = -1L
        for (f in logCandidates()) {
            try {
                if (!f.exists() || f.length() == 0L) continue
                val r = parseLog(f)
                if (r.timestamp > bestTs && (r.hasPrediction || r.evaluatedCount > 0)) {
                    best = r; bestTs = r.timestamp
                }
            } catch (e: Exception) {
                Log.w(TAG, "Python log okunamadi ${f.absolutePath}: ${e.message}")
            }
        }
        return best
    }

    private fun parseLog(f: File): PythonResult {
        var bestLine: String? = null
        var bestTs: Long = -1L
        try {
            f.forEachLine { line ->
                try {
                    if (line.isBlank()) return@forEachLine
                    val first = line.split("|").firstOrNull()?.trim()?.toLongOrNull() ?: return@forEachLine
                    if (first > bestTs) { bestTs = first; bestLine = line }
                } catch (_: Exception) {}
            }
        } catch (e: Exception) {
            Log.w(TAG, "parseLog okuma hatasi ${f.absolutePath}: ${e.message}")
            return PythonResult.EMPTY
        }
        val line = bestLine ?: return PythonResult.EMPTY
        Log.d(TAG, "Python log son satir (${f.absolutePath}): $line")
        return parseLogLine(line)
    }

    private fun parseLogLine(line: String): PythonResult {
        return try {
            val c = line.split("|")
            if (c.size < 7) return PythonResult.EMPTY
            val ts = c[0].trim().toLongOrNull() ?: 0L
            val pri = c[1].trim().toIntOrNull() ?: 0
            val secRaw = c[2].trim()
            val sec = if (secRaw.isEmpty() || secRaw == "0") null else secRaw.toIntOrNull()
            val conf = c[3].trim().removeSuffix("%").toDoubleOrNull()?.div(100.0)
                ?: c[3].trim().toDoubleOrNull() ?: 0.25
            val sideFmt = c[4].trim()
            val sideConf = c[5].trim().removeSuffix("%").toDoubleOrNull()?.div(100.0) ?: 0.5
            var oeConf = 0.5; var sbConf = 0.5
            var kpri = 0; var ksec: Int? = null; var kconf = 0.25
            var ev = 0; var priAcc = 0.0; var anyAcc = 0.0; var sideAnyAcc = 0.0
            var spri = emptyList<Int>(); var sany = emptyList<Int>(); var sn = emptyList<Int>()
            var wsum = ""
            if (c.size >= 9) {
                oeConf = c[6].trim().removeSuffix("%").toDoubleOrNull()?.div(100.0) ?: 0.5
                sbConf = c[7].trim().removeSuffix("%").toDoubleOrNull()?.div(100.0) ?: 0.5
            }
            if (c.size >= 12) {
                kpri = c[8].trim().toIntOrNull() ?: 0
                val ks = c[9].trim()
                ksec = if (ks.isEmpty() || ks == "0") null else ks.toIntOrNull()
                kconf = c[10].trim().removeSuffix("%").toDoubleOrNull()?.div(100.0) ?: 0.25
            }
            when {
                c.size >= 19 -> {
                    // v8.1+ 19 kolon: 11=ev, 12=pri_acc, 13=any_acc, 14=side_acc,
                    // 15=strat_pri, 16=strat_any, 17=strat_n, 18=wsum
                    ev = c[11].trim().toIntOrNull() ?: 0
                    priAcc = c[12].trim().removeSuffix("%").toDoubleOrNull()?.div(100.0) ?: 0.0
                    anyAcc = c[13].trim().removeSuffix("%").toDoubleOrNull()?.div(100.0) ?: 0.0
                    sideAnyAcc = c[14].trim().removeSuffix("%").toDoubleOrNull()?.div(100.0) ?: 0.0
                    spri = c[15].trim().split(",").map { it.trim().toIntOrNull() ?: 0 }
                    sany = c[16].trim().split(",").map { it.trim().toIntOrNull() ?: 0 }
                    sn   = c[17].trim().split(",").map { it.trim().toIntOrNull() ?: 0 }
                    wsum = c[18].trim()
                }
                c.size >= 16 -> {
                    // v8.0 16 kolon: 11=ev, 12=pri_acc, 13=any_acc, 14=side_acc, 15=wsum
                    ev = c[11].trim().toIntOrNull() ?: 0
                    priAcc = c[12].trim().removeSuffix("%").toDoubleOrNull()?.div(100.0) ?: 0.0
                    anyAcc = c[13].trim().removeSuffix("%").toDoubleOrNull()?.div(100.0) ?: 0.0
                    sideAnyAcc = c[14].trim().removeSuffix("%").toDoubleOrNull()?.div(100.0) ?: 0.0
                    wsum = c[15].trim()
                }
            }
            val nStrat = minOf(spri.size, sany.size, sn.size)
            val stratStats = if (nStrat in listOf(9, 13)) {
                (0 until nStrat).map { i -> Triple(spri[i], sany[i], sn[i]) }
            } else emptyList()
            PythonResult(
                timestamp = ts, primary = pri, secondary = sec, confidence = conf,
                sideFormatted = sideFmt, sideConfidence = sideConf,
                oeConfidence = oeConf, sbConfidence = sbConf,
                kalipPrimary = kpri, kalipSecondary = ksec, kalipConfidence = kconf,
                evaluatedCount = ev, priAccuracy = priAcc, anyAccuracy = anyAcc,
                sideAnyAccuracy = sideAnyAcc, stratStats = stratStats,
                weightsSummary = wsum
            )
        } catch (_: Exception) { PythonResult.EMPTY }
    }
}
