# FAN v2.4 Değişiklikler

## Ana Değişiklikler (Kullanıcının Talepleri Doğrultusunda)

### 1. Kombine Yöntemi Tamamen Kaldırıldı
- `DataEntry.combined*` alanları (combinedPrediction/Secondary/IsDouble/Correct/SecCorrect/Accuracy/SecAccuracy) silindi.
- `COMBINED_METHOD_INDICES` listeden kaldırıldı.
- `EnsembleResult.combined*` alanları (combinedPrediction/Secondary/ShowDouble) silindi.
- `computeSubEnsemble` metodu kombine için çağrılmıyor.
- Ana ekranda ve Overlay'de Kombine satırı yok.
- CSV formatı **geriye dönük uyumlu**: `kombine_*` sütunları header'da duruyor ama her zaman `0/HAYIR/%0` yazılıyor (eski CSV'ler sorunsuz okunuyor).
- MethodStatsDialog'da "Kombine (5 yöntem)" satırı kaldırıldı.

### 2. Kalıp Arama HER ZAMAN Çiftli
- `Ensemble.computeKalipDouble()` metodu: Kalıp (method 0) için her zaman `primary/secondary` çifti döndürür.
- `DataEntry.kalipIsDouble = true` (varsayılan ve zorunlu).
- Overlay'de "K:pri/sec" formatında görünür.

### 3. Ensemble Katmanlı Tahmin Sistemi (%40 / %70)
- **< %40 güven** → "NONE" tier: `--` (tahmin yok, beklemede)
- **%40–%70 arası** → "DOUBLE" tier: çiftli tahmin (pri/sec)
- **≥ %70 güven** → "SINGLE" tier: tekil tahmin (emin)
- Tier bazlı renklendirme: SINGLE=yeşil, DOUBLE=turuncu, NONE=gri.
- Doğruluk hesaplamasında "<40% tahmin vermedi" kayıtları accuracy'den ÇIKARILIR (adil oran).
- `EnsembleResult.tier` alanı eklendi.

### 4. Güven Kalibrasyonu (Platt Tarzı)
- Ensemble online calibration: son 40 tahminin gerçek isabet oranını tutar (`calibWindow`).
- Final confidence = %45 raw confidence + %35 metaConfidence + %20 rolling accuracy.
- Bu sayede güven sayıları gerçek başarıyla uyumlu olur (eski sorun: %50-60 görünüp %14 isabet).
- `Ensemble.recordCalibrationOutcome()` PredictionEngine tarafından her sonuçtan sonra çağrılır.

### 5. Yan Tahmin Tersine Mantık (Çapraz Korelasyon)
- **STRONG_CONF = 0.75** (eskiden 0.55 idi — çok yükseltildi, keskinleştirildi).
- **Her iki eksen (OE ve SB) ≥%75** → çapraz form: `T•K=1`, `C•K=2`, `T•B=3`, `B•C=4`. Bu direkt sayıyı işaret eder.
- **Tek eksen ≥%75** → tek harf: K/B/T/C → %50 şans (o eksene göre).
- **Her iki eksen de <%75** → `--` (tahmin yok).
- `lettersToNumber()` harita: KT=1, KC=2, BT=3, BC=4.
- `checkCorrect()` yeni mantığa göre:
  - "--" → hiçbiri sayılmaz.
  - Tek harf → o eksen eşleşmeli.
  - Çapraz form (içinde = varsa) → any-correct: herhangi bir eksen.
- Half-memory (yarım hafıza): çapraz formda iki harf de yarım sayılır, tek harf formda sadece o harf, `--` formda hiç kayıt yok.

### 6. Ana Ekran Sadeleştirme
- Ana ekranda SADECE:
  - Ensemble % (primary başarı)
  - Ensemble tahmin + güven (yeni: 24sp, büyük font)
  - Tier info (tekil/çiftli/beklemede)
  - ★ Yan başarı + yan tahmin + güven
  - Meta güven, Rejim, Anomali
  - Son 6 değer
- Kombine ve Kalıp için ayrı başarı satırları ANA EKRANDA yok.
- Per-axis (OE/SB) döküm yok.
- Başlıkta "FAN v2.4" görünür.
- Ensemble için "Doğru: X/Y (N beklemede)" formatında bilgi.

### 7. MethodStatsDialog Güncellendi
- 13 yöntem + ★ Ensemble + ★ Yan satırı.
- "Kombine" satırı tamamen kaldırıldı.
- Summary kartında "Beklemede (tahmin yok)" satırı eklendi.
- Ensemble doğruluğu "verdiği tahminler üzerinden" hesaplanıyor.

### 8. Overlay Güncellemesi
- 3 satır: Ensemble (en büyük), Kalıp (K:), Yan (Y:).
- Kombine satırı yok.
- Tier mantığı overlayde de: `--` / `pri/sec` / `pri`.
- Yan çapraz formda yeşil renk, tek harfte mor, `--`da gri.
- Bildirim: "Overlay çalışıyor (v2.4)".

### 9. Version
- versionCode = 6, versionName = "2.4"
- SettingsDialog: "FAN v2.4"
- OverlayService notifikasyonu: "v2.4"
- Ana başlık: "FAN v2.4"

### 10. CSV Uyumluluğu
- Header aynı kalır (kombine sütunları yerinde).
- Yeni verilerde kombine sütunları "0/HAYIR/%0" olarak yazılır.
- Eski kayıtlar sorunsuz okunur; `ensembleTier` alanı eski veriler için `ensemblePrediction==0→NONE, isDouble→DOUBLE, else→SINGLE` şeklinde geriye dönük çıkarılır.

### 11. Diğer
- `StatsResult` sadeleştirildi: `sideOeAccuracy/sideSbAccuracy/sideBothAccuracy/combinedAccuracy` kaldırıldı. Yerine `evaluatedWithPrediction`, `noPredictionCount`, `sideNoPredCount` eklendi.
- Side prediction CAP değeri 0.76'dan 0.88'e çıkarıldı (yüksek güvenlere izin).
- Kalıp ikincil doğru sayımı `RollingStats.kalipSecCorrect` tutuluyor ama CSV'ye yazılmıyor (sadece dahili).
