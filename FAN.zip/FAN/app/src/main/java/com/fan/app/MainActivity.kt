package com.fan.app

import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import com.fan.app.data.CsvManager
import com.fan.app.data.DataEntry
import com.fan.app.engine.PredictionEngine
import com.fan.app.overlay.OverlayService
import com.fan.app.ui.MethodStatsDialog
import com.fan.app.ui.SettingsDialog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var csvManager: CsvManager
    private lateinit var engine: PredictionEngine

    private lateinit var tvOverlayStatus: TextView
    private lateinit var btnOverlayToggle: Button
    private lateinit var tvTotalCount: TextView
    private lateinit var tvCorrectCount: TextView
    private lateinit var tvAccuracy: TextView
    private lateinit var progressAccuracy: ProgressBar
    private lateinit var tvMetaConfidence: TextView
    private lateinit var tvCurrentRegime: TextView
    private lateinit var tvAnomalyStatus: TextView
    private lateinit var tvSidePrediction: TextView
    private lateinit var tvSideIndependent: TextView

    private val overlayPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (Settings.canDrawOverlays(this)) {
            startOverlayService()
        } else {
            Toast.makeText(this, "Overlay izni verilmedi", Toast.LENGTH_SHORT).show()
            updateOverlayStatus()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        csvManager = CsvManager(this)
        engine = PredictionEngine(csvManager)

        initViews()
        setupListeners()
    }

    override fun onResume() {
        super.onResume()
        updateOverlayStatus()
        refreshStats()
    }

    private fun initViews() {
        tvOverlayStatus = findViewById(R.id.tvOverlayStatus)
        btnOverlayToggle = findViewById(R.id.btnOverlayToggle)
        tvTotalCount = findViewById(R.id.tvTotalCount)
        tvCorrectCount = findViewById(R.id.tvCorrectCount)
        tvAccuracy = findViewById(R.id.tvAccuracy)
        progressAccuracy = findViewById(R.id.progressAccuracy)
        tvMetaConfidence = findViewById(R.id.tvMetaConfidence)
        tvCurrentRegime = findViewById(R.id.tvCurrentRegime)
        tvAnomalyStatus = findViewById(R.id.tvAnomalyStatus)
        tvSidePrediction = findViewById(R.id.tvSidePrediction)
        tvSideIndependent = findViewById(R.id.tvSideIndependent)
    }

    private fun setupListeners() {
        btnOverlayToggle.setOnClickListener {
            if (OverlayService.isRunning) stopOverlay() else startOverlay()
        }

        findViewById<Button>(R.id.btnRefreshStats).setOnClickListener {
            refreshStats()
        }

        findViewById<Button>(R.id.btnQuick1).setOnClickListener { quickEntry(1) }
        findViewById<Button>(R.id.btnQuick2).setOnClickListener { quickEntry(2) }
        findViewById<Button>(R.id.btnQuick3).setOnClickListener { quickEntry(3) }
        findViewById<Button>(R.id.btnQuick4).setOnClickListener { quickEntry(4) }

        findViewById<Button>(R.id.btnMethodStats).setOnClickListener {
            showMethodStatsDialog()
        }

        findViewById<Button>(R.id.btnSettings).setOnClickListener {
            SettingsDialog(this).apply {
                setOnDismissListener {
                    sendOverlayCommand(OverlayService.ACTION_APPLY_SETTINGS)
                }
            }.show()
        }

        findViewById<Button>(R.id.btnExport).setOnClickListener {
            exportData()
        }

        findViewById<Button>(R.id.btnClearData).setOnClickListener {
            showClearConfirmDialog()
        }
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            overlayPermissionLauncher.launch(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
            return
        }
        startOverlayService()
    }

    private fun startOverlayService() {
        try {
            startForegroundService(Intent(this, OverlayService::class.java))
        } catch (e: Exception) {
            Toast.makeText(this, "Overlay başlatılamadı: ${e.message}", Toast.LENGTH_LONG).show()
        }
        updateOverlayStatus()
    }

    private fun stopOverlay() {
        stopService(Intent(this, OverlayService::class.java))
        updateOverlayStatus()
    }

    private fun updateOverlayStatus() {
        val running = OverlayService.isRunning
        tvOverlayStatus.text =
            if (running) getString(R.string.overlay_status_on)
            else getString(R.string.overlay_status_off)

        btnOverlayToggle.text =
            if (running) getString(R.string.overlay_stop)
            else getString(R.string.overlay_start)

        btnOverlayToggle.backgroundTintList = ColorStateList.valueOf(
            ContextCompat.getColor(
                this,
                if (running) R.color.colorError else R.color.colorPrimary
            )
        )
    }

    private fun quickEntry(value: Int) {
        lifecycleScope.launch {
            try {
                engine.onNewValue(value)
                refreshStatsInternal()
                sendOverlayCommand(OverlayService.ACTION_REFRESH)
                Toast.makeText(this@MainActivity, "$value girildi", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "Hata: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun refreshStats() {
        lifecycleScope.launch {
            refreshStatsInternal()
        }
    }

    private suspend fun refreshStatsInternal() {
        val stats = engine.getStats()

        tvTotalCount.text = "Toplam Kayıt: ${stats.totalCount}"
        tvCorrectCount.text =
            "Primary: ${stats.correctCount}/${stats.evaluatedCount} · Toplam: ${stats.totalCorrectCount}"

        val pct = (stats.accuracy * 100).toInt().coerceIn(0, 100)
        tvAccuracy.text = "Doğruluk: %$pct"
        progressAccuracy.progress = pct

        val currentPred = engine.getCurrentPrediction()
        val result = currentPred.ensembleResult

        if (result != null) {
            tvMetaConfidence.text = "Meta Güven: ${(result.metaConfidence * 100).toInt()}%"
            tvCurrentRegime.text = "Rejim: ${result.currentRegime.replace("_", " ")}"

            val anomalyCount = result.anomalyInfo?.anomalies?.size ?: 0
            if (anomalyCount > 0) {
                tvAnomalyStatus.text = "⚠ $anomalyCount Anomali · Kaos: ${(result.chaosScore).toInt()}"
                tvAnomalyStatus.setTextColor(
                    ContextCompat.getColor(this, R.color.colorError)
                )
            } else {
                tvAnomalyStatus.text = "✓ Normal · Kaos: ${(result.chaosScore).toInt()}"
                tvAnomalyStatus.setTextColor(
                    ContextCompat.getColor(this, R.color.colorAccent)
                )
            }

            tvSidePrediction.text = "Yan Std: ${result.sideStandardFormatted}"
            tvSideIndependent.text = "Yan Rejim: ${result.sideRegimeFormatted} · [${result.sideDisplay}]"
        } else {
            tvMetaConfidence.text = "Meta Güven: --"
            tvCurrentRegime.text = "Rejim: --"
            tvAnomalyStatus.text = "--"
            tvAnomalyStatus.setTextColor(
                ContextCompat.getColor(this, R.color.colorTextSecondary)
            )
            tvSidePrediction.text = "Yan Std: --"
            tvSideIndependent.text = "Yan Rejim: --"
        }
    }

    private fun showMethodStatsDialog() {
        lifecycleScope.launch {
            try {
                val stats = engine.getStats()
                val activeStats = withContext(Dispatchers.IO) {
                    val allEntries = csvManager.readAllEntries()
                    val lastEntry = allEntries.lastOrNull() ?: return@withContext null

                    val activeList = (0 until DataEntry.METHOD_COUNT).map { idx ->
                        val name = DataEntry.METHOD_NAMES[idx].replace("_", " ")
                        val isActive = !lastEntry.getMethodMuted(idx)
                        Triple(name, if (isActive) 1 else 0, if (isActive) 1 else 0)
                    }.toMutableList()

                    // Yan tahminler ayrı yöntem gibi
                    activeList.add(Triple("Yan Tahmin (Standart)", 1, 1))
                    activeList.add(Triple("Yan Tahmin (Rejim)", 1, 1))

                    activeList
                }

                MethodStatsDialog(this@MainActivity, stats.methodStats, activeStats).show()
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "Hata: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun exportData() {
        try {
            val uri = FileProvider.getUriForFile(
                this,
                "$packageName.provider",
                csvManager.exportFile()
            )

            startActivity(
                Intent.createChooser(
                    Intent(Intent.ACTION_SEND).apply {
                        type = "text/csv"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    },
                    "CSV Dışa Aktar"
                )
            )
        } catch (e: Exception) {
            Toast.makeText(this, "Hata: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun showClearConfirmDialog() {
        AlertDialog.Builder(this)
            .setTitle("Verileri Temizle")
            .setMessage("Tüm veriler silinecek. Emin misiniz?")
            .setPositiveButton("Sil") { _, _ ->
                engine.clearAll()
                refreshStats()
                sendOverlayCommand(OverlayService.ACTION_REFRESH)
                Toast.makeText(this, "Veriler silindi", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("İptal", null)
            .show()
    }

    private fun sendOverlayCommand(action: String) {
        if (!OverlayService.isRunning) return
        try {
            startService(
                Intent(this, OverlayService::class.java).apply {
                    this.action = action
                }
            )
        } catch (_: Exception) {
        }
    }
}