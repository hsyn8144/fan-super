package com.fan.app.data

import android.content.Context
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.Date

class CsvManager(private val context: Context) {

    private val fileName = "fan_data.csv"
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
    private val csvFile: File get() = File(context.filesDir, fileName)

    private val header: String
        get() {
            val sb = StringBuilder()

            sb.append("id|tarih|sayi|onceki_tahmin_id|veri_sayisi")

            sb.append("|ensemble_tahmin_1|ensemble_tahmin_2|ensemble_cift_mi|ensemble_guven")
            sb.append("|ensemble_1_dogru|ensemble_2_dogru|ensemble_toplam_dogru")
            sb.append("|ensemble_1_basari|ensemble_2_basari|ensemble_toplam_basari")

            sb.append("|kombine_tahmin_1|kombine_tahmin_2|kombine_cift_mi|kombine_guven")
            sb.append("|kombine_1_dogru|kombine_2_dogru|kombine_toplam_dogru")
            sb.append("|kombine_1_basari|kombine_2_basari|kombine_toplam_basari")

            sb.append("|kalip_tahmin_1|kalip_tahmin_2|kalip_cift_mi|kalip_guven")
            sb.append("|kalip_1_dogru|kalip_2_dogru|kalip_toplam_dogru")
            sb.append("|kalip_1_basari|kalip_2_basari|kalip_toplam_basari")

            sb.append("|yan_standart_tahmin|yan_standart_dogru|yan_standart_cift_dogru|yan_standart_basari|yan_standart_cift_basari")
            sb.append("|yan_rejim_tahmin|yan_rejim_dogru|yan_rejim_cift_dogru|yan_rejim_basari|yan_rejim_cift_basari")
            sb.append("|yan_gosterim|yan_final_dogru|yan_final_cift_dogru|yan_final_basari|yan_final_cift_basari")

            sb.append("|rejim_mevcut|rejim_onceki|rejim_kararli_tur")
            sb.append("|kalip_eslesen_uzunluk|kalip_eslesen_adet|kalip_rejimi|rejim_benzerlik_skoru")
            sb.append("|kaos_skoru|kalip_kirilan_uzunluk|anomali_bayraklar|guven_ayarli|aktif_model_sayisi")

            sb.append("|susturulan_modeller|odullendirilen_modeller|geri_donen_modeller|yedek_model|karar_gerekce")

            for (name in DataEntry.METHOD_NAMES) {
                sb.append("|${name}_aktif")
                sb.append("|${name}_susturuldu")
                sb.append("|${name}_seri_dogru")
                sb.append("|${name}_seri_yanlis")
                sb.append("|${name}_carpan")
                sb.append("|${name}_final_tahmin1")
                sb.append("|${name}_final_tahmin2")
                sb.append("|${name}_final_guven")
                sb.append("|${name}_dogru")
                sb.append("|${name}_basari")
            }

            for (traceHeader in DataEntry.TRACE_HEADERS) {
                sb.append("|$traceHeader")
            }

            sb.append("\n")
            return sb.toString()
        }

    fun ensureFileExists() {
        if (!csvFile.exists()) {
            csvFile.createNewFile()
            csvFile.writeText(header)
            return
        }

        val lines = csvFile.readLines()
        if (lines.isEmpty()) {
            csvFile.writeText(header)
            return
        }

        // CSV header migration: eski header varsa yeni yapıya taşı
        val existingHeader = lines.first().trimEnd()
        val expectedHeader = header.trimEnd()

        if (existingHeader != expectedHeader) {
            migrateHeader(lines, existingHeader)
        }
    }

    /**
     * Eski CSV'yi yeni header'a uyumlu olarak taşır.
     * Var olan kolonların verisi korunur, yeni kolonlar boş başlar.
     */
    private fun migrateHeader(lines: List<String>, oldHeaderLine: String) {
        val oldHeaders = oldHeaderLine.split("|")
        val newHeaders = header.trimEnd().split("|")

        if (oldHeaders == newHeaders) return

        val migrated = mutableListOf<String>()
        migrated.add(header.trimEnd())

        for (line in lines.drop(1)) {
            if (line.isBlank()) continue
            val oldCols = line.split("|")
            val oldMap = mutableMapOf<String, String>()
            for (i in oldHeaders.indices) {
                oldMap[oldHeaders[i]] = oldCols.getOrNull(i) ?: ""
            }

            val newLine = newHeaders.joinToString("|") { h -> oldMap[h] ?: "" }
            migrated.add(newLine)
        }

        csvFile.writeText(migrated.joinToString("\n") + "\n")
    }

    fun appendEntry(entry: DataEntry) {
        ensureFileExists()
        FileWriter(csvFile, true).use {
            it.append(entryToLine(entry)).append("\n")
        }
    }

    fun updateLastEntry(entry: DataEntry) {
        val lines = csvFile.readLines().toMutableList()
        if (lines.size < 2) return
        lines[lines.size - 1] = entryToLine(entry)
        csvFile.writeText(lines.joinToString("\n") + "\n")
    }

    fun readAllEntries(): List<DataEntry> {
        ensureFileExists()
        val lines = csvFile.readLines()
        if (lines.size <= 1) return emptyList()
        return lines.drop(1)
            .filter { it.isNotBlank() }
            .mapNotNull { parseLine(it) }
    }

    fun readValues(): List<Int> = readAllEntries().map { it.value }

    fun deleteLastEntry() {
        val lines = csvFile.readLines().toMutableList()
        if (lines.size <= 1) return
        lines.removeAt(lines.size - 1)
        csvFile.writeText(lines.joinToString("\n") + "\n")
    }

    fun clearAll() {
        csvFile.writeText(header)
    }

    fun exportFile(): File = csvFile

    fun getTotalCount(): Int = readAllEntries().size

    fun getEnsembleStats(): Triple<Int, Int, Int> {
        val entries = readAllEntries().drop(DataEntry.INTERNAL_THRESHOLD)
        if (entries.isEmpty()) return Triple(0, 0, 0)
        val primary = entries.count { it.ensemblePrimary1Correct }
        val total = entries.count { it.ensembleTotalCorrect }
        return Triple(primary, total, entries.size)
    }

    /**
     * Tüm başarılar:
     * doğru_sayısı / (toplam_veri - 5)
     *
     * Sessizde olsa bile modelin tahmini var, o yüzden payda değişmez.
     * Yan tahminler de buraya yöntem gibi eklenir.
     */
    fun getMethodStats(): List<Triple<String, Int, Int>> {
        val entries = readAllEntries().drop(DataEntry.INTERNAL_THRESHOLD)
        if (entries.isEmpty()) return emptyList()

        val totalEvaluated = entries.size
        val statsList = mutableListOf<Triple<String, Int, Int>>()

        // 13 model
        for (i in 0 until DataEntry.METHOD_COUNT) {
            val name = DataEntry.METHOD_NAMES[i].replace("_", " ")
            val correct = entries.count { it.getMethodCorrect(i) }
            statsList.add(Triple(name, correct, totalEvaluated))
        }

        // Yan tahminler
        val sideStandardCorrect = entries.count { it.sideStandardCorrect }
        statsList.add(Triple("Yan Tahmin (Standart)", sideStandardCorrect, totalEvaluated))

        val sideRegimeCorrect = entries.count { it.sideRegimeCorrect }
        statsList.add(Triple("Yan Tahmin (Rejim)", sideRegimeCorrect, totalEvaluated))

        return statsList.sortedByDescending {
            if (it.third > 0) it.second.toDouble() / it.third else 0.0
        }
    }

    private fun entryToLine(e: DataEntry): String {
        val sb = StringBuilder()

        sb.append("${e.id}|${dateFormat.format(Date(e.timestamp))}|${e.value}|${e.previousPredictionId}|${e.dataCount}")

        sb.append("|${e.ensemblePrediction1}|${e.ensemblePrediction2}|${d(e.ensembleIsDouble)}|${pct(e.ensembleConfidence)}")
        sb.append("|${d(e.ensemblePrimary1Correct)}|${d(e.ensemblePrimary2Correct)}|${d(e.ensembleTotalCorrect)}")
        sb.append("|${pct(e.ensemblePrimary1Accuracy)}|${pct(e.ensemblePrimary2Accuracy)}|${pct(e.ensembleTotalAccuracy)}")

        sb.append("|${e.combinedPrediction1}|${e.combinedPrediction2}|${d(e.combinedIsDouble)}|${pct(e.combinedConfidence)}")
        sb.append("|${d(e.combinedPrimary1Correct)}|${d(e.combinedPrimary2Correct)}|${d(e.combinedTotalCorrect)}")
        sb.append("|${pct(e.combinedPrimary1Accuracy)}|${pct(e.combinedPrimary2Accuracy)}|${pct(e.combinedTotalAccuracy)}")

        sb.append("|${e.kalipPrediction1}|${e.kalipPrediction2}|${d(e.kalipIsDouble)}|${pct(e.kalipConfidence)}")
        sb.append("|${d(e.kalipPrimary1Correct)}|${d(e.kalipPrimary2Correct)}|${d(e.kalipTotalCorrect)}")
        sb.append("|${pct(e.kalipPrimary1Accuracy)}|${pct(e.kalipPrimary2Accuracy)}|${pct(e.kalipTotalAccuracy)}")

        sb.append("|${sanitize(e.sideStandardPrediction)}|${d(e.sideStandardCorrect)}|${d(e.sideStandardDoubleCorrect)}|${pct(e.sideStandardAccuracy)}|${pct(e.sideStandardDoubleAccuracy)}")
        sb.append("|${sanitize(e.sideRegimePrediction)}|${d(e.sideRegimeCorrect)}|${d(e.sideRegimeDoubleCorrect)}|${pct(e.sideRegimeAccuracy)}|${pct(e.sideRegimeDoubleAccuracy)}")
        sb.append("|${sanitize(e.sideDisplayPrediction)}|${d(e.sideFinalCorrect)}|${d(e.sideFinalDoubleCorrect)}|${pct(e.sideFinalAccuracy)}|${pct(e.sideFinalDoubleAccuracy)}")

        sb.append("|${sanitize(e.currentRegime)}|${sanitize(e.previousRegime)}|${e.regimeStableCount}")
        sb.append("|${e.matchedPatternLength}|${e.matchedPatternCount}|${sanitize(e.matchedPatternRegime)}|${pct(e.regimeSimilarityScore)}")
        sb.append("|${pct(e.chaosScore)}|${e.patternBreakLength}|${sanitize(e.anomalyFlags)}|${d(e.confidenceAdjusted)}|${e.activeModelCount}")

        sb.append("|${sanitize(e.mutedModels)}|${sanitize(e.rewardedModels)}|${sanitize(e.returnedModels)}|${sanitize(e.fallbackModel)}|${sanitize(e.decisionReason)}")

        for (i in 0 until DataEntry.METHOD_COUNT) {
            sb.append("|${d(e.getMethodActive(i))}")
            sb.append("|${d(e.getMethodMuted(i))}")
            sb.append("|${e.getMethodStreakSuccess(i)}")
            sb.append("|${e.getMethodStreakFail(i)}")
            sb.append("|${pct(e.getMethodVoteMultiplier(i))}")
            sb.append("|${e.getMethodFinalPrediction1(i)}")
            sb.append("|${e.getMethodFinalPrediction2(i)}")
            sb.append("|${pct(e.getMethodFinalConfidence(i))}")
            sb.append("|${d(e.getMethodCorrect(i))}")
            sb.append("|${pct(e.getMethodAccuracy(i))}")
        }

        for (traceHeader in DataEntry.TRACE_HEADERS) {
            sb.append("|${sanitize(e.getTrace(traceHeader))}")
        }

        return sb.toString()
    }

    fun parseLine(line: String): DataEntry? {
        return try {
            val c = line.split("|")
            if (c.size < 50) return null

            var idx = 0

            fun s(): String = c.getOrNull(idx++)?.trim() ?: ""
            fun i(): Int = s().toIntOrNull() ?: 0
            fun l(): Long = s().toLongOrNull() ?: 0L
            fun b(): Boolean {
                val v = s().uppercase()
                return v == "EVET" || v == "1" || v == "TRUE"
            }
            fun p(): Double = s().removeSuffix("%").toDoubleOrNull()?.div(100.0) ?: 0.0
            fun ts(): Long = try {
                dateFormat.parse(s())?.time ?: 0L
            } catch (e: Exception) {
                0L
            }

            val entry = DataEntry()

            entry.id = l()
            entry.timestamp = ts()
            entry.value = i()
            entry.previousPredictionId = l()
            entry.dataCount = i()

            entry.ensemblePrediction1 = i()
            entry.ensemblePrediction2 = i()
            entry.ensembleIsDouble = b()
            entry.ensembleConfidence = p()
            entry.ensemblePrimary1Correct = b()
            entry.ensemblePrimary2Correct = b()
            entry.ensembleTotalCorrect = b()
            entry.ensemblePrimary1Accuracy = p()
            entry.ensemblePrimary2Accuracy = p()
            entry.ensembleTotalAccuracy = p()

            entry.combinedPrediction1 = i()
            entry.combinedPrediction2 = i()
            entry.combinedIsDouble = b()
            entry.combinedConfidence = p()
            entry.combinedPrimary1Correct = b()
            entry.combinedPrimary2Correct = b()
            entry.combinedTotalCorrect = b()
            entry.combinedPrimary1Accuracy = p()
            entry.combinedPrimary2Accuracy = p()
            entry.combinedTotalAccuracy = p()

            entry.kalipPrediction1 = i()
            entry.kalipPrediction2 = i()
            entry.kalipIsDouble = b()
            entry.kalipConfidence = p()
            entry.kalipPrimary1Correct = b()
            entry.kalipPrimary2Correct = b()
            entry.kalipTotalCorrect = b()
            entry.kalipPrimary1Accuracy = p()
            entry.kalipPrimary2Accuracy = p()
            entry.kalipTotalAccuracy = p()

            entry.sideStandardPrediction = s()
            entry.sideStandardCorrect = b()
            entry.sideStandardDoubleCorrect = b()
            entry.sideStandardAccuracy = p()
            entry.sideStandardDoubleAccuracy = p()

            entry.sideRegimePrediction = s()
            entry.sideRegimeCorrect = b()
            entry.sideRegimeDoubleCorrect = b()
            entry.sideRegimeAccuracy = p()
            entry.sideRegimeDoubleAccuracy = p()

            entry.sideDisplayPrediction = s()
            entry.sideFinalCorrect = b()
            entry.sideFinalDoubleCorrect = b()
            entry.sideFinalAccuracy = p()
            entry.sideFinalDoubleAccuracy = p()

            entry.currentRegime = s()
            entry.previousRegime = s()
            entry.regimeStableCount = i()
            entry.matchedPatternLength = i()
            entry.matchedPatternCount = i()
            entry.matchedPatternRegime = s()
            entry.regimeSimilarityScore = p()
            entry.chaosScore = p()
            entry.patternBreakLength = i()
            entry.anomalyFlags = s()
            entry.confidenceAdjusted = b()
            entry.activeModelCount = i()

            entry.mutedModels = s()
            entry.rewardedModels = s()
            entry.returnedModels = s()
            entry.fallbackModel = s()
            entry.decisionReason = s()

            for (methodIndex in 0 until DataEntry.METHOD_COUNT) {
                val active = b()
                val muted = b()
                val streakSuccess = i()
                val streakFail = i()
                val voteMultiplier = p()
                val finalPrediction1 = i()
                val finalPrediction2 = i()
                val finalConfidence = p()
                val correct = b()
                val accuracy = p()

                entry.setMethodCore(
                    index = methodIndex,
                    active = active,
                    muted = muted,
                    streakSuccess = streakSuccess,
                    streakFail = streakFail,
                    voteMultiplier = voteMultiplier,
                    finalPrediction1 = finalPrediction1,
                    finalPrediction2 = finalPrediction2,
                    finalConfidence = finalConfidence,
                    correct = correct,
                    accuracy = accuracy
                )
            }

            for (traceHeader in DataEntry.TRACE_HEADERS) {
                if (idx >= c.size) break
                entry.traceColumns[traceHeader] = c[idx]
                idx++
            }

            entry
        } catch (e: Exception) {
            null
        }
    }

    private fun d(v: Boolean): String = if (v) "EVET" else "HAYIR"

    private fun pct(v: Double): String =
        String.format(Locale.US, "%%%d", (v * 100).toInt())

    private fun sanitize(v: String): String =
        v.replace("|", "/").replace("\n", " ").replace("\r", " ")
}