package com.fan.app.engine

import com.fan.app.data.CsvManager
import com.fan.app.data.DataEntry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.util.Locale

class PredictionEngine(private val csvManager: CsvManager) {

    private val mutex = Mutex()
    private var lastComputedResult: Ensemble.EnsembleResult? = null
    private var isMemoryInitialized = false

    private data class MethodOutcome(
        val methodIndex: Int,
        val finalCorrect: Boolean,
        val nativeCorrect: Boolean,
        val patternCorrect: Boolean,
        val regimeCorrect: Boolean,
        val metaCorrect: Boolean,
        val supportCorrect: Boolean,
        val supportSharedSuccess: Boolean,
        val basariKaynagi: String // YENİ
    )

    private fun ensureMemoryInitialized() {
        if (!isMemoryInitialized) {
            val allEntries = csvManager.readAllEntries()
            val allData = allEntries.map { it.value }

            ContextualMemory.initializeFromEntries(allEntries, allData)
            initializeMeritCouncilFromHistory(allEntries)

            if (allData.size >= DataEntry.INTERNAL_THRESHOLD) {
                lastComputedResult = Ensemble.compute(allData, allEntries)
            } else {
                lastComputedResult = null
            }

            isMemoryInitialized = true
        }
    }

    private fun initializeMeritCouncilFromHistory(entries: List<DataEntry>) {
        MeritCouncil.reset()
        if (entries.size < DataEntry.INTERNAL_THRESHOLD + 1) return

        for (i in DataEntry.INTERNAL_THRESHOLD until entries.size - 1) {
            val entry = entries[i]
            val nextValue = entries[i + 1].value
            val chaosScore = entry.chaosScore // O satırdaki kaos

            for (methodIdx in 0 until DataEntry.METHOD_COUNT) {
                val prediction = entry.getMethodFinalPrediction1(methodIdx)
                if (prediction <= 0) continue

                val finalCorrect = prediction == nextValue

                val name = DataEntry.METHOD_NAMES[methodIdx]
                val traceNativeCorrect = parseTraceBool(entry.getTrace("${name}_native_dogru"))
                val tracePatternCorrect = parseTraceBool(entry.getTrace("${name}_kalip_dogru"))
                val traceRegimeCorrect = parseTraceBool(entry.getTrace("${name}_rejim_dogru"))
                val traceMetaCorrect = parseTraceBool(entry.getTrace("${name}_meta_dogru"))
                val traceSharedSupport = parseTraceBool(entry.getTrace("${name}_destek_paylasimli_basari"))
                val traceSource = entry.getTrace("${name}_final_secim_kaynagi").trim()

                val nativeCorrect = traceNativeCorrect
                    ?: (finalCorrect && (traceSource.isBlank() || traceSource == "NATIVE"))

                val supportCorrect = finalCorrect && !nativeCorrect && (
                        (tracePatternCorrect ?: false) ||
                                (traceRegimeCorrect ?: false) ||
                                (traceMetaCorrect ?: false) ||
                                traceSource in listOf("PATTERN", "REGIME", "META", "BLENDED", "BIAS_SHIFTED")
                        )

                val supportSharedSuccess = traceSharedSupport ?: false

                MeritCouncil.updateAfterResult(
                    methodIndex = methodIdx,
                    finalCorrect = finalCorrect,
                    nativeCorrect = nativeCorrect,
                    supportCorrect = supportCorrect,
                    supportSharedSuccess = supportSharedSuccess,
                    chaosScore = chaosScore // YENİ
                )
            }
        }
    }

    suspend fun onNewValue(value: Int): EngineResult = withContext(Dispatchers.Default) {
        mutex.withLock {
            ensureMemoryInitialized()

            val allEntries = csvManager.readAllEntries()
            val allDataBefore = allEntries.map { it.value }.toMutableList()
            val totalBefore = allDataBefore.size

            val allDataAfter = allDataBefore.toMutableList().apply { add(value) }
            val currentDataCount = allDataAfter.size

            if (currentDataCount <= DataEntry.INTERNAL_THRESHOLD) {
                val newEntry = buildRawEntry(
                    id = currentDataCount.toLong(),
                    value = value,
                    dataCount = currentDataCount
                )
                csvManager.appendEntry(newEntry)

                val entriesAfterAppend = allEntries + newEntry
                if (allDataAfter.size >= DataEntry.INTERNAL_THRESHOLD) {
                    lastComputedResult = Ensemble.compute(allDataAfter, entriesAfterAppend)
                }

                return@withLock EngineResult(
                    ensembleResult = lastComputedResult,
                    isSilent = currentDataCount <= DataEntry.SILENT_THRESHOLD,
                    totalDataCount = currentDataCount,
                    recentValues = allDataAfter.takeLast(6).reversed()
                )
            }

            val previousPredictionResult = lastComputedResult
                ?: Ensemble.compute(allDataBefore, allEntries).also { lastComputedResult = it }

            val outcomes = buildMethodOutcomes(previousPredictionResult, value)

            for (methodIdx in 0 until DataEntry.METHOD_COUNT) {
                val outcome = outcomes[methodIdx] ?: continue

                MeritCouncil.updateAfterResult(
                    methodIndex = methodIdx,
                    finalCorrect = outcome.finalCorrect,
                    nativeCorrect = outcome.nativeCorrect,
                    supportCorrect = outcome.supportCorrect,
                    supportSharedSuccess = outcome.supportSharedSuccess,
                    chaosScore = previousPredictionResult.chaosScore // YENİ
                )

                val vote = previousPredictionResult.methodVotes.find { it.methodIndex == methodIdx }
                if (vote != null && vote.finalPrediction1 > 0) {
                    MethodWeightTracker.update(methodIdx, vote.finalPrediction1, value)
                }
            }

            val newEntry = buildShiftedEntry(
                id = currentDataCount.toLong(),
                actualValue = value,
                predictionSourceId = totalBefore.toLong(),
                predictionResult = previousPredictionResult,
                allEntries = allEntries,
                dataCount = currentDataCount,
                outcomes = outcomes
            )

            csvManager.appendEntry(newEntry)
            val entriesAfterAppend = allEntries + newEntry

            ContextualMemory.updateWithNewEntry(
                entry = newEntry,
                allData = allDataAfter,
                previousRegime = previousPredictionResult.previousRegime,
                patternBroken = previousPredictionResult.patternBreakLength > 0,
                brokenPatternLength = previousPredictionResult.patternBreakLength,
                ensembleCorrect = previousPredictionResult.finalPrediction1 == value
            )

            val nextPredictionResult = Ensemble.compute(allDataAfter, entriesAfterAppend)
            lastComputedResult = nextPredictionResult

            EngineResult(
                ensembleResult = nextPredictionResult,
                isSilent = currentDataCount <= DataEntry.SILENT_THRESHOLD,
                totalDataCount = currentDataCount,
                recentValues = allDataAfter.takeLast(6).reversed()
            )
        }
    }

    suspend fun deleteLastValue(): EngineResult? = withContext(Dispatchers.Default) {
        mutex.withLock {
            val allEntries = csvManager.readAllEntries()
            if (allEntries.isEmpty()) return@withLock null

            csvManager.deleteLastEntry()

            val remainingEntries = csvManager.readAllEntries()
            val remainingData = remainingEntries.map { it.value }

            isMemoryInitialized = false
            ensureMemoryInitialized()

            val result = if (remainingData.size >= DataEntry.INTERNAL_THRESHOLD) {
                Ensemble.compute(remainingData, remainingEntries).also { lastComputedResult = it }
            } else {
                lastComputedResult = null
                null
            }

            EngineResult(
                ensembleResult = result,
                isSilent = remainingData.size <= DataEntry.SILENT_THRESHOLD,
                totalDataCount = remainingData.size,
                recentValues = remainingData.takeLast(6).reversed()
            )
        }
    }

    suspend fun getCurrentPrediction(): EngineResult = withContext(Dispatchers.Default) {
        ensureMemoryInitialized()

        val allEntries = csvManager.readAllEntries()
        val allData = allEntries.map { it.value }

        val result = if (allData.size >= DataEntry.INTERNAL_THRESHOLD) {
            Ensemble.compute(allData, allEntries).also { lastComputedResult = it }
        } else {
            null
        }

        EngineResult(
            ensembleResult = result,
            isSilent = allData.size <= DataEntry.SILENT_THRESHOLD,
            totalDataCount = allData.size,
            recentValues = allData.takeLast(6).reversed()
        )
    }

    suspend fun getStats(): StatsResult = withContext(Dispatchers.Default) {
        val (primary, totalHits, size) = csvManager.getEnsembleStats()
        val totalAll = csvManager.getTotalCount()
        val methodStats = csvManager.getMethodStats()

        StatsResult(
            totalCount = totalAll,
            evaluatedCount = size,
            correctCount = primary,
            totalCorrectCount = totalHits,
            accuracy = if (size > 0) primary.toDouble() / size else 0.0,
            methodStats = methodStats
        )
    }

    private fun buildMethodOutcomes(
        predictionResult: Ensemble.EnsembleResult,
        actualValue: Int
    ): Map<Int, MethodOutcome> {
        val prelim = mutableMapOf<Int, MethodOutcome>()

        for (vote in predictionResult.methodVotes) {
            val nativeCorrect = vote.nativePrediction1 == actualValue
            val patternCorrect = vote.patternPrediction1 == actualValue
            val regimeCorrect = vote.regimePrediction1 == actualValue
            val metaCorrect = vote.metaPrediction1 == actualValue
            val finalCorrect = vote.finalPrediction1 == actualValue

            val supportCorrect = finalCorrect && !nativeCorrect && (
                    patternCorrect || regimeCorrect || metaCorrect ||
                            vote.decisionSource != DecisionSource.NATIVE
                    )

            // YENİ: Başarı kaynağını tek String olarak özetle
            val basariKaynagi = when {
                !finalCorrect -> "NONE"
                nativeCorrect -> "NATIVE"
                patternCorrect -> "PATTERN_SUPPORT"
                regimeCorrect -> "REGIME_SUPPORT"
                metaCorrect -> "META_SUPPORT"
                vote.decisionSource == DecisionSource.BLENDED -> "BLENDED"
                else -> "SUPPORTED_OTHER"
            }

            prelim[vote.methodIndex] = MethodOutcome(
                methodIndex = vote.methodIndex,
                finalCorrect = finalCorrect,
                nativeCorrect = nativeCorrect,
                patternCorrect = patternCorrect,
                regimeCorrect = regimeCorrect,
                metaCorrect = metaCorrect,
                supportCorrect = supportCorrect,
                supportSharedSuccess = false,
                basariKaynagi = basariKaynagi
            )
        }

        val groupedByPrediction = prelim.values
            .filter { it.supportCorrect }
            .groupBy { predictionResult.methodVotes.firstOrNull { mv -> mv.methodIndex == it.methodIndex }?.finalPrediction1 ?: 0 }

        for ((methodIdx, outcome) in prelim) {
            if (!outcome.supportCorrect) continue
            val finalPred = predictionResult.methodVotes
                .firstOrNull { it.methodIndex == methodIdx }?.finalPrediction1 ?: 0
            val sameGroupCount = groupedByPrediction[finalPred]?.size ?: 0
            if (sameGroupCount >= 2) {
                prelim[methodIdx] = outcome.copy(
                    supportSharedSuccess = true,
                    basariKaynagi = "SHARED_SUPPORT" // YENİ
                )
            }
        }

        return prelim
    }

    private fun buildRawEntry(id: Long, value: Int, dataCount: Int): DataEntry {
        val entry = DataEntry()
        entry.id = id
        entry.timestamp = System.currentTimeMillis()
        entry.value = value
        entry.previousPredictionId = 0
        entry.dataCount = dataCount
        return entry
    }

    private fun buildShiftedEntry(
        id: Long,
        actualValue: Int,
        predictionSourceId: Long,
        predictionResult: Ensemble.EnsembleResult,
        allEntries: List<DataEntry>,
        dataCount: Int,
        outcomes: Map<Int, MethodOutcome>
    ): DataEntry {
        val entry = DataEntry()
        entry.id = id
        entry.timestamp = System.currentTimeMillis()
        entry.value = actualValue
        entry.previousPredictionId = predictionSourceId
        entry.dataCount = dataCount

        val denominator = (dataCount - DataEntry.INTERNAL_THRESHOLD).coerceAtLeast(1)

        fun accuracy(correctCountBefore: Int, hit: Boolean): Double {
            return (correctCountBefore + if (hit) 1 else 0).toDouble() / denominator
        }

        val evaluatedEntries = allEntries.drop(DataEntry.INTERNAL_THRESHOLD)

        // Ensemble
        val ensemble1Hit = predictionResult.finalPrediction1 == actualValue
        val ensemble2Hit = predictionResult.finalPrediction2 == actualValue
        val ensembleTotalHit = ensemble1Hit || ensemble2Hit

        entry.ensemblePrediction1 = predictionResult.finalPrediction1
        entry.ensemblePrediction2 = predictionResult.finalPrediction2
        entry.ensembleIsDouble = predictionResult.showDouble
        entry.ensembleConfidence = predictionResult.confidence
        entry.ensemblePrimary1Correct = ensemble1Hit
        entry.ensemblePrimary2Correct = ensemble2Hit
        entry.ensembleTotalCorrect = ensembleTotalHit
        entry.ensemblePrimary1Accuracy = accuracy(evaluatedEntries.count { it.ensemblePrimary1Correct }, ensemble1Hit)
        entry.ensemblePrimary2Accuracy = accuracy(evaluatedEntries.count { it.ensemblePrimary2Correct }, ensemble2Hit)
        entry.ensembleTotalAccuracy = accuracy(evaluatedEntries.count { it.ensembleTotalCorrect }, ensembleTotalHit)

        // Combined
        val combined1Hit = predictionResult.combinedPrediction1 == actualValue
        val combined2Hit = predictionResult.combinedPrediction2 == actualValue
        val combinedTotalHit = combined1Hit || combined2Hit

        entry.combinedPrediction1 = predictionResult.combinedPrediction1
        entry.combinedPrediction2 = predictionResult.combinedPrediction2
        entry.combinedIsDouble = predictionResult.combinedShowDouble
        entry.combinedConfidence = predictionResult.combinedConfidence
        entry.combinedPrimary1Correct = combined1Hit
        entry.combinedPrimary2Correct = combined2Hit
        entry.combinedTotalCorrect = combinedTotalHit
        entry.combinedPrimary1Accuracy = accuracy(evaluatedEntries.count { it.combinedPrimary1Correct }, combined1Hit)
        entry.combinedPrimary2Accuracy = accuracy(evaluatedEntries.count { it.combinedPrimary2Correct }, combined2Hit)
        entry.combinedTotalAccuracy = accuracy(evaluatedEntries.count { it.combinedTotalCorrect }, combinedTotalHit)

        // Kalıp tek
        val kalip1Hit = predictionResult.kalipPrediction1 == actualValue
        val kalip2Hit = predictionResult.kalipPrediction2 == actualValue
        val kalipTotalHit = kalip1Hit || kalip2Hit

        entry.kalipPrediction1 = predictionResult.kalipPrediction1
        entry.kalipPrediction2 = predictionResult.kalipPrediction2
        entry.kalipIsDouble = predictionResult.kalipShowDouble
        entry.kalipConfidence = predictionResult.kalipConfidence
        entry.kalipPrimary1Correct = kalip1Hit
        entry.kalipPrimary2Correct = kalip2Hit
        entry.kalipTotalCorrect = kalipTotalHit
        entry.kalipPrimary1Accuracy = accuracy(evaluatedEntries.count { it.kalipPrimary1Correct }, kalip1Hit)
        entry.kalipPrimary2Accuracy = accuracy(evaluatedEntries.count { it.kalipPrimary2Correct }, kalip2Hit)
        entry.kalipTotalAccuracy = accuracy(evaluatedEntries.count { it.kalipTotalCorrect }, kalipTotalHit)

        // Side Standart
        val sideStandardHit = SidePrediction.checkSideCorrect(predictionResult.sideStandardFormatted, actualValue)
        val sideStandardDoubleHit = SidePrediction.checkSideDoubleCorrect(predictionResult.sideStandardFormatted, actualValue)

        entry.sideStandardPrediction = predictionResult.sideStandardFormatted
        entry.sideStandardCorrect = sideStandardHit
        entry.sideStandardDoubleCorrect = sideStandardDoubleHit
        entry.sideStandardAccuracy = accuracy(evaluatedEntries.count { it.sideStandardCorrect }, sideStandardHit)
        entry.sideStandardDoubleAccuracy = accuracy(evaluatedEntries.count { it.sideStandardDoubleCorrect }, sideStandardDoubleHit)

        // Side Rejim
        val sideRegimeHit = SidePrediction.checkSideCorrect(predictionResult.sideRegimeFormatted, actualValue)
        val sideRegimeDoubleHit = SidePrediction.checkSideDoubleCorrect(predictionResult.sideRegimeFormatted, actualValue)

        entry.sideRegimePrediction = predictionResult.sideRegimeFormatted
        entry.sideRegimeCorrect = sideRegimeHit
        entry.sideRegimeDoubleCorrect = sideRegimeDoubleHit
        entry.sideRegimeAccuracy = accuracy(evaluatedEntries.count { it.sideRegimeCorrect }, sideRegimeHit)
        entry.sideRegimeDoubleAccuracy = accuracy(evaluatedEntries.count { it.sideRegimeDoubleCorrect }, sideRegimeDoubleHit)

        // Side Final
        val sideFinalHit = sideStandardHit || sideRegimeHit
        val sideFinalDoubleHit = sideStandardDoubleHit || sideRegimeDoubleHit

        entry.sideDisplayPrediction = predictionResult.sideDisplay
        entry.sideFinalCorrect = sideFinalHit
        entry.sideFinalDoubleCorrect = sideFinalDoubleHit
        entry.sideFinalAccuracy = accuracy(evaluatedEntries.count { it.sideFinalCorrect }, sideFinalHit)
        entry.sideFinalDoubleAccuracy = accuracy(evaluatedEntries.count { it.sideFinalDoubleCorrect }, sideFinalDoubleHit)

        // Rejim / Kalıp / Kaos
        entry.currentRegime = predictionResult.currentRegime
        entry.previousRegime = predictionResult.previousRegime
        entry.regimeStableCount = predictionResult.regimeStableCount
        entry.matchedPatternLength = predictionResult.matchedPatternLength
        entry.matchedPatternCount = predictionResult.matchedPatternCount
        entry.matchedPatternRegime = predictionResult.matchedPatternRegime
        entry.regimeSimilarityScore = predictionResult.regimeSimilarityScore
        entry.chaosScore = predictionResult.chaosScore
        entry.patternBreakLength = predictionResult.patternBreakLength
        entry.anomalyFlags = predictionResult.anomalyInfo?.let { AnomalyDetector.formatAnomalyFlags(it) } ?: ""
        entry.confidenceAdjusted = (predictionResult.anomalyInfo?.confidenceAdjustment ?: 1.0) != 1.0
        entry.activeModelCount = predictionResult.councilDecision.activeModels.size

        // Meclis
        entry.mutedModels = predictionResult.councilDecision.mutedModels.joinToString(",")
        entry.rewardedModels = predictionResult.councilDecision.rewardedModels.joinToString(",")
        entry.returnedModels = predictionResult.councilDecision.returnedModels.joinToString(",")
        entry.fallbackModel = predictionResult.councilDecision.fallbackModels.joinToString(",")
        entry.decisionReason = predictionResult.councilDecision.reason

        // YENİ: Global Aynılaşma Metrikleri Hesaplama
        val activeVotes = predictionResult.methodVotes.filter { !it.isMuted && it.isActive }
        val dominantPredCount = activeVotes.groupBy { it.finalPrediction1 }.values.maxOfOrNull { it.size } ?: 0
        val dominantSourceCount = activeVotes.groupBy { it.decisionSource.name }.values.maxOfOrNull { it.size } ?: 0
        val consensusRatio = if (activeVotes.isNotEmpty()) dominantPredCount.toDouble() / activeVotes.size else 0.0

        entry.setTrace("model_konsensus_orani", String.format(Locale.US, "%%%d", (consensusRatio * 100).toInt()))
        entry.setTrace("ayni_final_tahmin_yapan_model_sayisi", dominantPredCount)
        entry.setTrace("ayni_kaynakla_karar_veren_model_sayisi", dominantSourceCount)

        // 13 Model
        for (methodIndex in 0 until DataEntry.METHOD_COUNT) {
            val vote = predictionResult.methodVotes.find { it.methodIndex == methodIndex }
            val outcome = outcomes[methodIndex]

            if (vote != null) {
                val methodHit = vote.finalPrediction1 == actualValue
                val methodAccuracy = accuracy(
                    evaluatedEntries.count { it.getMethodCorrect(methodIndex) },
                    methodHit
                )

                val councilState = MeritCouncil.getStateSnapshot(methodIndex)

                entry.setMethodCore(
                    index = methodIndex,
                    active = !councilState.muted,
                    muted = councilState.muted,
                    streakSuccess = councilState.streakSuccess,
                    streakFail = councilState.streakFail,
                    voteMultiplier = councilState.voteMultiplier,
                    finalPrediction1 = vote.finalPrediction1,
                    finalPrediction2 = vote.finalPrediction2,
                    finalConfidence = vote.finalConfidence,
                    correct = methodHit,
                    accuracy = methodAccuracy
                )

                val name = DataEntry.METHOD_NAMES[methodIndex]

                entry.setTrace("${name}_native_tahmin1", vote.nativePrediction1)
                entry.setTrace("${name}_native_tahmin2", vote.nativePrediction2)
                entry.setTrace("${name}_native_guven", String.format(Locale.US, "%.2f", vote.nativeConfidence))

                entry.setTrace("${name}_kalip_tahmin1", vote.patternPrediction1)
                entry.setTrace("${name}_kalip_tahmin2", vote.patternPrediction2)
                entry.setTrace("${name}_kalip_guven", String.format(Locale.US, "%.2f", vote.patternConfidence))
                entry.setTrace("${name}_kalip_ref_uzunluk", vote.patternRefLength)
                entry.setTrace("${name}_kalip_ref_rejim", vote.patternRefRegime)
                entry.setTrace("${name}_kalip_ref_eslesme", vote.patternRefCount)

                entry.setTrace("${name}_regime_tahmin1", vote.regimePrediction1)
                entry.setTrace("${name}_regime_tahmin2", vote.regimePrediction2)
                entry.setTrace("${name}_regime_guven", String.format(Locale.US, "%.2f", vote.regimeConfidence))

                entry.setTrace("${name}_meta_tahmin1", vote.metaPrediction1)
                entry.setTrace("${name}_meta_tahmin2", vote.metaPrediction2)
                entry.setTrace("${name}_meta_guven", String.format(Locale.US, "%.2f", vote.metaConfidence))

                entry.setTrace("${name}_blended_tahmin1", vote.blendedPrediction1)
                entry.setTrace("${name}_blended_tahmin2", vote.blendedPrediction2)
                entry.setTrace("${name}_blended_guven", String.format(Locale.US, "%.2f", vote.blendedConfidence))

                entry.setTrace("${name}_final_secim_kaynagi", vote.decisionSource.name)

                if (outcome != null) {
                    entry.setTrace("${name}_basari_kaynagi", outcome.basariKaynagi) // YENİ
                    entry.setTrace("${name}_native_dogru", boolText(outcome.nativeCorrect))
                    entry.setTrace("${name}_kalip_dogru", boolText(outcome.patternCorrect))
                    entry.setTrace("${name}_rejim_dogru", boolText(outcome.regimeCorrect))
                    entry.setTrace("${name}_meta_dogru", boolText(outcome.metaCorrect))
                    entry.setTrace("${name}_native_basari_seri", councilState.nativeSuccessStreak)
                    entry.setTrace("${name}_destek_basari_seri", councilState.supportSuccessStreak)
                    entry.setTrace("${name}_destek_paylasimli_basari", boolText(outcome.supportSharedSuccess))
                    entry.setTrace("${name}_odul_kademesi", councilState.rewardTier.name)
                    entry.setTrace("${name}_bias_kaydirildi", boolText(vote.biasShifted))
                } else {
                    entry.setTrace("${name}_basari_kaynagi", "NONE")
                    entry.setTrace("${name}_native_dogru", boolText(methodHit))
                    entry.setTrace("${name}_kalip_dogru", "HAYIR")
                    entry.setTrace("${name}_rejim_dogru", "HAYIR")
                    entry.setTrace("${name}_meta_dogru", "HAYIR")
                    entry.setTrace("${name}_native_basari_seri", 0)
                    entry.setTrace("${name}_destek_basari_seri", 0)
                    entry.setTrace("${name}_destek_paylasimli_basari", "HAYIR")
                    entry.setTrace("${name}_odul_kademesi", "NONE")
                    entry.setTrace("${name}_bias_kaydirildi", "HAYIR")
                }
            }
        }

        entry.setTrace("Standart_Yan_Tahmin_Teklik_Ciftlik_Guven", String.format(Locale.US, "%.2f", predictionResult.sideStandard.oddEvenConfidence))
        entry.setTrace("Standart_Yan_Tahmin_Kucukluk_Buyukluk_Guven", String.format(Locale.US, "%.2f", predictionResult.sideStandard.smallBigConfidence))
        entry.setTrace("Rejim_Yan_Tahmin_Teklik_Ciftlik_Guven", String.format(Locale.US, "%.2f", predictionResult.sideRegime.oddEvenConfidence))
        entry.setTrace("Rejim_Yan_Tahmin_Kucukluk_Buyukluk_Guven", String.format(Locale.US, "%.2f", predictionResult.sideRegime.smallBigConfidence))
        entry.setTrace("Yan_Tahmin_Final_Secim_Kaynagi", "STD+REG")
        entry.setTrace("Ensemble_Karar_Detayi", predictionResult.councilDecision.reason)
        entry.setTrace("Kaos_Skoru_Detayi", String.format(Locale.US, "%.2f", predictionResult.chaosScore)) // YENİ RAW FORMAT
        entry.setTrace("Kirilan_Kalip_Detayi", if (predictionResult.patternBreakLength > 0) "LEN=${predictionResult.patternBreakLength}" else "YOK")
        entry.setTrace("Eslesen_Kalip_Detayi", if (predictionResult.matchedPatternLength > 0) "LEN=${predictionResult.matchedPatternLength} CNT=${predictionResult.matchedPatternCount}" else "YOK")
        entry.setTrace("Rejim_Gecis_Tahmini", ContextualMemory.predictNextRegime(predictionResult.currentRegime))
        entry.setTrace("Rejim_Gecis_Deger_Tahmini", "")
        entry.setTrace("Meclis_Durum_Detayi", "Aktif=${predictionResult.councilDecision.activeModels.size} Muted=${predictionResult.councilDecision.mutedModels.size}")

        return entry
    }

    fun clearAll() {
        csvManager.clearAll()
        lastComputedResult = null
        MethodWeightTracker.reset()
        MeritCouncil.reset()
        ContextualMemory.clear()
        isMemoryInitialized = false
    }

    private fun parseTraceBool(value: String): Boolean? {
        val v = value.trim().uppercase()
        if (v.isBlank()) return null
        return when (v) {
            "EVET", "TRUE", "1" -> true
            "HAYIR", "FALSE", "0" -> false
            else -> null
        }
    }

    private fun boolText(value: Boolean): String = if (value) "EVET" else "HAYIR"

    data class EngineResult(
        val ensembleResult: Ensemble.EnsembleResult?,
        val isSilent: Boolean,
        val totalDataCount: Int,
        val recentValues: List<Int>
    )

    data class StatsResult(
        val totalCount: Int,
        val evaluatedCount: Int,
        val correctCount: Int,
        val totalCorrectCount: Int,
        val accuracy: Double,
        val methodStats: List<Triple<String, Int, Int>>
    )
}