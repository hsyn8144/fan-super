package com.fan.app.engine

object MethodWeightTracker {

    private val consecutiveWrongs = mutableMapOf<Int, Int>()
    private val lastPrediction = mutableMapOf<Int, Int>()
    private val multipliers = mutableMapOf<Int, Double>()

    fun getMultiplier(methodIndex: Int): Double = multipliers[methodIndex] ?: 1.0

    fun update(methodIndex: Int, prediction: Int, actualValue: Int) {
        if (prediction <= 0) return
        val isCorrect = prediction == actualValue
        val lastPred = lastPrediction[methodIndex]

        if (!isCorrect) {
            if (lastPred == prediction) {
                val wrongCount = (consecutiveWrongs[methodIndex] ?: 0) + 1
                consecutiveWrongs[methodIndex] = wrongCount
                if (wrongCount >= 2) {
                    val cur = multipliers[methodIndex] ?: 1.0
                    multipliers[methodIndex] = maxOf(cur * 0.4, 0.05)
                }
            } else {
                consecutiveWrongs[methodIndex] = 1
            }
        } else {
            consecutiveWrongs[methodIndex] = 0
            val cur = multipliers[methodIndex] ?: 1.0
            multipliers[methodIndex] = minOf(cur * 1.3, 1.0)
        }
        lastPrediction[methodIndex] = prediction
    }

    fun reset() {
        consecutiveWrongs.clear()
        lastPrediction.clear()
        multipliers.clear()
    }
}