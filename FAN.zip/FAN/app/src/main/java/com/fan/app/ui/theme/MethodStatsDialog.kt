package com.fan.app.ui

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.Window
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import com.fan.app.R

class MethodStatsDialog(
    context: Context,
    private val methodStats: List<Triple<String, Int, Int>>,
    private val activeStats: List<Triple<String, Int, Int>>? = null
) : Dialog(context) {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        buildUI()
    }

    private fun buildUI() {
        val scroll = ScrollView(context)
        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(Color.parseColor("#F5F5F5"))
        }

        val title = TextView(context).apply {
            text = "Yöntem İstatistikleri"
            textSize = 18f
            setTextColor(Color.parseColor("#212121"))
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 24)
        }
        container.addView(title)

        val subtitle = TextView(context).apply {
            text = "Yeşil: Aktif yöntemler  |  Gri: Pasif yöntemler"
            textSize = 12f
            setTextColor(Color.parseColor("#757575"))
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 16)
        }
        container.addView(subtitle)

        if (methodStats.isEmpty()) {
            val empty = TextView(context).apply {
                text = "Henüz yeterli veri yok.\n50 veri girilmesi gerekiyor."
                textSize = 14f
                setTextColor(Color.parseColor("#757575"))
                gravity = Gravity.CENTER
                setPadding(0, 32, 0, 32)
            }
            container.addView(empty)
        } else {
            methodStats.forEachIndexed { index, (name, correct, total) ->
                val isActive = activeStats?.find { it.first == name }?.third != 0
                container.addView(buildMethodRow(index + 1, name, correct, total, isActive))
            }
        }

        val closeBtn = android.widget.Button(context).apply {
            text = "Kapat"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#1565C0"))
            setPadding(0, 16, 0, 16)
            setOnClickListener { dismiss() }
        }
        val btnParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = 24 }
        container.addView(closeBtn, btnParams)

        scroll.addView(container)
        setContentView(scroll)

        window?.setLayout(
            (context.resources.displayMetrics.widthPixels * 0.9).toInt(),
            android.view.WindowManager.LayoutParams.WRAP_CONTENT
        )
    }

    private fun buildMethodRow(
        rank: Int,
        name: String,
        correct: Int,
        total: Int,
        isActive: Boolean
    ): LinearLayout {
        val row = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 12, 16, 12)
            setBackgroundColor(if (isActive) Color.WHITE else Color.parseColor("#E0E0E0"))
            alpha = if (isActive) 1.0f else 0.6f
        }

        val rowParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = 8 }

        val topRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
        }

        val rankColor = when (rank) {
            1 -> "#FFD600"
            2 -> "#B0BEC5"
            3 -> "#FF9800"
            else -> "#1565C0"
        }

        val rankBadge = TextView(context).apply {
            text = "#$rank"
            textSize = 13f
            setTextColor(Color.parseColor(rankColor))
            setPadding(0, 0, 12, 0)
            gravity = Gravity.CENTER_VERTICAL
        }
        topRow.addView(rankBadge)

        val nameText = TextView(context).apply {
            text = name
            textSize = 14f
            setTextColor(Color.parseColor(if (isActive) "#212121" else "#757575"))
            layoutParams = LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f
            )
        }
        topRow.addView(nameText)

        val statusText = TextView(context).apply {
            text = if (isActive) "●" else "○"
            textSize = 12f
            setTextColor(Color.parseColor(if (isActive) "#4CAF50" else "#9E9E9E"))
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 8, 0)
        }
        topRow.addView(statusText)

        val accuracy = if (total > 0) correct.toDouble() / total else 0.0
        val pct = (accuracy * 100).toInt()

        val accuracyText = TextView(context).apply {
            text = "%$pct"
            textSize = 15f
            setTextColor(
                when {
                    !isActive -> Color.parseColor("#9E9E9E")
                    pct >= 40 -> Color.parseColor("#4CAF50")
                    pct >= 30 -> Color.parseColor("#FF9800")
                    else -> Color.parseColor("#F44336")
                }
            )
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
        }
        topRow.addView(accuracyText)

        row.addView(topRow)

        val detailText = TextView(context).apply {
            text = "Doğru: $correct / $total ${if (!isActive) "(Pasif)" else ""}"
            textSize = 11f
            setTextColor(Color.parseColor("#757575"))
            setPadding(0, 4, 0, 6)
        }
        row.addView(detailText)

        val progress = ProgressBar(context, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = pct
            progressTintList = android.content.res.ColorStateList.valueOf(
                when {
                    !isActive -> Color.parseColor("#BDBDBD")
                    pct >= 40 -> Color.parseColor("#4CAF50")
                    pct >= 30 -> Color.parseColor("#FF9800")
                    else -> Color.parseColor("#F44336")
                }
            )
        }
        row.addView(progress, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 12
        ))

        row.layoutParams = rowParams
        return row
    }
}