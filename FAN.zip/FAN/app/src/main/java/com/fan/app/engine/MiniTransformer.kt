package com.fan.app.engine

class MiniTransformer {

    private val windowSize = 12
    private val dModel = 12
    private val numHeads = 3
    private val headDim = dModel / numHeads

    // Birikimli öğrenilen ağırlıklar — sıfırlanmaz
    private val outputWeights = Array(4) { DoubleArray(dModel + 1) { 0.0 } }
    private var trained = false
    private val lr = 0.004

    // Çeşitlilik takibi
    private val predHistory = ArrayDeque<Int>(20)

    /**
     * Eski compute — geriye uyumluluk için korundu.
     * Bağlamsal bilgi olmadan çalışır.
     */
    fun compute(data: List<Int>): Map<Int, Double> {
        return computeWithContext(data, "KAOS", 0, 0)
    }

    /**
     * Bağlamsal feature'larla zenginleştirilmiş compute.
     * Ensemble tarafından çağrılır.
     *
     * @param currentRegimeGroup Mevcut rejim grubu (TEKRAR, YON, SALINIMM, KAOS)
     * @param matchedPatternLength Eşleşen kalıp uzunluğu
     * @param chaosBucket Kaos seviye kovası (0-4)
     */
    fun computeWithContext(
        data: List<Int>,
        currentRegimeGroup: String,
        matchedPatternLength: Int,
        chaosBucket: Int
    ): Map<Int, Double> {
        if (data.size < 4) return equal()

        val trainFrom = maxOf(0, data.size - 100)
        for (i in trainFrom until data.size - 1) {
            val sub = data.subList(maxOf(0, i - windowSize + 1), i + 1)
            val pooled = forward(sub, currentRegimeGroup, matchedPatternLength, chaosBucket)
            learn(pooled, data[i + 1])
        }

        val sub = data.takeLast(windowSize)
        val pooled = forward(sub, currentRegimeGroup, matchedPatternLength, chaosBucket)
        return predictWithDiversity(pooled)
    }

    private fun forward(
        seq: List<Int>,
        regimeGroup: String,
        patternLength: Int,
        chaosBucket: Int
    ): DoubleArray {
        val emb = embed(seq, regimeGroup, patternLength, chaosBucket)
        val att = attention(emb)
        val last = att.last()
        val avg = DoubleArray(dModel) { j -> att.map { it[j] }.average() }
        return DoubleArray(dModel) { j -> last[j] * 0.6 + avg[j] * 0.4 }
    }

    private fun embed(
        seq: List<Int>,
        regimeGroup: String,
        patternLength: Int,
        chaosBucket: Int
    ): Array<DoubleArray> {
        // Bağlamsal scalar'lar
        val regimeScalar = when (regimeGroup) {
            "TEKRAR" -> 0.25
            "YON" -> 0.50
            "SALINIMM" -> 0.75
            else -> 1.0 // KAOS
        }
        val patternScalar = patternLength.coerceIn(0, 10).toDouble() / 10.0
        val chaosScalar = chaosBucket.coerceIn(0, 4).toDouble() / 4.0

        return Array(seq.size) { i ->
            val v = seq[i]
            val prev = if (i > 0) seq[i - 1] else v
            val freq = seq.count { it == v }.toDouble() / seq.size.coerceAtLeast(1)

            DoubleArray(dModel) { j ->
                when (j) {
                    0 -> (v - 2.5) / 1.5                    // değer normalize
                    1 -> kotlin.math.sin(i * 0.8)           // pozisyon sin
                    2 -> kotlin.math.cos(i * 0.8)           // pozisyon cos
                    3 -> (v - prev).toDouble() / 3.0        // delta
                    4 -> if (v == prev) 1.0 else 0.0        // tekrar flag
                    5 -> v.toDouble() / 4.0                 // ham değer ratio
                    6 -> kotlin.math.sin(v * 1.5)           // değer sin
                    7 -> kotlin.math.cos(v * 1.5)           // değer cos
                    8 -> regimeScalar                        // YENİ: rejim token
                    9 -> patternScalar                       // YENİ: kalıp uzunluğu token
                    10 -> chaosScalar                        // YENİ: kaos token
                    11 -> freq                               // YENİ: pencere içi frekans
                    else -> 0.0
                }
            }
        }
    }

    private fun attention(emb: Array<DoubleArray>): Array<DoubleArray> {
        val n = emb.size
        val out = Array(n) { DoubleArray(dModel) }
        for (h in 0 until numHeads) {
            val off = h * headDim
            for (i in 0 until n) {
                val scores = DoubleArray(n)
                for (j in 0 until n) {
                    var dot = 0.0
                    for (k in 0 until headDim) dot += emb[i][off + k] * emb[j][off + k]
                    scores[j] = dot / kotlin.math.sqrt(headDim.toDouble())
                }
                val mx = scores.max()
                val ex = DoubleArray(n) { kotlin.math.exp(scores[it] - mx) }
                val s = ex.sum().coerceAtLeast(1e-9)
                val w = DoubleArray(n) { ex[it] / s }
                for (k in 0 until headDim) {
                    var weighted = 0.0
                    for (j in 0 until n) weighted += w[j] * emb[j][off + k]
                    out[i][off + k] += weighted
                }
            }
        }
        return out
    }

    private fun rawScores(vec: DoubleArray): DoubleArray =
        DoubleArray(4) { cls ->
            outputWeights[cls][0] + vec.indices.sumOf { j -> outputWeights[cls][j + 1] * vec[j] }
        }

    private fun learn(vec: DoubleArray, target: Int) {
        val scores = rawScores(vec)
        val mx = scores.max()
        val ex = DoubleArray(4) { kotlin.math.exp(scores[it] - mx) }
        val s = ex.sum().coerceAtLeast(1e-9)
        val probs = DoubleArray(4) { ex[it] / s }
        for (cls in 0..3) {
            val t = if (cls == target - 1) 1.0 else 0.0
            val err = t - probs[cls]
            outputWeights[cls][0] += lr * err
            for (j in vec.indices) outputWeights[cls][j + 1] += lr * err * vec[j]
        }
        trained = true
    }

    private fun predictWithDiversity(vec: DoubleArray): Map<Int, Double> {
        if (!trained) return equal()
        val scores = rawScores(vec)
        val mx = scores.max()
        val ex = DoubleArray(4) { kotlin.math.exp(scores[it] - mx) }
        val s = ex.sum().coerceAtLeast(1e-9)
        val probs = DoubleArray(4) { ex[it] / s }

        // Çeşitlilik düzeltmesi
        val adjusted = diversityAdjust(probs)
        val top = adjusted.indices.maxByOrNull { adjusted[it] }!! + 1
        if (predHistory.size >= 20) predHistory.removeFirst()
        predHistory.addLast(top)

        val total = adjusted.sum().coerceAtLeast(1e-9)
        return mapOf(
            1 to adjusted[0] / total,
            2 to adjusted[1] / total,
            3 to adjusted[2] / total,
            4 to adjusted[3] / total
        )
    }

    private fun diversityAdjust(probs: DoubleArray): DoubleArray {
        if (predHistory.size < 8) return probs
        val recent = predHistory.toList().takeLast(8)
        val freq = DoubleArray(4) { k -> recent.count { it == k + 1 }.toDouble() / recent.size }
        val result = DoubleArray(4)
        for (k in 0..3) {
            val penalty = when {
                freq[k] > 0.6 -> 0.4   // çok sık tahmin ediliyor, bastır
                freq[k] > 0.4 -> 0.7
                else -> 1.0
            }
            result[k] = probs[k] * penalty
        }
        return result
    }

    private fun equal() = mapOf(1 to 0.25, 2 to 0.25, 3 to 0.25, 4 to 0.25)
}