package com.fan.app.engine

import com.fan.app.data.DataEntry

object MeritCouncil {

    data class CouncilState(
        val methodIndex: Int,

        var active: Boolean = true,
        var muted: Boolean = false,

        var finalStreakSuccess: Int = 0,
        var finalStreakFail: Int = 0,

        var silentStreakSuccess: Int = 0,
        var returningNextTurn: Boolean = false,

        var nativeSuccessStreak: Int = 0,
        var supportSuccessStreak: Int = 0,
        var supportSharedSuccess: Boolean = false,

        var rewardTier: RewardTier = RewardTier.NONE,
        var voteMultiplier: Double = 1.0
    )

    data class CouncilDecision(
        val activeModels: List<Int>,
        val mutedModels: List<Int>,
        val rewardedModels: List<Int>,
        val returnedModels: List<Int>,
        val fallbackModels: List<Int>,
        val multipliers: Map<Int, Double>,
        val reason: String
    )

    data class StateSnapshot(
        val active: Boolean,
        val muted: Boolean,
        val streakSuccess: Int,
        val streakFail: Int,
        val voteMultiplier: Double,

        val nativeSuccessStreak: Int,
        val supportSuccessStreak: Int,
        val supportSharedSuccess: Boolean,
        val rewardTier: RewardTier
    )

    private val states = mutableMapOf<Int, CouncilState>()

    private fun getState(index: Int): CouncilState {
        return states.getOrPut(index) { CouncilState(methodIndex = index) }
    }

    fun reset() {
        states.clear()
    }

    fun getStateSnapshot(index: Int): StateSnapshot {
        val st = getState(index)
        return StateSnapshot(
            active = !st.muted,
            muted = st.muted,
            streakSuccess = st.finalStreakSuccess,
            streakFail = st.finalStreakFail,
            voteMultiplier = st.voteMultiplier,
            nativeSuccessStreak = st.nativeSuccessStreak,
            supportSuccessStreak = st.supportSuccessStreak,
            supportSharedSuccess = st.supportSharedSuccess,
            rewardTier = st.rewardTier
        )
    }

    fun getAllStates(): Map<Int, CouncilState> = states.mapValues { it.value.copy() }

    // Geriye uyumluluk için
    fun updateAfterResult(
        methodIndex: Int,
        predicted: Int,
        actual: Int,
        isEnsembleContext: Boolean = true
    ) {
        if (!isEnsembleContext && methodIndex == 0) return
        val finalCorrect = predicted == actual
        updateAfterResult(methodIndex, finalCorrect, finalCorrect, false, false, 0.0)
    }

    /**
     * YENİ: chaosScore parametresi eklendi. Mute eşiği buna göre belirlenir.
     */
    fun updateAfterResult(
        methodIndex: Int,
        finalCorrect: Boolean,
        nativeCorrect: Boolean,
        supportCorrect: Boolean,
        supportSharedSuccess: Boolean,
        chaosScore: Double
    ) {
        val state = getState(methodIndex)

        if (state.muted) {
            if (finalCorrect) {
                state.silentStreakSuccess++
                if (state.silentStreakSuccess >= 2) {
                    state.returningNextTurn = true
                }
            } else {
                state.silentStreakSuccess = 0
                state.returningNextTurn = false
            }
            return
        }

        if (finalCorrect) {
            state.finalStreakSuccess++
            state.finalStreakFail = 0
        } else {
            state.finalStreakFail++
            state.finalStreakSuccess = 0
        }

        if (nativeCorrect) {
            state.nativeSuccessStreak++
        } else {
            state.nativeSuccessStreak = 0
        }

        if (supportCorrect) {
            state.supportSuccessStreak++
        } else {
            state.supportSuccessStreak = 0
        }

        state.supportSharedSuccess = supportSharedSuccess

        // DİNAMİK MUTE EŞİĞİ
        val muteThreshold = when {
            chaosScore <= 5.0 -> 3
            chaosScore <= 15.0 -> 4
            else -> 5
        }

        if (state.finalStreakFail >= muteThreshold) {
            state.muted = true
            state.active = false
            state.returningNextTurn = false
            state.silentStreakSuccess = 0
            state.rewardTier = RewardTier.NONE
            state.voteMultiplier = 1.0
            return
        }

        val rewardTier = when {
            supportSharedSuccess && state.supportSuccessStreak >= 2 -> RewardTier.SUPPORT_CAPPED
            state.nativeSuccessStreak >= 5 -> RewardTier.NATIVE_STREAK_5_PLUS
            state.nativeSuccessStreak == 4 -> RewardTier.NATIVE_STREAK_4
            state.nativeSuccessStreak == 3 -> RewardTier.NATIVE_STREAK_3
            state.nativeSuccessStreak == 2 -> RewardTier.NATIVE_STREAK_2
            else -> RewardTier.NONE
        }

        state.rewardTier = rewardTier
        state.voteMultiplier = rewardTier.multiplier
        state.active = !state.muted
    }

    fun makeDecision(
        pastEntries: List<DataEntry>
    ): CouncilDecision {
        val activeModels = mutableListOf<Int>()
        val mutedModels = mutableListOf<Int>()
        val rewardedModels = mutableListOf<Int>()
        val returnedModels = mutableListOf<Int>()
        val fallbackModels = mutableListOf<Int>()
        val multipliers = mutableMapOf<Int, Double>()
        val reasons = mutableListOf<String>()

        for (i in 0 until DataEntry.METHOD_COUNT) {
            val st = getState(i)
            if (st.returningNextTurn) {
                st.returningNextTurn = false
                st.muted = false
                st.active = true
                st.finalStreakFail = 0
                st.silentStreakSuccess = 0
                st.voteMultiplier = 1.0
                st.rewardTier = RewardTier.NONE

                returnedModels.add(i)
                reasons.add("M${i}:GeriDondu")
            }
        }

        for (i in 0 until DataEntry.METHOD_COUNT) {
            val st = getState(i)
            if (st.muted) {
                mutedModels.add(i)
            } else {
                activeModels.add(i)
                multipliers[i] = st.voteMultiplier
                if (st.voteMultiplier > 1.0) {
                    rewardedModels.add(i)
                }
            }
        }

        if (activeModels.size < DataEntry.MIN_ACTIVE_MODELS) {
            val need = DataEntry.MIN_ACTIVE_MODELS - activeModels.size
            val candidates = findFallbackCandidates(mutedModels, pastEntries)

            var added = 0
            for (idx in candidates) {
                if (added >= need) break
                if (idx in activeModels) continue

                val st = getState(idx)
                st.muted = false
                st.active = true
                st.finalStreakFail = 0
                st.returningNextTurn = false
                st.silentStreakSuccess = 0
                st.voteMultiplier = 1.0
                st.rewardTier = RewardTier.NONE

                activeModels.add(idx)
                mutedModels.remove(idx)
                fallbackModels.add(idx)
                multipliers[idx] = 1.0
                reasons.add("M${idx}:YedekEklendi")
                added++
            }

            if (activeModels.size < DataEntry.MIN_ACTIVE_MODELS) {
                for (idx in mutedModels.toList()) {
                    if (activeModels.size >= DataEntry.MIN_ACTIVE_MODELS) break

                    val st = getState(idx)
                    st.muted = false
                    st.active = true
                    st.finalStreakFail = 0
                    st.returningNextTurn = false
                    st.silentStreakSuccess = 0
                    st.voteMultiplier = 1.0
                    st.rewardTier = RewardTier.NONE

                    activeModels.add(idx)
                    mutedModels.remove(idx)
                    fallbackModels.add(idx)
                    multipliers[idx] = 1.0
                    reasons.add("M${idx}:ZorunluGeriAl")
                }
            }
        }

        val reason = if (reasons.isEmpty()) "Normal" else reasons.joinToString(";")

        return CouncilDecision(
            activeModels = activeModels.sorted(),
            mutedModels = mutedModels.sorted(),
            rewardedModels = rewardedModels.sorted(),
            returnedModels = returnedModels.sorted(),
            fallbackModels = fallbackModels.sorted(),
            multipliers = multipliers.toMap(),
            reason = reason
        )
    }

    private fun findFallbackCandidates(
        mutedModels: List<Int>,
        pastEntries: List<DataEntry>
    ): List<Int> {
        val result = mutableListOf<Int>()
        val mutedSet = mutedModels.toSet()

        if (pastEntries.isEmpty()) return result

        val last = pastEntries.lastOrNull()
        if (last != null) {
            for (i in 0 until DataEntry.METHOD_COUNT) {
                if (i in mutedSet && last.getMethodCorrect(i)) {
                    result.add(i)
                }
            }
        }

        val prev = pastEntries.dropLast(1).lastOrNull()
        if (prev != null) {
            for (i in 0 until DataEntry.METHOD_COUNT) {
                if (i in mutedSet && i !in result && prev.getMethodCorrect(i)) {
                    result.add(i)
                }
            }
        }

        val recent = pastEntries.takeLast(5).reversed()
        for (entry in recent) {
            for (i in 0 until DataEntry.METHOD_COUNT) {
                if (i in mutedSet && i !in result && entry.getMethodCorrect(i)) {
                    result.add(i)
                }
            }
        }

        return result
    }
}