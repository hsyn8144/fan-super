package com.fan.app.engine

class EchoStateNetwork {

    private val reservoirSize = 30
    private val spectralRadius = 0.85
    private val inputScaling = 0.4
    private val leakRate = 0.3

    private val reservoir = Array(reservoirSize) { DoubleArray(reservoirSize) }
    private val inputWeights = Array(4) { DoubleArray(reservoirSize) }

    // Birikimli öğrenilen çıktı ağırlıkları — sıfırlanmaz
    private val outputWeights = Array(4) { DoubleArray(reservoirSize + 1) { 0.0 } }
    private var state = DoubleArray(reservoirSize)
    private var trained = false
    private val lr = 0.003

    // Çeşitlilik takibi
    private val predHistory = ArrayDeque<Int>(20)

    init { initReservoir() }

    private fun initReservoir() {
        val rng = java.util.Random(77)
        for (i in 0 until reservoirSize)
            for (j in 0 until reservoirSize)
                reservoir[i][j] = if (rng.nextDouble() < 0.15)
                    (rng.nextDouble() * 2 - 1) * spectralRadius else 0.0
        for (i in 0..3)
            for (j in 0 until reservoirSize)
                inputWeights[i][j] = (rng.nextDouble() * 2 - 1) * inputScaling
    }

    fun compute(data: List<Int>): Map<Int, Double> {
        if (data.size < 5) return equal()

        // State ısıtma (son 80 veri üzerinde)
        val trainFrom = maxOf(0, data.size - 80)
        state = DoubleArray(reservoirSize)
        for (i in trainFrom until maxOf(trainFrom, data.size - 15)) {
            updateState(data[i] - 1)
        }

        // Öğrenme (son 15 veri)
        for (i in maxOf(trainFrom, data.size - 15) until data.size - 1) {
            updateState(data[i] - 1)
            learn(state.copyOf(), data[i + 1])
        }

        updateState(data.last() - 1)
        return predictWithDiversity(state)
    }

    private fun updateState(input: Int) {
        val inp = input.coerceIn(0, 3)
        val newState = DoubleArray(reservoirSize)
        for (j in 0 until reservoirSize) {
            var sum = inputWeights[inp][j]
            for (k in 0 until reservoirSize) sum += reservoir[k][j] * state[k]
            newState[j] = (1 - leakRate) * state[j] + leakRate * kotlin.math.tanh(sum)
        }
        state = newState
    }

    private fun learn(s: DoubleArray, target: Int) {
        val scores = rawScores(s)
        val maxS = scores.max()
        val exps = DoubleArray(4) { kotlin.math.exp(scores[it] - maxS) }
        val sumExp = exps.sum().coerceAtLeast(1e-9)
        val probs = DoubleArray(4) { exps[it] / sumExp }
        for (cls in 0..3) {
            val t = if (cls == target - 1) 1.0 else 0.0
            val err = t - probs[cls]
            outputWeights[cls][0] += lr * err
            for (j in s.indices) outputWeights[cls][j + 1] += lr * err * s[j]
        }
        trained = true
    }

    private fun rawScores(s: DoubleArray): DoubleArray =
        DoubleArray(4) { cls ->
            outputWeights[cls][0] + s.indices.sumOf { j -> outputWeights[cls][j + 1] * s[j] }
        }

    private fun predictWithDiversity(s: DoubleArray): Map<Int, Double> {
        if (!trained) return equal()
        val scores = rawScores(s)
        val maxS = scores.max()
        val exps = DoubleArray(4) { kotlin.math.exp(scores[it] - maxS) }
        val sumExp = exps.sum().coerceAtLeast(1e-9)
        val probs = DoubleArray(4) { exps[it] / sumExp }

        // Çeşitlilik düzeltmesi
        val adjusted = diversityAdjust(probs)
        val top = adjusted.indices.maxByOrNull { adjusted[it] }!! + 1
        if (predHistory.size >= 20) predHistory.removeFirst()
        predHistory.addLast(top)

        val total = adjusted.sum().coerceAtLeast(1e-9)
        return mapOf(1 to adjusted[0]/total, 2 to adjusted[1]/total, 3 to adjusted[2]/total, 4 to adjusted[3]/total)
    }

    private fun diversityAdjust(probs: DoubleArray): DoubleArray {
        if (predHistory.size < 8) return probs
        val recent = predHistory.toList().takeLast(8)
        val freq = DoubleArray(4) { k -> recent.count { it == k + 1 }.toDouble() / recent.size }
        val result = DoubleArray(4)
        for (k in 0..3) {
            val penalty = when {
                freq[k] > 0.6 -> 0.4   // çok sık tahmin ediliyor, bastır
                freq[k] > 0.4 -> 0.7
                else -> 1.0
            }
            result[k] = probs[k] * penalty
        }
        return result
    }

    private fun equal() = mapOf(1 to 0.25, 2 to 0.25, 3 to 0.25, 4 to 0.25)
}