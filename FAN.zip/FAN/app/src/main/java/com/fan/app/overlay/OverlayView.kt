package com.fan.app.overlay

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.cardview.widget.CardView
import com.fan.app.engine.Ensemble
import com.fan.app.engine.PredictionEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs

class OverlayView(context: Context) : LinearLayout(context) {

    var onValueEntered: ((Int) -> Unit)? = null
    var onDeletePressed: (() -> Unit)? = null

    private val windowManager =
        context.getSystemService(Context.WINDOW_SERVICE) as WindowManager

    private val uiScope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private lateinit var params: WindowManager.LayoutParams
    private var isAddedToWindow = false
    private var isHorizontal = false

    private var buttonSizePct = 100
    private var opacityPct = 30
    private var fadeDelayMs = 4000L
    private var vibrationEnabled = false

    private var fadeJob: Job? = null
    private var isFaded = false

    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f
    private var wasDragging = false

    private var lastResult: PredictionEngine.EngineResult? = null

    // Tüm UI elemanları nullable — rebuild sırasında güvenli erişim
    private var tvMainPrediction: TextView? = null
    private var tvMainConfidence: TextView? = null
    private var tvCombinedPrediction: TextView? = null
    private var tvCombinedConfidence: TextView? = null
    private var tvKalipPrediction: TextView? = null
    private var tvKalipConfidence: TextView? = null
    private var tvSidePrediction: TextView? = null
    private var tvSideConfidence: TextView? = null
    private var tvRecentValues: TextView? = null
    private var btnDel: Button? = null
    private var btn1: Button? = null
    private var btn2: Button? = null
    private var btn3: Button? = null
    private var btn4: Button? = null

    init {
        orientation = VERTICAL
        buildVerticalLayout()
    }

    // ======================== SHOW / HIDE ========================

    fun show() {
        if (isAddedToWindow) return

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = dp(120)
        }

        try {
            windowManager.addView(this, params)
            isAddedToWindow = true
            alpha = 1f
            scheduleFade()
        } catch (_: Exception) {
        }
    }

    fun hide() {
        fadeJob?.cancel()
        if (!isAddedToWindow) return
        try {
            windowManager.removeView(this)
        } catch (_: Exception) {
        }
        isAddedToWindow = false
    }

    // ======================== LAYOUT REBUILD (GÜVENLI) ========================

    private fun safeRebuildLayout(horizontal: Boolean) {
        val savedX = if (::params.isInitialized) params.x else 0
        val savedY = if (::params.isInitialized) params.y else dp(120)
        val wasAdded = isAddedToWindow

        if (wasAdded) {
            try {
                windowManager.removeView(this)
            } catch (_: Exception) {
            }
            isAddedToWindow = false
        }

        isHorizontal = horizontal
        if (horizontal) {
            buildHorizontalLayoutInternal()
        } else {
            buildVerticalLayoutInternal()
        }

        if (wasAdded && ::params.isInitialized) {
            params.x = savedX
            params.y = savedY
            try {
                windowManager.addView(this, params)
                isAddedToWindow = true
            } catch (_: Exception) {
            }
        }
    }

    // ======================== VERTICAL LAYOUT ========================

    private fun buildVerticalLayout() {
        buildVerticalLayoutInternal()
    }

    private fun buildVerticalLayoutInternal() {
        removeAllViews()
        orientation = VERTICAL
        setPadding(dp(8), dp(8), dp(8), dp(8))

        val card = CardView(context).apply {
            radius = dp(16).toFloat()
            setCardBackgroundColor(Color.parseColor("#CC1565C0"))
            cardElevation = dp(8).toFloat()
        }

        val inner = LinearLayout(context).apply {
            orientation = VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }

        // --- Tahmin paneli ---
        val predictionPanel = LinearLayout(context).apply {
            orientation = VERTICAL
            setPadding(0, 0, 0, dp(6))
        }

        // Ana tahmin (büyük)
        run {
            val row = createPredictionRow(
                26f, 14f, Color.WHITE, Color.parseColor("#FFD600")
            )
            tvMainPrediction = row.prediction
            tvMainConfidence = row.confidence
            predictionPanel.addView(row.container)
        }

        // Combined tahmin
        run {
            val row = createPredictionRow(
                18f, 12f, Color.parseColor("#C8E6C9"), Color.parseColor("#81C784")
            )
            tvCombinedPrediction = row.prediction
            tvCombinedConfidence = row.confidence
            predictionPanel.addView(row.container)
        }

        // Kalıp tahmin
        run {
            val row = createPredictionRow(
                18f, 12f, Color.parseColor("#FFE0B2"), Color.parseColor("#FFB74D")
            )
            tvKalipPrediction = row.prediction
            tvKalipConfidence = row.confidence
            predictionPanel.addView(row.container)
        }

        // Yan tahmin
        run {
            val row = createPredictionRow(
                18f, 12f, Color.parseColor("#E1BEE7"), Color.parseColor("#CE93D8")
            )
            tvSidePrediction = row.prediction
            tvSideConfidence = row.confidence
            predictionPanel.addView(row.container)
        }

        // Son veriler
        tvRecentValues = TextView(context).apply {
            textSize = 10f
            setTextColor(Color.parseColor("#BBDEFB"))
            gravity = Gravity.CENTER
            typeface = Typeface.MONOSPACE
            text = "- - - - - -"
            setPadding(0, dp(6), 0, dp(2))
        }
        predictionPanel.addView(
            tvRecentValues,
            LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT)
        )

        inner.addView(
            predictionPanel,
            LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT)
        )

        // --- Butonlar ---
        btnDel = createButton("DEL", Color.parseColor("#78909C"))
        btn4 = createButton("4", Color.parseColor("#F44336"))
        btn3 = createButton("3", Color.parseColor("#FF9800"))
        btn2 = createButton("2", Color.parseColor("#2196F3"))
        btn1 = createButton("1", Color.parseColor("#4CAF50"))

        inner.addView(btnDel, buttonParams())
        inner.addView(btn4, buttonParams())
        inner.addView(btn3, buttonParams())
        inner.addView(btn2, buttonParams())
        inner.addView(btn1, buttonParams())

        card.addView(inner)
        addView(card)

        setupButtonListeners()
        attachDragListener(predictionPanel)
        restoreLastDisplay()
    }

    // ======================== HORIZONTAL LAYOUT ========================

    private fun buildHorizontalLayoutInternal() {
        removeAllViews()
        orientation = HORIZONTAL
        setPadding(dp(8), dp(8), dp(8), dp(8))

        val card = CardView(context).apply {
            radius = dp(16).toFloat()
            setCardBackgroundColor(Color.parseColor("#CC1565C0"))
            cardElevation = dp(8).toFloat()
        }

        val inner = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }

        // Tahmin paneli (sol)
        val predictionPanel = LinearLayout(context).apply {
            orientation = VERTICAL
            setPadding(dp(6), 0, dp(8), 0)
        }

        run {
            val row = createPredictionRow(
                18f, 11f, Color.WHITE, Color.parseColor("#FFD600")
            )
            tvMainPrediction = row.prediction
            tvMainConfidence = row.confidence
            predictionPanel.addView(row.container)
        }

        run {
            val row = createPredictionRow(
                13f, 10f, Color.parseColor("#C8E6C9"), Color.parseColor("#81C784")
            )
            tvCombinedPrediction = row.prediction
            tvCombinedConfidence = row.confidence
            predictionPanel.addView(row.container)
        }

        run {
            val row = createPredictionRow(
                13f, 10f, Color.parseColor("#FFE0B2"), Color.parseColor("#FFB74D")
            )
            tvKalipPrediction = row.prediction
            tvKalipConfidence = row.confidence
            predictionPanel.addView(row.container)
        }

        run {
            val row = createPredictionRow(
                13f, 10f, Color.parseColor("#E1BEE7"), Color.parseColor("#CE93D8")
            )
            tvSidePrediction = row.prediction
            tvSideConfidence = row.confidence
            predictionPanel.addView(row.container)
        }

        tvRecentValues = TextView(context).apply {
            textSize = 9f
            setTextColor(Color.parseColor("#BBDEFB"))
            gravity = Gravity.CENTER
            typeface = Typeface.MONOSPACE
            text = "- - - - - -"
            setPadding(0, dp(4), 0, 0)
        }
        predictionPanel.addView(
            tvRecentValues,
            LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT)
        )

        inner.addView(
            predictionPanel,
            LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f)
        )

        // Butonlar (sağ)
        val buttonGroup = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        btnDel = createButton("DEL", Color.parseColor("#78909C"))
        btn4 = createButton("4", Color.parseColor("#F44336"))
        btn3 = createButton("3", Color.parseColor("#FF9800"))
        btn2 = createButton("2", Color.parseColor("#2196F3"))
        btn1 = createButton("1", Color.parseColor("#4CAF50"))

        buttonGroup.addView(btnDel, buttonParamsH())
        buttonGroup.addView(btn4, buttonParamsH())
        buttonGroup.addView(btn3, buttonParamsH())
        buttonGroup.addView(btn2, buttonParamsH())
        buttonGroup.addView(btn1, buttonParamsH())

        inner.addView(buttonGroup)

        card.addView(inner)
        addView(card)

        setupButtonListeners()
        attachDragListener(predictionPanel)
        restoreLastDisplay()
    }

    // ======================== YARDIMCI WIDGET'LAR ========================

    private data class PredictionRowViews(
        val container: LinearLayout,
        val prediction: TextView,
        val confidence: TextView
    )

    private fun createPredictionRow(
        predTextSize: Float,
        confTextSize: Float,
        predColor: Int,
        confColor: Int
    ): PredictionRowViews {
        val row = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(2), 0, dp(2))
        }

        val tvPred = TextView(context).apply {
            text = "--"
            textSize = predTextSize
            setTextColor(predColor)
            typeface = Typeface.MONOSPACE
            gravity = Gravity.START or Gravity.CENTER_VERTICAL
        }

        val tvConf = TextView(context).apply {
            text = "%--"
            textSize = confTextSize
            setTextColor(confColor)
            typeface = Typeface.MONOSPACE
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
        }

        row.addView(tvPred, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
        row.addView(tvConf, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT))

        return PredictionRowViews(row, tvPred, tvConf)
    }

    private fun createButton(label: String, color: Int): Button {
        return Button(context).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = 14f
            setBackgroundColor(color)
            stateListAnimator = null
            isAllCaps = false
            minHeight = 0
            minimumHeight = 0
        }
    }

    private fun buttonParams(): LayoutParams {
        val size = ((48 * buttonSizePct) / 100f).toInt().dpToPx()
        return LayoutParams(LayoutParams.MATCH_PARENT, size).apply {
            setMargins(0, dp(4), 0, dp(4))
        }
    }

    private fun buttonParamsH(): LayoutParams {
        val size = ((44 * buttonSizePct) / 100f).toInt().dpToPx()
        return LayoutParams(size, size).apply {
            setMargins(dp(4), 0, dp(4), 0)
        }
    }

    // ======================== BUTON LISTENER'LAR ========================

    private fun setupButtonListeners() {
        btn1?.setOnClickListener {
            vibrate(); resetFade(); onValueEntered?.invoke(1)
        }
        btn2?.setOnClickListener {
            vibrate(); resetFade(); onValueEntered?.invoke(2)
        }
        btn3?.setOnClickListener {
            vibrate(); resetFade(); onValueEntered?.invoke(3)
        }
        btn4?.setOnClickListener {
            vibrate(); resetFade(); onValueEntered?.invoke(4)
        }
        btnDel?.setOnClickListener {
            vibrate(); resetFade(); onDeletePressed?.invoke()
        }
    }

    // ======================== DISPLAY GÜNCELLE ========================

    fun updateDisplay(result: PredictionEngine.EngineResult) {
        lastResult = result
        val ens = result.ensembleResult

        if (result.isSilent || ens == null) {
            tvMainPrediction?.text = "--"
            tvMainConfidence?.text = "%--"
            tvCombinedPrediction?.text = "--"
            tvCombinedConfidence?.text = "%--"
            tvKalipPrediction?.text = "--"
            tvKalipConfidence?.text = "%--"
            tvSidePrediction?.text = "--"
            tvSideConfidence?.text = "%--"
        } else {
            // Ana tahmin
            tvMainPrediction?.text = formatPrediction(
                ens.finalPrediction1, ens.finalPrediction2, ens.showDouble
            )
            tvMainConfidence?.text = formatPercent(ens.confidence)

            // Combined
            tvCombinedPrediction?.text = formatPrediction(
                ens.combinedPrediction1, ens.combinedPrediction2, ens.combinedShowDouble
            )
            tvCombinedConfidence?.text = formatPercent(ens.combinedConfidence)

            // Kalıp
            tvKalipPrediction?.text = formatPrediction(
                ens.kalipPrediction1, ens.kalipPrediction2, ens.kalipShowDouble
            )
            tvKalipConfidence?.text = formatPercent(ens.kalipConfidence)

            // Yan tahmin (standart/rejim birleşik gösterim)
            tvSidePrediction?.text = ens.sideDisplay.ifBlank { "--" }
            tvSideConfidence?.text = formatPercent(computeSideConfidence(ens))
        }

        tvRecentValues?.text =
            if (result.recentValues.isEmpty()) "- - - - - -"
            else result.recentValues.joinToString(" ")
    }

    private fun restoreLastDisplay() {
        lastResult?.let { updateDisplay(it) }
    }

    private fun formatPrediction(primary: Int, secondary: Int, showDouble: Boolean): String {
        return when {
            primary <= 0 -> "--"
            showDouble && secondary > 0 && secondary != primary -> "$primary/$secondary"
            primary > 0 -> "$primary"
            else -> "--"
        }
    }

    private fun formatPercent(value: Double): String {
        return "%${(value * 100).toInt().coerceIn(0, 100)}"
    }

    private fun computeSideConfidence(result: Ensemble.EnsembleResult): Double {
        return maxOf(
            result.sideStandard.smallBigConfidence,
            result.sideStandard.oddEvenConfidence,
            result.sideRegime.smallBigConfidence,
            result.sideRegime.oddEvenConfidence
        )
    }

    // ======================== SÜRÜKLEME / SNAP ========================

    private fun attachDragListener(target: View) {
        target.setOnTouchListener { v, event ->
            if (!::params.isInitialized || !isAddedToWindow) return@setOnTouchListener false

            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    wasDragging = false
                    resetFade()
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()

                    if (abs(dx) > dp(4) || abs(dy) > dp(4)) {
                        wasDragging = true
                    }

                    if (wasDragging) {
                        params.x = (initialX + dx).coerceAtLeast(0)
                        params.y = (initialY + dy).coerceAtLeast(0)
                        updateWindowLayoutSafely()
                    }
                    true
                }

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (wasDragging) {
                        val deltaY = event.rawY - initialTouchY
                        handleRelease(deltaY)
                    } else {
                        v.performClick()
                    }
                    scheduleFade()
                    true
                }

                else -> false
            }
        }
    }

    private fun handleRelease(deltaY: Float) {
        if (deltaY < -dp(48)) {
            if (!isHorizontal) {
                safeRebuildLayout(horizontal = true)
            }
            post { snapToTop() }
            return
        }

        if (isHorizontal) {
            safeRebuildLayout(horizontal = false)
        }
        post { snapLeftOrRight() }
    }

    private fun snapToTop() {
        if (!isAddedToWindow || !::params.isInitialized) return
        params.x = 0
        params.y = 0
        updateWindowLayoutSafely()
    }

    private fun snapLeftOrRight() {
        if (!isAddedToWindow || !::params.isInitialized) return

        val screenWidth = resources.displayMetrics.widthPixels
        val viewWidth = (width.takeIf { it > 0 } ?: measuredWidth).coerceAtLeast(1)

        params.x = if (params.x + viewWidth / 2 < screenWidth / 2) {
            0
        } else {
            (screenWidth - viewWidth).coerceAtLeast(0)
        }

        updateWindowLayoutSafely()
    }

    private fun updateWindowLayoutSafely() {
        if (!isAddedToWindow || !::params.isInitialized) return
        try {
            windowManager.updateViewLayout(this, params)
        } catch (_: Exception) {
        }
    }

    // ======================== FADE ========================

    private fun scheduleFade() {
        fadeJob?.cancel()
        if (!isAddedToWindow || fadeDelayMs <= 0L) return

        fadeJob = uiScope.launch {
            delay(fadeDelayMs)
            if (!isAddedToWindow) return@launch
            animate().alpha(opacityPct / 100f).setDuration(500).start()
            isFaded = true
        }
    }

    private fun resetFade() {
        fadeJob?.cancel()
        if (!isAddedToWindow) return
        animate().alpha(1f).setDuration(200).start()
        isFaded = false
        scheduleFade()
    }

    // ======================== AYARLAR ========================

    fun setButtonSize(pct: Int) {
        buttonSizePct = pct.coerceIn(60, 180)
        if (isAddedToWindow) safeRebuildLayout(isHorizontal)
    }

    fun setOpacity(pct: Int) {
        opacityPct = pct.coerceIn(10, 100)
        if (isFaded) alpha = opacityPct / 100f
    }

    fun setFadeDelay(ms: Long) {
        fadeDelayMs = ms.coerceAtLeast(0L)
        resetFade()
    }

    fun setVibrationEnabled(enabled: Boolean) {
        vibrationEnabled = enabled
    }

    // ======================== TİTREŞİM ========================

    private fun vibrate() {
        if (!vibrationEnabled) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                vm.defaultVibrator.vibrate(
                    VibrationEffect.createOneShot(30, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                @Suppress("DEPRECATION")
                val v = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                v.vibrate(VibrationEffect.createOneShot(30, VibrationEffect.DEFAULT_AMPLITUDE))
            }
        } catch (_: Exception) {
        }
    }

    // ======================== DP YARDIMCI ========================

    private fun Int.dpToPx(): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            this.toFloat(),
            context.resources.displayMetrics
        ).toInt()
    }

    private fun dp(value: Int): Int = value.dpToPx()
}