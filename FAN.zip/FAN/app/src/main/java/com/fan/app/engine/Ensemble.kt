package com.fan.app.engine

import com.fan.app.data.DataEntry
import kotlin.math.max
import kotlin.math.min

object Ensemble {

    private val ogd = OnlineGradientDescent()
    private val bayesian = BayesianUpdater()
    private val qLearning = QLearningEngine()
    private val transformer = MiniTransformer()
    private val markov = MarkovPredictor()

    // ── Sonuç Sınıfları ──────────────────────────────────────────────

    data class MethodVote(
        val methodIndex: Int,
        val methodName: String,
        val nativeVotes: Map<Int, Double>,
        val nativePrediction1: Int,
        val nativePrediction2: Int,
        val nativeConfidence: Double,
        val patternPrediction1: Int,
        val patternPrediction2: Int,
        val patternConfidence: Double,
        val patternRefLength: Int,
        val patternRefRegime: String,
        val patternRefCount: Int,
        val regimePrediction1: Int,
        val regimePrediction2: Int,
        val regimeConfidence: Double,
        val metaPrediction1: Int,
        val metaPrediction2: Int,
        val metaConfidence: Double,
        val blendedPrediction1: Int,
        val blendedPrediction2: Int,
        val blendedConfidence: Double,
        val finalPrediction1: Int,
        val finalPrediction2: Int,
        val finalConfidence: Double,
        val decisionSource: DecisionSource,
        val biasShifted: Boolean,
        val isActive: Boolean,
        val isMuted: Boolean,
        val streakSuccess: Int,
        val streakFail: Int,
        val voteMultiplier: Double
    )

    data class EnsembleResult(
        val finalPrediction1: Int,
        val finalPrediction2: Int,
        val confidence: Double,
        val showDouble: Boolean,
        val methodVotes: List<MethodVote>,
        val totalVotes: Map<Int, Double>,
        val sideStandard: SidePrediction.SidePredictionResult,
        val sideStandardFormatted: String,
        val sideRegime: SidePrediction.SidePredictionResult,
        val sideRegimeFormatted: String,
        val sideDisplay: String,
        val combinedPrediction1: Int,
        val combinedPrediction2: Int,
        val combinedConfidence: Double,
        val combinedShowDouble: Boolean,
        val kalipPrediction1: Int,
        val kalipPrediction2: Int,
        val kalipConfidence: Double,
        val kalipShowDouble: Boolean,
        val currentRegime: String,
        val previousRegime: String,
        val regimeStableCount: Int,
        val detectedPattern: String,
        val regimeSequence: String,
        val matchedPatternLength: Int,
        val matchedPatternCount: Int,
        val matchedPatternRegime: String,
        val regimeSimilarityScore: Double,
        val chaosScore: Double,
        val patternBreakLength: Int,
        val anomalyInfo: AnomalyDetector.AnomalyResult?,
        val metaConfidence: Double,
        val councilDecision: MeritCouncil.CouncilDecision
    )

    data class FinalResolution(
        val prediction1: Int,
        val prediction2: Int,
        val confidence: Double,
        val showDouble: Boolean
    )

    // ── Kaynak ağırlıkları ───────────────────────────────────────────
    private data class SourceWeights(
        val native: Double,
        val pattern: Double,
        val regime: Double,
        val meta: Double
    )

    // ── Rejim Kararlılık Takibi ──────────────────────────────────────
    private var lastRegime: String = ""
    private var regimeStableCount: Int = 0

    // ── Ana Hesaplama ─────────────────────────────────────────────────
    fun compute(data: List<Int>, pastEntries: List<DataEntry> = emptyList()): EnsembleResult {
        val eq = equal()

        if (data.size < DataEntry.INTERNAL_THRESHOLD) {
            val side = SidePrediction.analyzeStandard(data)
            val sideStr = SidePrediction.formatSidePrediction(side)
            return EnsembleResult(
                finalPrediction1 = 0, finalPrediction2 = 0, confidence = 0.0, showDouble = true,
                methodVotes = emptyList(), totalVotes = eq,
                sideStandard = side, sideStandardFormatted = sideStr,
                sideRegime = side, sideRegimeFormatted = sideStr,
                sideDisplay = "$sideStr/$sideStr",
                combinedPrediction1 = 0, combinedPrediction2 = 0, combinedConfidence = 0.0, combinedShowDouble = true,
                kalipPrediction1 = 0, kalipPrediction2 = 0, kalipConfidence = 0.0, kalipShowDouble = true,
                currentRegime = "KAOS", previousRegime = "", regimeStableCount = 0,
                detectedPattern = "NONE", regimeSequence = "",
                matchedPatternLength = 0, matchedPatternCount = 0, matchedPatternRegime = "",
                regimeSimilarityScore = 0.0, chaosScore = 0.0, patternBreakLength = 0,
                anomalyInfo = null, metaConfidence = 0.0,
                councilDecision = MeritCouncil.CouncilDecision(
                    emptyList(), emptyList(), emptyList(), emptyList(), emptyList(), emptyMap(), "YetersizVeri"
                )
            )
        }

        // Rejim analizi
        val regimeAnalysis = RegimeDetector.analyze(data)
        val patternInfo = RegimeDetector.detectPattern(data)
        val regimeGroup = regimeAnalysis.currentRegimeType.group
        val currentRegimeStr = if (regimeAnalysis.subType.isBlank()) {
            regimeAnalysis.currentRegimeType.name
        } else {
            "${regimeAnalysis.currentRegimeType.name}_${regimeAnalysis.subType}"
        }

        // Rejim kararlılığı
        if (currentRegimeStr == lastRegime) {
            regimeStableCount++
        } else {
            regimeStableCount = 1
        }
        val previousRegime = lastRegime
        lastRegime = currentRegimeStr

        // Bağlamsal hafıza sorgusu
        val patternQuery = ContextualMemory.queryPatternPrediction(data)
        val chaosScore = ContextualMemory.getChaosScore()
        val bestModelsForRegime = ContextualMemory.queryBestModelsForRegime(currentRegimeStr)

        // Meclis kararı
        val councilDecision = MeritCouncil.makeDecision(pastEntries)

        // Anomali tespiti
        val anomaly = AnomalyDetector.detect(data, pastEntries.map { it.value })

        // Pattern break kontrolü
        val patternBreakLen = if (patternInfo.type != "NONE" &&
            anomaly.anomalies.any { it.type == AnomalyDetector.AnomalyType.PATTERN_BREAK }
        ) {
            patternInfo.length
        } else {
            0
        }

        // Gating
        val streak = RegimeDetector.getCurrentStreak(data)
        val recentPerf = extractRecentPerformance(pastEntries)
        val gatingContext = ContextualGating.GatingContext(
            data = data,
            regime = regimeAnalysis.currentRegime,
            regimeSubType = regimeAnalysis.subType,
            pattern = patternInfo,
            streak = streak,
            recentPerformance = recentPerf
        )
        val gatingResults = ContextualGating.evaluateAllMethods(gatingContext)
        val finalGating = ContextualGating.applyEmergencyActivation(gatingResults)

        // Method Votes hesapla
        val methodVotes = computeMethodVotes(
            data, finalGating, pastEntries, patternQuery, regimeAnalysis,
            currentRegimeStr, bestModelsForRegime, councilDecision, chaosScore
        )

        // Ensemble oylama (sadece aktif modeller)
        val activeVotes = methodVotes.filter { it.isActive && !it.isMuted }
        val totalVotes = aggregateVotes(activeVotes)

        // Final tahmin
        val finalResult = resolveFinalPrediction(totalVotes, chaosScore, anomaly)

        // Side tahminleri (dual)
        val sideStandard = SidePrediction.analyzeStandard(data, regimeGroup)
        val sideStdStr = SidePrediction.formatSidePrediction(sideStandard)
        val sideRegime = SidePrediction.analyzeRegimeBehavior(
            data, currentRegimeStr,
            regimeAnalysis.regimeSequence.toDisplayString(), pastEntries
        )
        val sideRegStr = SidePrediction.formatSidePrediction(sideRegime)
        val sideDisplay = "$sideStdStr/$sideRegStr"

        // Combined (5'li)
        val combined = computeSubEnsemble(activeVotes, DataEntry.COMBINED_METHOD_INDICES)

        // Kalıp tek başına (meclis kuralları geçerli değil)
        val kalipVote = methodVotes.find { it.methodIndex == 0 }
        val kalipPred1 = kalipVote?.nativePrediction1 ?: 0
        val kalipPred2 = kalipVote?.nativePrediction2 ?: 0
        val kalipConf = kalipVote?.nativeConfidence ?: 0.0
        val kalipShowDouble = kalipConf < 0.60

        // Detected pattern string temiz
        val detectedPatternStr = if (patternInfo.type == "NONE") "NONE"
        else "${patternInfo.type}_${patternInfo.length}"

        return EnsembleResult(
            finalPrediction1 = finalResult.prediction1,
            finalPrediction2 = finalResult.prediction2,
            confidence = finalResult.confidence,
            showDouble = finalResult.showDouble,
            methodVotes = methodVotes,
            totalVotes = totalVotes,
            sideStandard = sideStandard,
            sideStandardFormatted = sideStdStr,
            sideRegime = sideRegime,
            sideRegimeFormatted = sideRegStr,
            sideDisplay = sideDisplay,
            combinedPrediction1 = combined.first,
            combinedPrediction2 = combined.second ?: 0,
            combinedConfidence = combined.third,
            combinedShowDouble = combined.third < 0.60,
            kalipPrediction1 = kalipPred1,
            kalipPrediction2 = kalipPred2,
            kalipConfidence = kalipConf,
            kalipShowDouble = kalipShowDouble,
            currentRegime = currentRegimeStr,
            previousRegime = previousRegime,
            regimeStableCount = regimeStableCount,
            detectedPattern = detectedPatternStr,
            regimeSequence = regimeAnalysis.regimeSequence.toDisplayString(),
            matchedPatternLength = patternQuery.patternLength,
            matchedPatternCount = patternQuery.matchCount,
            matchedPatternRegime = patternQuery.patternRegime,
            regimeSimilarityScore = computeRegimeSimilarity(currentRegimeStr, patternQuery.patternRegime),
            chaosScore = chaosScore,
            patternBreakLength = patternBreakLen,
            anomalyInfo = anomaly,
            metaConfidence = calculateMetaConfidence(activeVotes, anomaly),
            councilDecision = councilDecision
        )
    }

    // ── Method Vote Hesaplama ────────────────────────────────────────
    private fun computeMethodVotes(
        data: List<Int>,
        gating: List<ContextualGating.GatingResult>,
        pastEntries: List<DataEntry>,
        patternQuery: ContextualMemory.PatternQueryResult,
        regimeAnalysis: RegimeDetector.RegimeAnalysisResult,
        currentRegimeStr: String,
        bestModelsForRegime: List<Pair<Int, Double>>,
        councilDecision: MeritCouncil.CouncilDecision,
        chaosScore: Double
    ): List<MethodVote> {
        val votes = mutableListOf<MethodVote>()
        val patterns = PatternMatcher.findPatterns(data)
        val patResult = PatternMatcher.analyzePatternVotes(data, patterns)
        val behavVotes = PatternMatcher.behaviorAnalysis(data, patterns)
        fun g(i: Int) = gating.getOrElse(i) { ContextualGating.GatingResult(i, true, 1.0, "") }

        // Kaos bucket hesabı
        val chaosBkt = chaosBucket(chaosScore)

        // Rejim grupları (Q-Learning ve Transformer için)
        val currentGroup = regimeAnalysis.currentRegimeType.group
        val previousGroup = regimeAnalysis.regimeSequence.regimes.dropLast(1)
            .lastOrNull()?.type?.group ?: currentGroup

        // Global meta oyları
        val globalMetaVotes = MetaLearner().compute(data, emptyList(), pastEntries)

        val rawNativeVotes = listOf(
            mergeVoteMaps(listOf(patResult.votes to 0.7, behavVotes to 0.3)),    // 0: Kalip_Arama
            RegimeDetector.analyze(data).votes,                                    // 1: Rejim_Tespiti
            PatternMatcher.findDeltaPatternVotes(data),                           // 2: Fark_Dizisi
            PatternMatcher.findMirrorPatternVotes(data),                          // 3: Ayna_Kalip
            computeClusterShiftVotes(data, patterns),                             // 4: Kume_Kaymasi
            computeExpectationDriftVotes(data, patterns),                          // 5: Beklenti_Sapma
            computeWaveRepeatVotes(data),                                          // 6: Dalga_Tekrar
            ogd.compute(data),                                                     // 7: Online_Gradient
            bayesian.compute(data),                                                // 8: Bayesian
            globalMetaVotes,                                                       // 9: Meta_Ogrenme
            qLearning.computeWithContext(data, currentGroup, previousGroup,        // 10: Q_Learning
                patternQuery.patternLength, chaosBkt, councilDecision.activeModels.size),
            transformer.computeWithContext(data, currentGroup,                     // 11: Mini_Transformer
                patternQuery.patternLength, chaosBkt),
            markov.compute(data)                                                   // 12: Markov
        )

        // Global pattern ve regime oyları
        val patternVotesGlobal = buildPatternVotes(patternQuery)
        val regimeVotesGlobal = buildRegimeVotes(currentRegimeStr, regimeAnalysis.votes)

        for (i in 0 until DataEntry.METHOD_COUNT) {
            val nativeVotes = rawNativeVotes[i]
            val nativeSorted = nativeVotes.entries.sortedByDescending { it.value }
            val nativePred1 = nativeSorted[0].key
            val nativePred2 = nativeSorted.getOrNull(1)?.key ?: nativePred1
            val nativeConf = nativeSorted[0].value

            // Kalıp katmanı
            val patternSorted = patternVotesGlobal.entries.sortedByDescending { it.value }
            val patPred1 = patternSorted[0].key
            val patPred2 = patternSorted.getOrNull(1)?.key ?: patPred1
            val patConf = patternSorted[0].value
            val patRefLen = patternQuery.patternLength
            val patRefRegime = patternQuery.patternRegime
            val patRefCount = patternQuery.matchCount

            // Rejim katmanı
            val regimeSorted = regimeVotesGlobal.entries.sortedByDescending { it.value }
            val regimePred1 = regimeSorted[0].key
            val regimePred2 = regimeSorted.getOrNull(1)?.key ?: regimePred1
            val regimeConf = regimeSorted[0].value

            // Meta katmanı
            val metaVotes = buildMetaVotesForMethod(i, rawNativeVotes, globalMetaVotes, bestModelsForRegime)
            val metaSorted = metaVotes.entries.sortedByDescending { it.value }
            val metaPred1 = metaSorted[0].key
            val metaPred2 = metaSorted.getOrNull(1)?.key ?: metaPred1
            val metaConf = metaSorted[0].value

            // Kaynak ağırlıkları
            val weights = buildSourceWeights(i, pastEntries, patternQuery.found)

            // Blended (harmanlanmış) tahmin
            val blendedVotes = buildBlendedVotes(
                i, nativeVotes, patternVotesGlobal, regimeVotesGlobal, metaVotes,
                weights, pastEntries, chaosScore
            )
            val blendedSorted = blendedVotes.entries.sortedByDescending { it.value }
            val blendedPred1 = blendedSorted[0].key
            val blendedPred2 = blendedSorted.getOrNull(1)?.key ?: blendedPred1
            val blendedConf = blendedSorted[0].value

            // Final: blended + bias kırıcı
            var finalPred1 = blendedPred1
            var finalPred2 = blendedPred2
            var finalConf = blendedConf
            var biasShifted = false

            if (shouldBiasShift(i, finalPred1, pastEntries) && finalPred2 != finalPred1) {
                val tmp = finalPred1
                finalPred1 = finalPred2
                finalPred2 = tmp
                finalConf *= 0.92
                biasShifted = true
            }

            // Gating etkisi
            finalConf *= (0.85 + 0.15 * g(i).activityLevel)

            // Karar kaynağı tespiti
            val decisionSource = if (biasShifted) {
                DecisionSource.BIAS_SHIFTED
            } else {
                dominantDecisionSource(finalPred1, nativeVotes, patternVotesGlobal, regimeVotesGlobal, metaVotes, weights)
            }

            // Meclis durumu
            val councilState = MeritCouncil.getStateSnapshot(i)
            val isActive = i in councilDecision.activeModels
            val isMuted = i in councilDecision.mutedModels
            val multiplier = councilDecision.multipliers[i] ?: 1.0

            votes.add(
                MethodVote(
                    methodIndex = i,
                    methodName = DataEntry.METHOD_NAMES[i],
                    nativeVotes = nativeVotes,
                    nativePrediction1 = nativePred1,
                    nativePrediction2 = nativePred2,
                    nativeConfidence = nativeConf,
                    patternPrediction1 = patPred1,
                    patternPrediction2 = patPred2,
                    patternConfidence = patConf,
                    patternRefLength = patRefLen,
                    patternRefRegime = patRefRegime,
                    patternRefCount = patRefCount,
                    regimePrediction1 = regimePred1,
                    regimePrediction2 = regimePred2,
                    regimeConfidence = regimeConf,
                    metaPrediction1 = metaPred1,
                    metaPrediction2 = metaPred2,
                    metaConfidence = metaConf,
                    blendedPrediction1 = blendedPred1,
                    blendedPrediction2 = blendedPred2,
                    blendedConfidence = blendedConf,
                    finalPrediction1 = finalPred1,
                    finalPrediction2 = finalPred2,
                    finalConfidence = finalConf,
                    decisionSource = decisionSource,
                    biasShifted = biasShifted,
                    isActive = isActive,
                    isMuted = isMuted,
                    streakSuccess = councilState.streakSuccess,
                    streakFail = councilState.streakFail,
                    voteMultiplier = multiplier
                )
            )
        }

        return votes
    }

    // ── Kaynak Ağırlıkları ───────────────────────────────────────────
    /**
     * Her model için native / pattern / regime / meta ağırlıklarını hesaplar.
     * Kalıp modeli EZMEMELİ, DESTEKLEMELİ prensibi burada uygulanır.
     * Native her zaman ana omurga kalır.
     */
    private fun buildSourceWeights(
        methodIndex: Int,
        pastEntries: List<DataEntry>,
        patternFound: Boolean
    ): SourceWeights {
        // Kaynak güvenilirliği (son 20 turdaki başarı)
        val nativeRel = sourceReliability(pastEntries, methodIndex, "native_dogru")
        val patternRel = sourceReliability(pastEntries, methodIndex, "kalip_dogru")
        val regimeRel = sourceReliability(pastEntries, methodIndex, "rejim_dogru")
        val metaRel = sourceReliability(pastEntries, methodIndex, "meta_dogru")

        // Temel ağırlıklar — native her zaman dominant
        var native = 0.52 + 0.18 * nativeRel
        var pattern = (if (patternFound) 0.10 else 0.03) + 0.12 * patternRel
        var regime = 0.10 + 0.10 * regimeRel
        var meta = 0.08 + 0.08 * metaRel

        // Kalıp-ağırlıklı metodlara hafif pattern bonusu
        if (methodIndex in listOf(0, 3, 4, 5, 6)) pattern += 0.05
        // Öğrenen modellere hafif regime bonusu
        if (methodIndex in DataEntry.LEARNING_METHOD_INDICES) regime += 0.03

        // Normalize
        val total = native + pattern + regime + meta
        native /= total
        pattern /= total
        regime /= total
        meta /= total

        return SourceWeights(native, pattern, regime, meta)
    }

    /**
     * Son 20 turdaki trace kolonlarından kaynak güvenilirliğini hesaplar.
     */
    private fun sourceReliability(
        pastEntries: List<DataEntry>,
        methodIndex: Int,
        suffix: String
    ): Double {
        val name = DataEntry.METHOD_NAMES[methodIndex]
        val recent = pastEntries.takeLast(20)
        if (recent.size < 5) return 0.5

        var correct = 0
        var total = 0
        for (entry in recent) {
            val traceVal = entry.getTrace("${name}_$suffix").trim().uppercase()
            if (traceVal == "EVET" || traceVal == "TRUE" || traceVal == "1") {
                correct++
                total++
            } else if (traceVal == "HAYIR" || traceVal == "FALSE" || traceVal == "0") {
                total++
            }
        }

        return if (total >= 5) correct.toDouble() / total else 0.5
    }

    // ── Kalıp oyları ─────────────────────────────────────────────────
    private fun buildPatternVotes(query: ContextualMemory.PatternQueryResult): Map<Int, Double> {
        if (!query.found || query.prediction1 !in 1..4) return equal()
        val votes = mutableMapOf(1 to 0.02, 2 to 0.02, 3 to 0.02, 4 to 0.02)
        votes[query.prediction1] = max(query.confidence, 0.45)
        if (query.prediction2 in 1..4 && query.prediction2 != query.prediction1) {
            votes[query.prediction2] = max(1.0 - query.confidence, 0.20)
        }
        return normalizeVotes(votes)
    }

    // ── Rejim oyları ─────────────────────────────────────────────────
    private fun buildRegimeVotes(
        currentRegimeStr: String,
        currentVotes: Map<Int, Double>
    ): Map<Int, Double> {
        val nextRegime = ContextualMemory.predictNextRegime(currentRegimeStr)
        val transitionVotes = ContextualMemory.queryRegimeTransitionPrediction(currentRegimeStr, nextRegime)
        return mergeVoteMaps(listOf(currentVotes to 0.65, transitionVotes to 0.35))
    }

    // ── Meta oyları ──────────────────────────────────────────────────
    private fun buildMetaVotesForMethod(
        methodIndex: Int,
        rawNativeVotes: List<Map<Int, Double>>,
        globalMetaVotes: Map<Int, Double>,
        bestModelsForRegime: List<Pair<Int, Double>>
    ): Map<Int, Double> {
        val bestPeer = bestModelsForRegime.firstOrNull { it.first != methodIndex && it.second > 0.30 }

        return if (bestPeer != null && bestPeer.first in rawNativeVotes.indices) {
            mergeVoteMaps(listOf(
                globalMetaVotes to 0.55,
                rawNativeVotes[bestPeer.first] to 0.45
            ))
        } else {
            globalMetaVotes
        }
    }

    // ── Blended (harmanlanmış) tahmin ────────────────────────────────
    /**
     * Dört kaynağı ağırlıklı olarak birleştirir.
     * Konsensüs bonusu ve tekrarlanan yanlış cezası uygulanır.
     * Native her zaman çekirdek kalır, kalıp EZMEz DESTEKLEr.
     */
    private fun buildBlendedVotes(
        methodIndex: Int,
        nativeVotes: Map<Int, Double>,
        patternVotes: Map<Int, Double>,
        regimeVotes: Map<Int, Double>,
        metaVotes: Map<Int, Double>,
        weights: SourceWeights,
        pastEntries: List<DataEntry>,
        chaosScore: Double
    ): Map<Int, Double> {
        val nativeTop = nativeVotes.maxByOrNull { it.value }?.key ?: 1
        val patternTop = patternVotes.maxByOrNull { it.value }?.key ?: 1
        val regimeTop = regimeVotes.maxByOrNull { it.value }?.key ?: 1
        val metaTop = metaVotes.maxByOrNull { it.value }?.key ?: 1

        val scores = mutableMapOf<Int, Double>()

        for (n in 1..4) {
            var score =
                (nativeVotes[n] ?: 0.0) * weights.native +
                        (patternVotes[n] ?: 0.0) * weights.pattern +
                        (regimeVotes[n] ?: 0.0) * weights.regime +
                        (metaVotes[n] ?: 0.0) * weights.meta

            // Konsensüs bonusu: birden fazla kaynak aynı adayı destekliyorsa
            if (nativeTop == n && patternTop == n) score += 0.08
            if (nativeTop == n && regimeTop == n) score += 0.05
            if (nativeTop == n && metaTop == n) score += 0.04
            if (patternTop == n && regimeTop == n) score += 0.03

            // Tekrarlanan yanlış cezası
            score -= repeatedWrongPenalty(methodIndex, n, pastEntries)

            // Yüksek kaos + desteksiz native → hafif ceza
            if (chaosScore > 12.0 && n == nativeTop &&
                (patternVotes[n] ?: 0.0) < 0.15 && (regimeVotes[n] ?: 0.0) < 0.15) {
                score -= 0.04
            }

            scores[n] = max(score, 0.001)
        }

        return normalizeVotes(scores)
    }

    // ── Tekrarlanan yanlış cezası ────────────────────────────────────
    private fun repeatedWrongPenalty(
        methodIndex: Int,
        candidate: Int,
        pastEntries: List<DataEntry>
    ): Double {
        val recent = pastEntries.takeLast(3)
        var penalty = 0.0
        for (entry in recent) {
            if (entry.getMethodFinalPrediction1(methodIndex) == candidate && !entry.getMethodCorrect(methodIndex)) {
                penalty += 0.07
            }
        }
        return min(penalty, 0.21)
    }

    // ── Bias Kırıcı ──────────────────────────────────────────────────
    /**
     * Aynı final primary, 3 tur üst üste yanlışsa → secondary öne alınır.
     */
    private fun shouldBiasShift(
        methodIndex: Int,
        candidate: Int,
        pastEntries: List<DataEntry>
    ): Boolean {
        val recent = pastEntries.takeLast(3)
        if (recent.size < 3) return false
        return recent.all {
            it.getMethodFinalPrediction1(methodIndex) == candidate && !it.getMethodCorrect(methodIndex)
        }
    }

    // ── Dominant Karar Kaynağı Tespiti ────────────────────────────────
    private fun dominantDecisionSource(
        candidate: Int,
        nativeVotes: Map<Int, Double>,
        patternVotes: Map<Int, Double>,
        regimeVotes: Map<Int, Double>,
        metaVotes: Map<Int, Double>,
        weights: SourceWeights
    ): DecisionSource {
        val contributions = listOf(
            DecisionSource.NATIVE to (nativeVotes[candidate] ?: 0.0) * weights.native,
            DecisionSource.PATTERN to (patternVotes[candidate] ?: 0.0) * weights.pattern,
            DecisionSource.REGIME to (regimeVotes[candidate] ?: 0.0) * weights.regime,
            DecisionSource.META to (metaVotes[candidate] ?: 0.0) * weights.meta
        ).sortedByDescending { it.second }

        val top = contributions.first()
        val second = contributions.getOrNull(1)

        return if (second != null && (top.second - second.second) < 0.07) {
            DecisionSource.BLENDED
        } else {
            top.first
        }
    }

    // ── Oylama ───────────────────────────────────────────────────────
    private fun aggregateVotes(activeVotes: List<MethodVote>): Map<Int, Double> {
        val total = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)

        for (vote in activeVotes) {
            val weight = vote.voteMultiplier * vote.finalConfidence

            if (vote.finalConfidence < 0.60) {
                total[vote.finalPrediction1] = (total[vote.finalPrediction1] ?: 0.0) + 0.6 * weight
                total[vote.finalPrediction2] = (total[vote.finalPrediction2] ?: 0.0) + 0.4 * weight
            } else {
                total[vote.finalPrediction1] = (total[vote.finalPrediction1] ?: 0.0) + weight
            }
        }

        val sum = total.values.sum()
        return if (sum > 0) total.mapValues { it.value / sum } else equal()
    }

    // ── Final Tahmin ─────────────────────────────────────────────────
    private fun resolveFinalPrediction(
        votes: Map<Int, Double>,
        chaosScore: Double,
        anomaly: AnomalyDetector.AnomalyResult?
    ): FinalResolution {
        var confidence = votes.values.maxOrNull() ?: 0.25
        var showDouble = confidence < 0.60

        if (chaosScore > 10.0) {
            showDouble = true
            confidence *= 0.85
        }

        if (anomaly != null) {
            confidence *= anomaly.confidenceAdjustment
            showDouble = showDouble || anomaly.shouldShowDouble
        }

        val sorted = votes.entries.sortedByDescending { it.value }
        val pred1 = sorted[0].key
        val pred2 = sorted.getOrNull(1)?.key ?: pred1

        return FinalResolution(pred1, pred2, confidence, showDouble)
    }

    // ── Sub Ensemble ─────────────────────────────────────────────────
    private fun computeSubEnsemble(
        activeVotes: List<MethodVote>,
        indices: List<Int>
    ): Triple<Int, Int?, Double> {
        val votes = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)
        for (idx in indices) {
            val mv = activeVotes.find { it.methodIndex == idx } ?: continue
            val weight = mv.voteMultiplier
            votes[mv.finalPrediction1] = (votes[mv.finalPrediction1] ?: 0.0) + weight
        }
        val total = votes.values.sum().coerceAtLeast(1e-9)
        val sorted = votes.mapValues { it.value / total }.entries.sortedByDescending { it.value }
        val pri = sorted[0].key
        val conf = sorted[0].value
        val sec = if (conf < 0.60) sorted.getOrNull(1)?.key else null
        return Triple(pri, sec, conf)
    }

    // ── Meta Confidence ──────────────────────────────────────────────
    /**
     * Çeşitlilik kontrolü eklendi:
     * - Tüm modeller aynı kaynaktan aynı tahmini veriyorsa → echo penalty
     * - Karar kaynağı çeşitliliği de confidence'a katkı yapar
     */
    private fun calculateMetaConfidence(
        activeVotes: List<MethodVote>,
        anomaly: AnomalyDetector.AnomalyResult?
    ): Double {
        if (activeVotes.size < 2) return 0.25

        val freq = activeVotes.map { it.finalPrediction1 }.groupBy { it }.mapValues { it.value.size }
        val agreement = (freq.values.maxOrNull() ?: 0).toDouble() / activeVotes.size

        // Karar kaynağı çeşitliliği
        val sourceDiversity = activeVotes.map { it.decisionSource }.toSet().size.toDouble() / DecisionSource.entries.size

        // Echo penalty: herkes aynı kaynaktan aynı şeyi diyorsa
        val echoPenalty = if (sourceDiversity < 0.25 && agreement > 0.70) 0.10 else 0.0

        val base = 0.25 + 0.55 * agreement + 0.20 * sourceDiversity - echoPenalty
        val anomPen = anomaly?.overallSeverity?.times(-0.25) ?: 0.0

        return minOf(maxOf(base + anomPen, 0.1), 0.95)
    }

    // ── Rejim Benzerlik Skoru ─────────────────────────────────────────
    private fun computeRegimeSimilarity(currentRegime: String, patternRegime: String): Double {
        if (patternRegime.isBlank()) return 0.0
        return when {
            currentRegime == patternRegime -> 1.0
            extractRegimeGroup(currentRegime) == extractRegimeGroup(patternRegime) -> 0.65
            else -> 0.20
        }
    }

    private fun extractRegimeGroup(regime: String): String {
        return when {
            regime.contains("TEKRAR") || regime.contains("BLOK") || regime.contains("DALGA_TEK") -> "TEKRAR"
            regime.contains("ARTIS") || regime.contains("AZALIS") || regime.contains("TEPE") ||
                    regime.contains("VADI") || regime.contains("DONGU") -> "YON"
            regime.contains("SINIR") || regime.contains("KOSEGEN") || regime.contains("ZIGZAK") -> "SALINIMM"
            else -> "KAOS"
        }
    }

    // ── Kaos Bucket ──────────────────────────────────────────────────
    private fun chaosBucket(chaosScore: Double): Int = when {
        chaosScore >= 20.0 -> 4
        chaosScore >= 12.0 -> 3
        chaosScore >= 6.0 -> 2
        chaosScore >= 2.0 -> 1
        else -> 0
    }

    // ── Yardımcı Fonksiyonlar ─────────────────────────────────────────

    private fun extractRecentPerformance(pastEntries: List<DataEntry>): List<Pair<Int, Boolean>> =
        pastEntries.takeLast(50).flatMap { entry ->
            (0 until DataEntry.METHOD_COUNT).mapNotNull { idx ->
                if (!entry.getMethodActive(idx)) null
                else Pair(idx, entry.getMethodCorrect(idx))
            }
        }

    private fun computeClusterShiftVotes(data: List<Int>, patterns: List<PatternMatcher.PatternMatch>): Map<Int, Double> {
        val rd = computeDensity(data.takeLast(250))
        val pd = if (patterns.isNotEmpty()) computePatternDensity(data, patterns.maxByOrNull { it.patternLength }!!)
        else equal()
        val v = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)
        for (k in 1..4) v[k] = (rd[k] ?: 0.25) * 0.8 + (pd[k] ?: 0.25) * 0.2
        return normalizeVotes(v)
    }

    private fun computeDensity(data: List<Int>): Map<Int, Double> {
        if (data.isEmpty()) return equal()
        val f = mutableMapOf(1 to 0, 2 to 0, 3 to 0, 4 to 0)
        data.forEach { if (it in 1..4) f[it] = (f[it] ?: 0) + 1 }
        return f.mapValues { it.value / data.size.toDouble() }
    }

    private fun computePatternDensity(data: List<Int>, pattern: PatternMatcher.PatternMatch): Map<Int, Double> {
        val v = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)
        for (pos in pattern.matchPositions) {
            val ap = pos + pattern.patternLength
            if (ap < data.size - pattern.patternLength) {
                val nv = data[ap]
                if (nv in 1..4) v[nv] = (v[nv] ?: 0.0) + 1.0
            }
        }
        return normalizeVotes(v)
    }

    private fun computeExpectationDriftVotes(data: List<Int>, patterns: List<PatternMatcher.PatternMatch>): Map<Int, Double> {
        if (patterns.isEmpty() || data.size < 10) return equal()
        val v = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)
        for (pattern in patterns) {
            if (pattern.matchPositions.isEmpty()) continue
            val ac = mutableMapOf(1 to 0, 2 to 0, 3 to 0, 4 to 0)
            for (pos in pattern.matchPositions) {
                val ap = pos + pattern.patternLength
                if (ap < data.size - pattern.patternLength) {
                    val nv = data[ap]
                    if (nv in 1..4) ac[nv] = (ac[nv] ?: 0) + 1
                }
            }
            val total = ac.values.sum().toDouble()
            if (total == 0.0) continue
            val pw = pattern.patternLength.toDouble() / 10.0
            for ((k, count) in ac) {
                val rec = PatternMatcher.recencyFactor(data.size - pattern.matchPositions.last(), data.size)
                v[k] = (v[k] ?: 0.0) + (count / total) * pw * rec
            }
        }
        return normalizeVotes(v)
    }

    private fun computeWaveRepeatVotes(data: List<Int>): Map<Int, Double> {
        val wv = computeWaveVotes(data)
        val sv = RegimeDetector.getStreakBreakVotes(data)
        val v = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)
        for ((k, x) in wv) v[k] = (v[k] ?: 0.0) + x * 0.5
        for ((k, x) in sv) v[k] = (v[k] ?: 0.0) + x * 0.5
        return normalizeVotes(v)
    }

    private fun computeWaveVotes(data: List<Int>): Map<Int, Double> {
        if (data.size < 4) return equal()
        val v = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)
        for (i in 2 until data.size - 1) {
            val d1 = data[i] - data[i - 1]
            val d2 = data[i - 1] - data[i - 2]
            if (kotlin.math.abs(d1) in 1..3 && kotlin.math.abs(d2) in 1..3) {
                val nv = data[i + 1]
                if (nv in 1..4) {
                    val rec = PatternMatcher.recencyFactor(data.size - i, data.size)
                    v[nv] = (v[nv] ?: 0.0) + rec
                }
            }
        }
        return normalizeVotes(v)
    }

    private fun normalizeVotes(v: Map<Int, Double>): Map<Int, Double> {
        val t = v.values.sum()
        if (t == 0.0) return equal()
        return v.mapValues { it.value / t }
    }

    private fun mergeVoteMaps(vww: List<Pair<Map<Int, Double>, Double>>): Map<Int, Double> {
        val r = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)
        var tw = 0.0
        for ((votes, w) in vww) {
            for ((k, v) in votes) r[k] = (r[k] ?: 0.0) + v * w
            tw += w
        }
        if (tw == 0.0) return equal()
        return r.mapValues { it.value / tw }
    }

    private fun equal() = mapOf(1 to 0.25, 2 to 0.25, 3 to 0.25, 4 to 0.25)

    fun formatPrediction(r: EnsembleResult): String =
        if (r.showDouble && r.finalPrediction2 > 0) "${r.finalPrediction1}/${r.finalPrediction2}"
        else "${r.finalPrediction1}"

    fun formatConfidence(r: EnsembleResult): String = "%${(r.confidence * 100).toInt()}"
}