package com.fan.app.engine

object SidePrediction {

    enum class OddEven { ODD, EVEN }
    enum class SmallBig { SMALL, BIG }

    data class SidePredictionResult(
        val oddEvenPrediction: OddEven,
        val oddEvenConfidence: Double,
        val oddEvenSecond: OddEven?,
        val smallBigPrediction: SmallBig,
        val smallBigConfidence: Double,
        val smallBigSecond: SmallBig?
    )

    data class DualSideResult(
        val standardPrediction: String,
        val regimePrediction: String,
        val displayPrediction: String
    )

    fun Int.toOddEven(): OddEven = if (this % 2 != 0) OddEven.ODD else OddEven.EVEN
    fun Int.toSmallBig(): SmallBig = if (this <= 2) SmallBig.SMALL else SmallBig.BIG

    // ── Rejim Ağırlıkları ────────────────────────────────────────────
    private fun regimeWeights(regimeGroup: String): DoubleArray = when (regimeGroup) {
        "TEKRAR"   -> doubleArrayOf(0.6, 1.5, 2.0, 0.5, 0.8, 0.6)
        "YON"      -> doubleArrayOf(1.2, 0.8, 0.6, 2.0, 1.0, 0.8)
        "SALINIMM" -> doubleArrayOf(2.0, 0.5, 0.5, 1.0, 1.5, 1.5)
        "KAOS"     -> doubleArrayOf(0.8, 1.5, 0.8, 0.8, 0.8, 0.8)
        else       -> doubleArrayOf(1.0, 1.0, 1.0, 1.0, 1.0, 1.0)
    }

    // ── Standart Side Analizi ────────────────────────────────────────
    fun analyzeStandard(data: List<Int>, regimeGroup: String = "KAOS"): SidePredictionResult {
        if (data.size < 3) return SidePredictionResult(
            OddEven.ODD, 0.5, OddEven.EVEN,
            SmallBig.SMALL, 0.5, SmallBig.BIG
        )

        val w = regimeWeights(regimeGroup)
        val oeData = data.map { if (it.toOddEven() == OddEven.ODD) 0 else 1 }
        val sbData = data.map { if (it.toSmallBig() == SmallBig.SMALL) 0 else 1 }

        val oeVotes = analyzeAxis(oeData, w)
        val sbVotes = analyzeAxis(sbData, w)

        val oePred = if ((oeVotes[0] ?: 0.5) >= (oeVotes[1] ?: 0.5)) OddEven.ODD else OddEven.EVEN
        val oeConf = maxOf(oeVotes[0] ?: 0.5, oeVotes[1] ?: 0.5)
        val oeSecond = if (oeConf < 0.60) (if (oePred == OddEven.ODD) OddEven.EVEN else OddEven.ODD) else null

        val sbPred = if ((sbVotes[0] ?: 0.5) >= (sbVotes[1] ?: 0.5)) SmallBig.SMALL else SmallBig.BIG
        val sbConf = maxOf(sbVotes[0] ?: 0.5, sbVotes[1] ?: 0.5)
        val sbSecond = if (sbConf < 0.60) (if (sbPred == SmallBig.SMALL) SmallBig.BIG else SmallBig.SMALL) else null

        return SidePredictionResult(oePred, oeConf, oeSecond, sbPred, sbConf, sbSecond)
    }

    // ── Rejim Davranış Side Analizi (Yeni) ───────────────────────────
    fun analyzeRegimeBehavior(
        data: List<Int>,
        currentRegime: String,
        regimeSequence: String,
        allEntries: List<com.fan.app.data.DataEntry>
    ): SidePredictionResult {
        if (data.size < 5) return SidePredictionResult(
            OddEven.ODD, 0.5, OddEven.EVEN,
            SmallBig.SMALL, 0.5, SmallBig.BIG
        )

        val oeVotes = mutableMapOf(0 to 0.0, 1 to 0.0)
        val sbVotes = mutableMapOf(0 to 0.0, 1 to 0.0)

        val regimeParts = regimeSequence.split(">").filter { it.isNotBlank() }

        // Geçmişte bu rejim dizisi veya benzer diziler yaşandığında
        // sonraki değerlerin OE/SB dağılımını hesapla
        if (regimeParts.isNotEmpty() && allEntries.size > 10) {
            for (i in 0 until allEntries.size - 1) {
                val entry = allEntries[i]
                val entryRegime = entry.currentRegime

                val regimeMatch = when {
                    entryRegime == currentRegime -> 1.0
                    extractRegimeGroup(entryRegime) == extractRegimeGroup(currentRegime) -> 0.6
                    else -> 0.0
                }

                if (regimeMatch < 0.3) continue

                val nextEntry = allEntries[i + 1]
                val nextValue = nextEntry.value
                val oeVal = if (nextValue.toOddEven() == OddEven.ODD) 0 else 1
                val sbVal = if (nextValue.toSmallBig() == SmallBig.SMALL) 0 else 1

                val recency = PatternMatcher.recencyFactor(allEntries.size - i, allEntries.size)
                val weight = regimeMatch * recency

                oeVotes[oeVal] = (oeVotes[oeVal] ?: 0.0) + weight
                sbVotes[sbVal] = (sbVotes[sbVal] ?: 0.0) + weight
            }
        }

        // Rejim geçiş bazlı analiz
        if (regimeParts.size >= 2 && allEntries.size > 15) {
            val lastTwoRegimes = regimeParts.takeLast(2)
            for (i in 1 until allEntries.size - 1) {
                val prevRegime = allEntries[i - 1].currentRegime
                val currRegime = allEntries[i].currentRegime

                val prevGroup = extractRegimeGroup(prevRegime)
                val currGroup = extractRegimeGroup(currRegime)
                val targetPrevGroup = extractRegimeGroup(lastTwoRegimes[0])
                val targetCurrGroup = extractRegimeGroup(lastTwoRegimes[1])

                if (prevGroup == targetPrevGroup && currGroup == targetCurrGroup) {
                    val nextValue = allEntries[i + 1].value
                    val oeVal = if (nextValue.toOddEven() == OddEven.ODD) 0 else 1
                    val sbVal = if (nextValue.toSmallBig() == SmallBig.SMALL) 0 else 1

                    val recency = PatternMatcher.recencyFactor(allEntries.size - i, allEntries.size)
                    oeVotes[oeVal] = (oeVotes[oeVal] ?: 0.0) + recency * 1.5
                    sbVotes[sbVal] = (sbVotes[sbVal] ?: 0.0) + recency * 1.5
                }
            }
        }

        // Normalize
        val oeTotal = oeVotes.values.sum()
        val sbTotal = sbVotes.values.sum()

        val normalizedOe = if (oeTotal > 0) oeVotes.mapValues { it.value / oeTotal }
        else mapOf(0 to 0.5, 1 to 0.5)

        val normalizedSb = if (sbTotal > 0) sbVotes.mapValues { it.value / sbTotal }
        else mapOf(0 to 0.5, 1 to 0.5)

        val oePred = if ((normalizedOe[0] ?: 0.5) >= (normalizedOe[1] ?: 0.5)) OddEven.ODD else OddEven.EVEN
        val oeConf = maxOf(normalizedOe[0] ?: 0.5, normalizedOe[1] ?: 0.5)
        val oeSecond = if (oeConf < 0.60) (if (oePred == OddEven.ODD) OddEven.EVEN else OddEven.ODD) else null

        val sbPred = if ((normalizedSb[0] ?: 0.5) >= (normalizedSb[1] ?: 0.5)) SmallBig.SMALL else SmallBig.BIG
        val sbConf = maxOf(normalizedSb[0] ?: 0.5, normalizedSb[1] ?: 0.5)
        val sbSecond = if (sbConf < 0.60) (if (sbPred == SmallBig.SMALL) SmallBig.BIG else SmallBig.SMALL) else null

        return SidePredictionResult(oePred, oeConf, oeSecond, sbPred, sbConf, sbSecond)
    }

    private fun extractRegimeGroup(regime: String): String {
        return when {
            regime.contains("TEKRAR") || regime.contains("BLOK") || regime.contains("DALGA_TEK") -> "TEKRAR"
            regime.contains("ARTIS") || regime.contains("AZALIS") || regime.contains("TEPE") ||
                    regime.contains("VADI") || regime.contains("DONGU") -> "YON"
            regime.contains("SINIR") || regime.contains("KOSEGEN") || regime.contains("ZIGZAK") -> "SALINIMM"
            else -> "KAOS"
        }
    }

    // ── Dual Side Üretimi ────────────────────────────────────────────
    fun analyzeDual(
        data: List<Int>,
        regimeGroup: String,
        currentRegime: String,
        regimeSequence: String,
        allEntries: List<com.fan.app.data.DataEntry>
    ): DualSideResult {
        val standard = analyzeStandard(data, regimeGroup)
        val regimeBased = analyzeRegimeBehavior(data, currentRegime, regimeSequence, allEntries)

        val stdStr = formatSidePrediction(standard)
        val regStr = formatSidePrediction(regimeBased)

        val display = "$stdStr/$regStr"

        return DualSideResult(
            standardPrediction = stdStr,
            regimePrediction = regStr,
            displayPrediction = display
        )
    }

    // ── Axis Analiz ──────────────────────────────────────────────────
    private fun analyzeAxis(data: List<Int>, w: DoubleArray): Map<Int, Double> {
        val votes = mutableMapOf(0 to 0.0, 1 to 0.0)
        fun merge(src: Map<Int, Double>, weight: Double) {
            for ((k, v) in src) votes[k] = (votes[k] ?: 0.0) + v * weight
        }
        merge(axisPatternVotes(data), w[0])
        merge(axisFrequencyVotes(data), w[1])
        merge(axisStreakVotes(data), w[2])
        merge(axisWaveVotes(data), w[3])
        merge(axisMirrorVotes(data), w[4])
        merge(axisPositionVotes(data), w[5])
        val total = votes.values.sum()
        if (total == 0.0) return mapOf(0 to 0.5, 1 to 0.5)
        return votes.mapValues { it.value / total }
    }

    private fun axisPatternVotes(data: List<Int>): Map<Int, Double> {
        val votes = mutableMapOf(0 to 0.0, 1 to 0.0)
        if (data.size < 4) return mapOf(0 to 0.5, 1 to 0.5)
        val maxLen = minOf(10, data.size - 1)
        for (len in maxLen downTo 2) {
            val pattern = data.takeLast(len)
            val history = data.dropLast(len)
            for (i in 0..history.size - len) {
                if (history.subList(i, i + len) == pattern) {
                    val ap = i + len
                    if (ap < history.size) {
                        val nv = history[ap]
                        val rec = PatternMatcher.recencyFactor(history.size - ap, history.size)
                        votes[nv] = (votes[nv] ?: 0.0) + (len.toDouble() / 10.0) * rec
                    }
                }
            }
        }
        val total = votes.values.sum()
        if (total == 0.0) return mapOf(0 to 0.5, 1 to 0.5)
        return votes.mapValues { it.value / total }
    }

    private fun axisFrequencyVotes(data: List<Int>): Map<Int, Double> {
        val window = data.takeLast(50)
        if (window.isEmpty()) return mapOf(0 to 0.5, 1 to 0.5)
        val c0 = window.count { it == 0 }
        val c1 = window.count { it == 1 }
        val exp = window.size / 2.0
        val d0 = maxOf(0.0, exp - c0)
        val d1 = maxOf(0.0, exp - c1)
        val sum = d0 + d1
        if (sum == 0.0) return mapOf(0 to 0.5, 1 to 0.5)
        return mapOf(0 to d0 / sum, 1 to d1 / sum)
    }

    private fun axisStreakVotes(data: List<Int>): Map<Int, Double> {
        if (data.size < 3) return mapOf(0 to 0.5, 1 to 0.5)
        val lastVal = data.last()
        var streak = 1
        for (i in data.size - 2 downTo 0) {
            if (data[i] == lastVal) streak++ else break
        }
        val votes = mutableMapOf(0 to 0.0, 1 to 0.0)
        for (i in streak until data.size) {
            var j = i - 1
            var cnt = 0
            while (j >= 0 && data[j] == lastVal) {
                cnt++
                j--
            }
            if (cnt == streak) {
                val nv = data[i]
                val rec = PatternMatcher.recencyFactor(data.size - i, data.size)
                votes[nv] = (votes[nv] ?: 0.0) + rec
            }
        }
        val total = votes.values.sum()
        if (total == 0.0) {
            val opp = if (lastVal == 0) 1 else 0
            return mapOf(lastVal to 0.3, opp to 0.7)
        }
        return votes.mapValues { it.value / total }
    }

    private fun axisWaveVotes(data: List<Int>): Map<Int, Double> {
        if (data.size < 4) return mapOf(0 to 0.5, 1 to 0.5)
        val lv = data.last()
        val pv = data[data.size - 2]
        if (lv == pv) return mapOf(0 to 0.5, 1 to 0.5)
        var wc = 0
        for (i in 1 until data.size - 1) {
            if (data[i] != data[i - 1] && data[i] != data[i + 1]) wc++
        }
        val opp = if (lv == 0) 1 else 0
        val wr = wc.toDouble() / data.size
        return if (wr > 0.4) mapOf(opp to 0.65, lv to 0.35)
        else mapOf(0 to 0.5, 1 to 0.5)
    }

    private fun axisMirrorVotes(data: List<Int>): Map<Int, Double> {
        val votes = mutableMapOf(0 to 0.0, 1 to 0.0)
        if (data.size < 4) return mapOf(0 to 0.5, 1 to 0.5)
        val maxLen = minOf(10, data.size - 1)
        for (len in maxLen downTo 2) {
            val pattern = data.takeLast(len)
            val reversed = pattern.reversed()
            val history = data.dropLast(len)
            for (i in 0..history.size - len) {
                if (history.subList(i, i + len) == reversed) {
                    val ap = i + len
                    if (ap < history.size) {
                        val nv = history[ap]
                        val rec = PatternMatcher.recencyFactor(history.size - ap, history.size)
                        votes[nv] = (votes[nv] ?: 0.0) + (len.toDouble() / 10.0) * 0.5 * rec
                    }
                }
            }
        }
        val total = votes.values.sum()
        if (total == 0.0) return mapOf(0 to 0.5, 1 to 0.5)
        return votes.mapValues { it.value / total }
    }

    private fun axisPositionVotes(data: List<Int>): Map<Int, Double> {
        val votes = mutableMapOf(0 to 0.0, 1 to 0.0)
        if (data.size < 10) return mapOf(0 to 0.5, 1 to 0.5)
        for (period in 2..20) {
            if (data.size < period * 2) continue
            val posInPeriod = data.size % period
            var matchCount = 0
            var totalCount = 0
            var voteFor0 = 0
            var voteFor1 = 0
            var i = posInPeriod
            while (i < data.size - period) {
                if (i % period == posInPeriod % period) {
                    totalCount++
                    if (data[i] == data.last()) matchCount++
                    if (data[i] == 0) voteFor0++ else voteFor1++
                }
                i += period
            }
            if (totalCount > 3) {
                val consistency = matchCount.toDouble() / totalCount
                if (consistency > 0.6) {
                    val weight = consistency * 0.5
                    val dominant = if (voteFor0 > voteFor1) 0 else 1
                    votes[dominant] = (votes[dominant] ?: 0.0) + weight
                }
            }
        }
        val total = votes.values.sum()
        if (total == 0.0) return mapOf(0 to 0.5, 1 to 0.5)
        return votes.mapValues { it.value / total }
    }

    // ── Format ve Başarı Kontrolleri ─────────────────────────────────

    fun formatSidePrediction(result: SidePredictionResult): String {
        val sbFirst = if (result.smallBigPrediction == SmallBig.SMALL) "K" else "B"
        val oeFirst = if (result.oddEvenPrediction == OddEven.ODD) "T" else "C"
        val sbConf = result.smallBigConfidence
        val oeConf = result.oddEvenConfidence
        return when {
            sbConf >= 0.60 && oeConf >= 0.60 -> if (sbConf >= oeConf) "$sbFirst•$oeFirst" else "$oeFirst•$sbFirst"
            sbConf >= 0.60 -> sbFirst
            oeConf >= 0.60 -> oeFirst
            else -> if (sbConf >= oeConf) "$sbFirst•$oeFirst" else "$oeFirst•$sbFirst"
        }
    }

    private fun tokenMatches(token: String, actual: Int): Boolean {
        val actualOE = actual.toOddEven()
        val actualSB = actual.toSmallBig()
        return when (token.trim()) {
            "T"  -> actualOE == OddEven.ODD
            "C"  -> actualOE == OddEven.EVEN
            "K"  -> actualSB == SmallBig.SMALL
            "B"  -> actualSB == SmallBig.BIG
            else -> false
        }
    }

    /**
     * Tekli gösterimde: o tek eksen doğruysa → doğru
     * Çiftli gösterimde: en az biri doğruysa → doğru
     */
    fun checkSideCorrect(prediction: String, actual: Int): Boolean {
        val tokens = prediction.split("•").map { it.trim() }.filter { it.isNotEmpty() }
        return when (tokens.size) {
            0    -> false
            1    -> tokenMatches(tokens[0], actual)
            else -> tokens.any { tokenMatches(it, actual) }
        }
    }

    /**
     * Sadece çiftli gösterimde iki eksen de doğruysa → double correct (zirve)
     */
    fun checkSideDoubleCorrect(prediction: String, actual: Int): Boolean {
        val tokens = prediction.split("•").map { it.trim() }.filter { it.isNotEmpty() }
        if (tokens.size < 2) return false
        return tokens.all { tokenMatches(it, actual) }
    }
}