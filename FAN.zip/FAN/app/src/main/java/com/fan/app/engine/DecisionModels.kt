package com.fan.app.engine

/**
 * Karar kaynağı:
 *
 * NATIVE:
 *   Modelin tamamen kendi iç mantığı
 *
 * PATTERN:
 *   Birebir kalıp eşleşmesi desteği baskın
 *
 * REGIME:
 *   Rejim / davranış benzerliği baskın
 *
 * META:
 *   Diğer modellerin geçmiş başarısından türeyen destek baskın
 *
 * BLENDED:
 *   Native + Pattern + Regime + Meta birlikte harmanlandı
 *
 * BIAS_SHIFTED:
 *   Harmanlanan sonuçta primary bias'a düştüğü için secondary öne alındı
 */
enum class DecisionSource {
    NATIVE,
    PATTERN,
    REGIME,
    META,
    BLENDED,
    BIAS_SHIFTED
}

/**
 * Ödül katmanları.
 *
 * NATIVE streak:
 * - 2 doğru → 1.5x
 * - 3 doğru → 2.0x
 * - 4 doğru → 3.0x
 * - 5+ doğru → 4.0x
 *
 * SUPPORT_CAPPED:
 * - Kalıp / rejim desteği ile gelen ve paylaşılmış başarı varsa
 *   maksimum destek çarpanı burada sınırlanır.
 */
enum class RewardTier(val multiplier: Double) {
    NONE(1.0),
    SUPPORT_CAPPED(2.0),
    NATIVE_STREAK_2(1.5),
    NATIVE_STREAK_3(2.0),
    NATIVE_STREAK_4(3.0),
    NATIVE_STREAK_5_PLUS(4.0)
}

/**
 * Her aday sayı için skor vektörü.
 * 1..4 adaylarına tam karşılaştırmalı puan vermek için kullanılır.
 */
data class ScoreVector(
    val score1: Double = 0.0,
    val score2: Double = 0.0,
    val score3: Double = 0.0,
    val score4: Double = 0.0
) {
    fun toMap(): Map<Int, Double> = mapOf(
        1 to score1,
        2 to score2,
        3 to score3,
        4 to score4
    )

    companion object {
        fun fromMap(map: Map<Int, Double>): ScoreVector {
            return ScoreVector(
                score1 = map[1] ?: 0.0,
                score2 = map[2] ?: 0.0,
                score3 = map[3] ?: 0.0,
                score4 = map[4] ?: 0.0
            )
        }
    }
}

/**
 * Kalıp / rejim / meta destek özetleri.
 * Bu sınıf final override için değil, destek puanlaması için kullanılır.
 */
data class SupportMatchInfo(
    val matchedPatternLength: Int = 0,
    val matchedPatternCount: Int = 0,
    val matchedPatternRegime: String = "",
    val regimeSimilarityScore: Double = 0.0,
    val regimeTransitionPrediction: String = "",
    val exactPatternVotes: Map<Int, Double> = emptyMap(),
    val regimeBehaviorVotes: Map<Int, Double> = emptyMap(),
    val metaHistoryVotes: Map<Int, Double> = emptyMap()
)

/**
 * Bir modelin tek turdaki tam karar izi.
 * CSV trace kolonları büyük ölçüde buradan üretilebilir.
 */
data class ModelDecisionTrace(
    val methodIndex: Int,
    val methodName: String,

    val nativePrediction1: Int = 0,
    val nativePrediction2: Int = 0,
    val nativeConfidence: Double = 0.0,

    val patternPrediction1: Int = 0,
    val patternPrediction2: Int = 0,
    val patternConfidence: Double = 0.0,
    val patternRefLength: Int = 0,
    val patternRefRegime: String = "",
    val patternRefCount: Int = 0,

    val regimePrediction1: Int = 0,
    val regimePrediction2: Int = 0,
    val regimeConfidence: Double = 0.0,

    val metaPrediction1: Int = 0,
    val metaPrediction2: Int = 0,
    val metaConfidence: Double = 0.0,

    val blendedPrediction1: Int = 0,
    val blendedPrediction2: Int = 0,
    val blendedConfidence: Double = 0.0,

    val finalPrediction1: Int = 0,
    val finalPrediction2: Int = 0,
    val finalConfidence: Double = 0.0,

    val decisionSource: DecisionSource = DecisionSource.NATIVE,
    val biasShifted: Boolean = false,

    val nativeCorrect: Boolean = false,
    val patternCorrect: Boolean = false,
    val regimeCorrect: Boolean = false,
    val metaCorrect: Boolean = false,

    val nativeSuccessStreak: Int = 0,
    val supportSuccessStreak: Int = 0,

    /**
     * Aynı pattern/rejim destekli tahmin aynı anda en az bir model daha üretmişse true.
     * Bu durumda ödül SUPPORT_CAPPED altında tutulabilir.
     */
    val supportSharedSuccess: Boolean = false,

    val rewardTier: RewardTier = RewardTier.NONE
)