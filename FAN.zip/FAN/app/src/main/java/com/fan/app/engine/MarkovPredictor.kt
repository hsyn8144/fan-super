package com.fan.app.engine

class MarkovPredictor {

    fun compute(data: List<Int>): Map<Int, Double> {
        if (data.size < 3) return equal()
        val last = data.last()
        val prev = data.getOrNull(data.size - 2)
        val t1 = buildT1(data)
        val p1 = probs1(t1, last)
        if (prev != null && data.size >= 4) {
            val t2 = buildT2(data)
            val p2 = probs2(t2, prev, last)
            if (p2 != null) {
                val merged = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)
                for (k in 1..4) merged[k] = (p1[k] ?: 0.25) * 0.4 + (p2[k] ?: 0.25) * 0.6
                return normalize(merged)
            }
        }
        return p1
    }

    private fun buildT1(data: List<Int>): Map<Pair<Int,Int>, Double> {
        val t = mutableMapOf<Pair<Int,Int>, Double>()
        val decay = 0.97
        for (i in 0 until data.size - 1) {
            val key = Pair(data[i], data[i+1])
            val w = Math.pow(decay, (data.size - 2 - i).toDouble())
            t[key] = (t[key] ?: 0.0) + w
        }
        return t
    }

    private fun buildT2(data: List<Int>): Map<Triple<Int,Int,Int>, Double> {
        val t = mutableMapOf<Triple<Int,Int,Int>, Double>()
        val decay = 0.97
        for (i in 0 until data.size - 2) {
            val key = Triple(data[i], data[i+1], data[i+2])
            val w = Math.pow(decay, (data.size - 3 - i).toDouble())
            t[key] = (t[key] ?: 0.0) + w
        }
        return t
    }

    private fun probs1(t: Map<Pair<Int,Int>, Double>, from: Int): Map<Int, Double> {
        val p = mutableMapOf(1 to 0.5, 2 to 0.5, 3 to 0.5, 4 to 0.5)
        for (k in 1..4) p[k] = (p[k] ?: 0.5) + (t[Pair(from, k)] ?: 0.0)
        return normalize(p)
    }

    private fun probs2(t: Map<Triple<Int,Int,Int>, Double>, prev: Int, last: Int): Map<Int, Double>? {
        val p = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)
        var total = 0.0
        for (k in 1..4) { val w = t[Triple(prev, last, k)] ?: 0.0; p[k] = w; total += w }
        if (total < 0.1) return null
        for (k in 1..4) p[k] = (p[k] ?: 0.0) + 0.25
        return normalize(p)
    }

    private fun normalize(m: Map<Int, Double>): Map<Int, Double> {
        val total = m.values.sum()
        if (total == 0.0) return equal()
        return m.mapValues { it.value / total }
    }

    private fun equal() = mapOf(1 to 0.25, 2 to 0.25, 3 to 0.25, 4 to 0.25)
}