package com.fan.app.engine

import com.fan.app.data.DataEntry

/**
 * Bağlamsal Hafıza Motoru
 *
 * Kalıp eşleşmelerini, rejim geçişlerini ve model başarılarını
 * indeksleyip hızlı sorgulanabilir özet tablolar tutar.
 *
 * Uygulama açılınca CSV'den oluşturulur, her yeni veride artımlı güncellenir.
 */
object ContextualMemory {

    // ── Kalıp sonrası değer istatistikleri ───────────────────────────
    // Anahtar: kalıp uzunluğu + kalıp hash → sonraki değer dağılımı
    data class PatternOutcome(
        val patternLength: Int,
        val patternHash: String,
        val patternRegime: String,
        val nextValueCounts: MutableMap<Int, Int> = mutableMapOf(1 to 0, 2 to 0, 3 to 0, 4 to 0),
        val totalOccurrences: Int = 0
    )

    // ── Rejim geçiş istatistikleri ───────────────────────────────────
    data class RegimeTransitionStat(
        val fromRegime: String,
        val toRegime: String,
        var count: Int = 0,
        val nextValueCounts: MutableMap<Int, Int> = mutableMapOf(1 to 0, 2 to 0, 3 to 0, 4 to 0)
    )

    // ── Model rejim başarı profili ───────────────────────────────────
    data class ModelRegimeProfile(
        val methodIndex: Int,
        val regime: String,
        var totalPredictions: Int = 0,
        var correctPredictions: Int = 0
    ) {
        val accuracy: Double get() = if (totalPredictions >= 3) correctPredictions.toDouble() / totalPredictions else 0.0
    }

    // ── Hafıza Tabloları ─────────────────────────────────────────────
    private val patternOutcomes = mutableMapOf<String, PatternOutcome>()
    private val regimeTransitions = mutableMapOf<String, RegimeTransitionStat>()
    private val modelRegimeProfiles = mutableMapOf<String, ModelRegimeProfile>()
    private val regimeHistory = mutableListOf<String>()

    // ── Kaos Skoru ───────────────────────────────────────────────────
    private var currentChaosScore: Double = 0.0
    private val chaosDecayRate = 0.85  // Her doğru tahminde kaos azalır

    fun getChaosScore(): Double = currentChaosScore

    // ── Başlangıç: CSV'den Yükleme ──────────────────────────────────
    fun initializeFromEntries(entries: List<DataEntry>, allData: List<Int>) {
        clear()

        // Kalıp istatistiklerini oluştur
        for (patternLen in 3..8) {
            if (allData.size < patternLen + 1) continue
            for (i in 0..allData.size - patternLen - 1) {
                val pattern = allData.subList(i, i + patternLen)
                val nextVal = allData[i + patternLen]
                val hash = patternToHash(pattern)
                val regime = if (i < entries.size) extractRegimeGroup(entries.getOrNull(i + patternLen - 1)?.currentRegime ?: "") else "KAOS"

                val key = "${patternLen}_$hash"
                val outcome = patternOutcomes.getOrPut(key) {
                    PatternOutcome(patternLen, hash, regime)
                }
                outcome.nextValueCounts[nextVal] = (outcome.nextValueCounts[nextVal] ?: 0) + 1
            }
        }

        // Rejim geçiş istatistikleri
        for (i in 1 until entries.size) {
            val fromRegime = extractRegimeGroup(entries[i - 1].currentRegime)
            val toRegime = extractRegimeGroup(entries[i].currentRegime)
            regimeHistory.add(toRegime)

            if (i < entries.size - 1) {
                val key = "${fromRegime}_${toRegime}"
                val stat = regimeTransitions.getOrPut(key) {
                    RegimeTransitionStat(fromRegime, toRegime)
                }
                stat.count++
                val nextVal = entries[i + 1].value
                if (nextVal in 1..4) {
                    stat.nextValueCounts[nextVal] = (stat.nextValueCounts[nextVal] ?: 0) + 1
                }
            }
        }

        // Model rejim başarı profilleri
        for (entry in entries.drop(DataEntry.INTERNAL_THRESHOLD)) {
            val regime = extractRegimeGroup(entry.currentRegime)
            for (methodIdx in 0 until DataEntry.METHOD_COUNT) {
                val correct = getMethodCorrectFromEntry(entry, methodIdx)
                val active = getMethodActiveFromEntry(entry, methodIdx)
                if (!active) continue

                val key = "${methodIdx}_$regime"
                val profile = modelRegimeProfiles.getOrPut(key) {
                    ModelRegimeProfile(methodIdx, regime)
                }
                profile.totalPredictions++
                if (correct) profile.correctPredictions++
            }
        }
    }

    // ── Artımlı Güncelleme ───────────────────────────────────────────
    fun updateWithNewEntry(
        entry: DataEntry,
        allData: List<Int>,
        previousRegime: String,
        patternBroken: Boolean,
        brokenPatternLength: Int,
        ensembleCorrect: Boolean
    ) {
        val currentRegime = extractRegimeGroup(entry.currentRegime)

        // Rejim geçişi güncelle
        if (previousRegime.isNotBlank()) {
            val fromGroup = extractRegimeGroup(previousRegime)
            val key = "${fromGroup}_$currentRegime"
            val stat = regimeTransitions.getOrPut(key) {
                RegimeTransitionStat(fromGroup, currentRegime)
            }
            stat.count++
            if (entry.value in 1..4) {
                stat.nextValueCounts[entry.value] = (stat.nextValueCounts[entry.value] ?: 0) + 1
            }
        }
        regimeHistory.add(currentRegime)

        // Kalıp eşleşmeleri güncelle (son veriye göre)
        for (patternLen in 3..minOf(8, allData.size - 1)) {
            val startIdx = allData.size - patternLen - 1
            if (startIdx < 0) continue
            val pattern = allData.subList(startIdx, startIdx + patternLen)
            val nextVal = allData[startIdx + patternLen]
            val hash = patternToHash(pattern)
            val key = "${patternLen}_$hash"
            val outcome = patternOutcomes.getOrPut(key) {
                PatternOutcome(patternLen, hash, currentRegime)
            }
            outcome.nextValueCounts[nextVal] = (outcome.nextValueCounts[nextVal] ?: 0) + 1
        }

        // Kaos skoru güncelle
        if (patternBroken && brokenPatternLength > 0) {
            currentChaosScore += brokenPatternLength.toDouble()
        }
        if (ensembleCorrect) {
            currentChaosScore *= chaosDecayRate
        }
        currentChaosScore = currentChaosScore.coerceIn(0.0, 50.0)

        // Model rejim profilleri güncelle
        for (methodIdx in 0 until DataEntry.METHOD_COUNT) {
            val correct = getMethodCorrectFromEntry(entry, methodIdx)
            val active = getMethodActiveFromEntry(entry, methodIdx)
            if (!active) continue

            val key = "${methodIdx}_$currentRegime"
            val profile = modelRegimeProfiles.getOrPut(key) {
                ModelRegimeProfile(methodIdx, currentRegime)
            }
            profile.totalPredictions++
            if (correct) profile.correctPredictions++
        }
    }

    // ── Sorgulama Fonksiyonları ───────────────────────────────────────

    /**
     * Verilen kalıp için en olası sonraki değeri döndürür
     * 8'den 3'e doğru iner, en uzun eşleşmeyi tercih eder
     */
    fun queryPatternPrediction(data: List<Int>): PatternQueryResult {
        for (patternLen in minOf(8, data.size) downTo 3) {
            val pattern = data.takeLast(patternLen)
            val hash = patternToHash(pattern)
            val key = "${patternLen}_$hash"
            val outcome = patternOutcomes[key]

            if (outcome != null) {
                val total = outcome.nextValueCounts.values.sum()
                if (total >= 2) {
                    val sorted = outcome.nextValueCounts.entries.sortedByDescending { it.value }
                    val pred1 = sorted[0].key
                    val pred2 = sorted.getOrNull(1)?.key ?: pred1
                    val conf = sorted[0].value.toDouble() / total

                    return PatternQueryResult(
                        found = true,
                        patternLength = patternLen,
                        patternRegime = outcome.patternRegime,
                        matchCount = total,
                        prediction1 = pred1,
                        prediction2 = pred2,
                        confidence = conf
                    )
                }
            }
        }

        return PatternQueryResult(found = false)
    }

    /**
     * Verilen rejimde hangi modelin en başarılı olduğunu döndürür
     */
    fun queryBestModelsForRegime(regime: String): List<Pair<Int, Double>> {
        val regimeGroup = extractRegimeGroup(regime)
        return (0 until DataEntry.METHOD_COUNT).mapNotNull { methodIdx ->
            val key = "${methodIdx}_$regimeGroup"
            val profile = modelRegimeProfiles[key]
            if (profile != null && profile.totalPredictions >= 5) {
                Pair(methodIdx, profile.accuracy)
            } else null
        }.sortedByDescending { it.second }
    }

    /**
     * Rejim geçiş tahmini: mevcut rejimden sonra en olası rejim ne?
     */
    fun predictNextRegime(currentRegime: String): String {
        val currentGroup = extractRegimeGroup(currentRegime)
        val candidates = regimeTransitions.filter { it.value.fromRegime == currentGroup }
        if (candidates.isEmpty()) return "KAOS"

        return candidates.maxByOrNull { it.value.count }?.value?.toRegime ?: "KAOS"
    }

    /**
     * Rejim geçiş sonrası en olası değer tahmini
     */
    fun queryRegimeTransitionPrediction(fromRegime: String, toRegime: String): Map<Int, Double> {
        val fromGroup = extractRegimeGroup(fromRegime)
        val toGroup = extractRegimeGroup(toRegime)
        val key = "${fromGroup}_$toGroup"
        val stat = regimeTransitions[key]

        if (stat == null || stat.count < 3) return mapOf(1 to 0.25, 2 to 0.25, 3 to 0.25, 4 to 0.25)

        val total = stat.nextValueCounts.values.sum().toDouble()
        if (total == 0.0) return mapOf(1 to 0.25, 2 to 0.25, 3 to 0.25, 4 to 0.25)

        return stat.nextValueCounts.mapValues { it.value / total }
    }

    // ── Yardımcılar ──────────────────────────────────────────────────

    private fun patternToHash(pattern: List<Int>): String = pattern.joinToString("")

    private fun extractRegimeGroup(regime: String): String {
        return when {
            regime.contains("TEKRAR") || regime.contains("BLOK") || regime.contains("DALGA_TEK") -> "TEKRAR"
            regime.contains("ARTIS") || regime.contains("AZALIS") || regime.contains("TEPE") ||
                    regime.contains("VADI") || regime.contains("DONGU") -> "YON"
            regime.contains("SINIR") || regime.contains("KOSEGEN") || regime.contains("ZIGZAK") -> "SALINIMM"
            else -> "KAOS"
        }
    }

    private fun getMethodCorrectFromEntry(e: DataEntry, i: Int): Boolean = when (i) {
        0  -> e.method1Correct;  1  -> e.method2Correct;  2  -> e.method3Correct
        3  -> e.method4Correct;  4  -> e.method5Correct;  5  -> e.method6Correct
        6  -> e.method7Correct;  7  -> e.method8Correct;  8  -> e.method9Correct
        9  -> e.method10Correct; 10 -> e.method11Correct; 11 -> e.method12Correct
        12 -> e.method13Correct; else -> false
    }

    private fun getMethodActiveFromEntry(e: DataEntry, i: Int): Boolean = when (i) {
        0  -> e.method1Active;  1  -> e.method2Active;  2  -> e.method3Active
        3  -> e.method4Active;  4  -> e.method5Active;  5  -> e.method6Active
        6  -> e.method7Active;  7  -> e.method8Active;  8  -> e.method9Active
        9  -> e.method10Active; 10 -> e.method11Active; 11 -> e.method12Active
        12 -> e.method13Active; else -> true
    }

    fun clear() {
        patternOutcomes.clear()
        regimeTransitions.clear()
        modelRegimeProfiles.clear()
        regimeHistory.clear()
        currentChaosScore = 0.0
    }

    // ── Sonuç Sınıfları ──────────────────────────────────────────────
    data class PatternQueryResult(
        val found: Boolean = false,
        val patternLength: Int = 0,
        val patternRegime: String = "",
        val matchCount: Int = 0,
        val prediction1: Int = 0,
        val prediction2: Int = 0,
        val confidence: Double = 0.0
    )
}