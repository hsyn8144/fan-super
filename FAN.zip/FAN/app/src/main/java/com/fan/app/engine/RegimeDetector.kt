@file:Suppress("SpellCheckingInspection")
package com.fan.app.engine

object RegimeDetector {

    // ── Backward compat ──────────────────────────────────────────────
    enum class RegimeType { REGULAR, CHAOS, WAVE, REPEAT }
    data class PatternInfo(val type: String, val length: Int, val strength: Double, val description: String)

    // ── 25 Mikro Rejim ───────────────────────────────────────────────
    enum class MicroRegimeType(val group: String) {
        TEKRAR("TEKRAR"), BLOK_DUZ("TEKRAR"), BLOK_TERS("TEKRAR"),
        DALGA_TEK_SIM_1("TEKRAR"), DALGA_TEK_SIM_2("TEKRAR"), DALGA_TEK_SIM_3("TEKRAR"),
        DALGA_TEK_ASIM_1L("TEKRAR"), DALGA_TEK_ASIM_1R("TEKRAR"),
        DALGA_TEK_ASIM_2L("TEKRAR"), DALGA_TEK_ASIM_2R("TEKRAR"),
        DALGA_TEK_ASIM_3L("TEKRAR"), DALGA_TEK_ASIM_3R("TEKRAR"),
        DALGA_TEK_ASIM_MIX("TEKRAR"),
        ARTIS("YON"), AZALIS("YON"), TEPE("YON"), VADI("YON"), DONGU("YON"), DONGU_TERS("YON"),
        SINIR_ZIT("SALINIMM"), SINIR_ORT("SALINIMM"),
        KOSEGEN_13("SALINIMM"), KOSEGEN_24("SALINIMM"), ZIGZAK_KOM("SALINIMM"),
        KAOS("KAOS");

        fun toOldType(): RegimeType = when (group) {
            "TEKRAR"   -> RegimeType.REPEAT
            "YON"      -> RegimeType.WAVE
            "SALINIMM" -> RegimeType.WAVE
            else       -> RegimeType.CHAOS
        }
    }

    data class MicroRegime(
        val type: MicroRegimeType,
        val startIndex: Int,
        val length: Int,
        val score: Double,
        val values: List<Int>
    )

    data class RegimeSequence(
        val regimes: List<MicroRegime>,
        val totalLength: Int
    ) {
        fun toTypeList(): List<MicroRegimeType> = regimes.map { it.type }
        fun reversed(): List<MicroRegimeType> = regimes.reversed().map { it.type }
        fun mirrored(): List<MicroRegimeType> = regimes.map { mirror(it.type) }
        fun toDisplayString(): String = regimes.joinToString(">") { it.type.name }

        companion object {
            fun mirror(t: MicroRegimeType): MicroRegimeType = when (t) {
                MicroRegimeType.ARTIS             -> MicroRegimeType.AZALIS
                MicroRegimeType.AZALIS            -> MicroRegimeType.ARTIS
                MicroRegimeType.TEPE              -> MicroRegimeType.VADI
                MicroRegimeType.VADI              -> MicroRegimeType.TEPE
                MicroRegimeType.DONGU             -> MicroRegimeType.DONGU_TERS
                MicroRegimeType.DONGU_TERS        -> MicroRegimeType.DONGU
                MicroRegimeType.BLOK_DUZ          -> MicroRegimeType.BLOK_TERS
                MicroRegimeType.BLOK_TERS         -> MicroRegimeType.BLOK_DUZ
                MicroRegimeType.DALGA_TEK_ASIM_1L -> MicroRegimeType.DALGA_TEK_ASIM_1R
                MicroRegimeType.DALGA_TEK_ASIM_1R -> MicroRegimeType.DALGA_TEK_ASIM_1L
                MicroRegimeType.DALGA_TEK_ASIM_2L -> MicroRegimeType.DALGA_TEK_ASIM_2R
                MicroRegimeType.DALGA_TEK_ASIM_2R -> MicroRegimeType.DALGA_TEK_ASIM_2L
                MicroRegimeType.DALGA_TEK_ASIM_3L -> MicroRegimeType.DALGA_TEK_ASIM_3R
                MicroRegimeType.DALGA_TEK_ASIM_3R -> MicroRegimeType.DALGA_TEK_ASIM_3L
                else -> t
            }
        }
    }

    data class RegimeAnalysisResult(
        val currentRegimeType: MicroRegimeType,
        val regimeSequence: RegimeSequence,
        val votes: Map<Int, Double>,
        val confidence: Double,
        val subType: String = ""
    ) {
        val currentRegime: RegimeType get() = currentRegimeType.toOldType()
    }

    // ── Ana Analiz ───────────────────────────────────────────────────
    fun analyze(data: List<Int>): RegimeAnalysisResult {
        if (data.size < 3) return defaultResult()
        val minRegimes = when {
            data.size >= 500 -> 4
            data.size >= 250 -> 3
            else -> 2
        }
        val window = data.takeLast(20)
        val sequence = detectRegimeSequence(window, minRegimes)
        val votes = if (data.size >= 20) computeVotesFromSequence(data, sequence)
        else mapOf(1 to 0.25, 2 to 0.25, 3 to 0.25, 4 to 0.25)
        val filtered = eliminateLowVotes(votes)
        val currentType = sequence.regimes.lastOrNull()?.type ?: MicroRegimeType.KAOS
        return RegimeAnalysisResult(
            currentRegimeType = currentType,
            regimeSequence = sequence,
            votes = filtered,
            confidence = filtered.values.maxOrNull() ?: 0.25,
            subType = currentType.group
        )
    }

    // ── Rejim Dizisi Tespiti ─────────────────────────────────────────
    fun detectRegimeSequence(window: List<Int>, minRegimes: Int = 2): RegimeSequence {
        val regimes = mutableListOf<MicroRegime>()
        var pos = window.size
        var safetyCounter = 0
        while (pos >= 3 && regimes.size < 4 && safetyCounter < 15) {
            safetyCounter++
            var found = false
            for (len in minOf(8, pos) downTo 3) {
                val start = pos - len
                val sub = window.subList(start, pos)
                val matchResult = bestMatch(sub)
                val type = matchResult.first
                val score = matchResult.second
                if (score >= 0.6) {
                    regimes.add(0, MicroRegime(type, start, len, score, sub.toList()))
                    pos -= len
                    found = true
                    break
                }
            }
            if (!found) pos--
            if (regimes.size >= minOf(minRegimes + 2, 4)) break
        }
        return RegimeSequence(regimes, window.size - pos)
    }

    // ── En İyi Eşleşme ───────────────────────────────────────────────
    private fun bestMatch(w: List<Int>): Pair<MicroRegimeType, Double> {
        val scores = mapOf(
            MicroRegimeType.TEKRAR            to scoreTekrar(w),
            MicroRegimeType.BLOK_DUZ          to scoreBlokDuz(w),
            MicroRegimeType.BLOK_TERS         to scoreBlokTers(w),
            MicroRegimeType.DALGA_TEK_SIM_1   to scoreDALGASim(w, 1),
            MicroRegimeType.DALGA_TEK_SIM_2   to scoreDALGASim(w, 2),
            MicroRegimeType.DALGA_TEK_SIM_3   to scoreDALGASim(w, 3),
            MicroRegimeType.DALGA_TEK_ASIM_1L to scoreDALGAAsimL(w, 1),
            MicroRegimeType.DALGA_TEK_ASIM_1R to scoreDALGAAsimR(w, 1),
            MicroRegimeType.DALGA_TEK_ASIM_2L to scoreDALGAAsimL(w, 2),
            MicroRegimeType.DALGA_TEK_ASIM_2R to scoreDALGAAsimR(w, 2),
            MicroRegimeType.DALGA_TEK_ASIM_3L to scoreDALGAAsimL(w, 3),
            MicroRegimeType.DALGA_TEK_ASIM_3R to scoreDALGAAsimR(w, 3),
            MicroRegimeType.DALGA_TEK_ASIM_MIX to scoreDALGAAsimMix(w),
            MicroRegimeType.ARTIS             to scoreArtis(w),
            MicroRegimeType.AZALIS            to scoreAzalis(w),
            MicroRegimeType.TEPE              to scoreTepe(w),
            MicroRegimeType.VADI              to scoreVadi(w),
            MicroRegimeType.DONGU             to scoreDongu(w),
            MicroRegimeType.DONGU_TERS        to scoreDonguTers(w),
            MicroRegimeType.SINIR_ZIT         to scoreSinir(w, 1, 4),
            MicroRegimeType.SINIR_ORT         to scoreSinir(w, 2, 3),
            MicroRegimeType.KOSEGEN_13        to scoreSinir(w, 1, 3),
            MicroRegimeType.KOSEGEN_24        to scoreSinir(w, 2, 4),
            MicroRegimeType.ZIGZAK_KOM        to scoreZigzak(w)
        )
        val best = scores.maxByOrNull { it.value }
        return if (best != null && best.value >= 0.6) Pair(best.key, best.value)
        else Pair(MicroRegimeType.KAOS, 0.3)
    }

    // ── Tarihsel Eşleştirme ──────────────────────────────────────────
    private fun computeVotesFromSequence(data: List<Int>, seq: RegimeSequence): Map<Int, Double> {
        if (seq.regimes.isEmpty()) return mapOf(1 to 0.25, 2 to 0.25, 3 to 0.25, 4 to 0.25)
        val votes = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)
        var totalWeight = 0.0
        val cur = seq.toTypeList()
        val rev = seq.reversed()
        val mir = seq.mirrored()
        val seqLen = seq.totalLength.coerceAtLeast(3)
        val searchEnd = data.size - seqLen
        if (searchEnd < 10) return getDefaultVotes(seq, data)

        for (i in 0 until searchEnd step 2) {
            val hw = data.subList(i, minOf(i + 20, searchEnd))
            if (hw.size < 6) continue
            val hs = detectRegimeSequence(hw, 1)
            val ht = hs.toTypeList()
            if (ht.isEmpty()) continue
            val matchScore = bestSeqMatch(cur, ht, rev, mir)
            if (matchScore < 0.3) continue
            val afterIdx = i + hs.totalLength
            if (afterIdx < data.size) {
                val nv = data[afterIdx]
                if (nv in 1..4) {
                    val rec = PatternMatcher.recencyFactor(data.size - afterIdx, data.size)
                    val w = matchScore * rec
                    votes[nv] = (votes[nv] ?: 0.0) + w
                    totalWeight += w
                }
            }
        }
        if (totalWeight < 0.1) return getDefaultVotes(seq, data)
        return votes.mapValues { it.value / totalWeight }
    }

    private fun bestSeqMatch(
        cur: List<MicroRegimeType>, hist: List<MicroRegimeType>,
        rev: List<MicroRegimeType>, mir: List<MicroRegimeType>
    ): Double {
        val exact = seqSim(cur, hist)
        if (exact >= 0.85) return 1.0
        return maxOf(exact, seqSim(rev, hist) * 0.7, seqSim(mir, hist) * 0.6, groupSim(cur, hist) * 0.5)
    }

    private fun seqSim(a: List<MicroRegimeType>, b: List<MicroRegimeType>): Double {
        if (a.isEmpty() || b.isEmpty()) return 0.0
        val min = minOf(a.size, b.size)
        var score = 0.0
        for (i in 0 until min) {
            if (a[i] == b[i]) score += 2.0
            else if (a[i].group == b[i].group) score += 1.0
        }
        return score / (maxOf(a.size, b.size) * 2.0)
    }

    private fun groupSim(a: List<MicroRegimeType>, b: List<MicroRegimeType>): Double {
        if (a.isEmpty() || b.isEmpty()) return 0.0
        val min = minOf(a.size, b.size)
        val matches = (0 until min).count { a[it].group == b[it].group }
        return matches.toDouble() / maxOf(a.size, b.size)
    }

    private fun getDefaultVotes(seq: RegimeSequence, data: List<Int>): Map<Int, Double> {
        val t = seq.regimes.lastOrNull()?.type
            ?: return mapOf(1 to 0.25, 2 to 0.25, 3 to 0.25, 4 to 0.25)
        val lv = data.lastOrNull()
            ?: return mapOf(1 to 0.25, 2 to 0.25, 3 to 0.25, 4 to 0.25)

        return when (t) {
            MicroRegimeType.TEKRAR -> {
                val streakResult = getCurrentStreak(data)
                val v = streakResult.first
                val s = streakResult.second
                if (s >= 4) {
                    val others = (1..4).filter { it != v }
                    mutableMapOf(v to 0.15).apply { others.forEach { put(it, 0.2833) } }
                } else {
                    mutableMapOf(v to 0.55).apply {
                        (1..4).filter { it != v }.forEach { put(it, 0.15) }
                    }
                }
            }
            MicroRegimeType.ARTIS -> {
                val n = if (lv < 4) lv + 1 else 1
                val n2 = if (n < 4) n + 1 else 1
                mapOf(n to 0.50, n2 to 0.25, lv to 0.15, ((lv + 2) % 4 + 1) to 0.10)
            }
            MicroRegimeType.AZALIS -> {
                val n = if (lv > 1) lv - 1 else 4
                val n2 = if (n > 1) n - 1 else 4
                mapOf(n to 0.50, n2 to 0.25, lv to 0.15, ((lv + 2) % 4 + 1) to 0.10)
            }
            MicroRegimeType.TEPE -> {
                val n = if (lv > 1) lv - 1 else 4
                val n2 = (if (lv > 2) lv - 2 else lv + 2).coerceIn(1, 4)
                val other = (1..4).filter { it != n && it != n2 && it != lv }.firstOrNull() ?: 2
                mapOf(n to 0.45, n2 to 0.25, other to 0.20, lv to 0.10)
            }
            MicroRegimeType.VADI -> {
                val n = if (lv < 4) lv + 1 else 1
                val n2 = (if (lv < 3) lv + 2 else lv - 2).coerceIn(1, 4)
                val other = (1..4).filter { it != n && it != n2 && it != lv }.firstOrNull() ?: 3
                mapOf(n to 0.45, n2 to 0.25, other to 0.20, lv to 0.10)
            }
            MicroRegimeType.DONGU, MicroRegimeType.DONGU_TERS -> {
                val base = 0.25; val penalty = 0.08; val bonus = penalty / 3.0
                (1..4).associateWith { if (it == lv) base - penalty else base + bonus }
            }
            MicroRegimeType.SINIR_ZIT -> {
                val n = if (lv == 1) 4 else if (lv == 4) 1 else lv
                mapOf(n to 0.60, 1 to 0.13, 4 to 0.13, 2 to 0.07, 3 to 0.07)
            }
            MicroRegimeType.SINIR_ORT -> {
                val n = if (lv == 2) 3 else if (lv == 3) 2 else lv
                mapOf(n to 0.60, 2 to 0.13, 3 to 0.13, 1 to 0.07, 4 to 0.07)
            }
            MicroRegimeType.KOSEGEN_13 -> {
                val n = if (lv == 1) 3 else if (lv == 3) 1 else lv
                mapOf(n to 0.55, 1 to 0.15, 3 to 0.15, 2 to 0.075, 4 to 0.075)
            }
            MicroRegimeType.KOSEGEN_24 -> {
                val n = if (lv == 2) 4 else if (lv == 4) 2 else lv
                mapOf(n to 0.55, 2 to 0.15, 4 to 0.15, 1 to 0.075, 3 to 0.075)
            }
            MicroRegimeType.ZIGZAK_KOM -> {
                val n = if (data.size >= 2) {
                    val prev = data[data.size - 2]
                    if (lv > prev) lv - 1 else lv + 1
                } else lv + 1
                val nc = n.coerceIn(1, 4)
                val others = (1..4).filter { it != nc && it != lv }
                mapOf(
                    nc to 0.55,
                    lv to 0.10,
                    others.getOrElse(0) { 2 } to 0.20,
                    others.getOrElse(1) { 3 } to 0.15
                )
            }
            MicroRegimeType.BLOK_DUZ -> {
                val n = if (lv < 4) lv + 1 else lv
                val others = (1..4).filter { it != lv && it != n }
                mapOf(
                    lv to 0.45, n to 0.35,
                    others.getOrElse(0) { 1 } to 0.12,
                    others.getOrElse(1) { 2 } to 0.08
                )
            }
            MicroRegimeType.BLOK_TERS -> {
                val n = if (lv > 1) lv - 1 else lv
                val others = (1..4).filter { it != lv && it != n }
                mapOf(
                    lv to 0.45, n to 0.35,
                    others.getOrElse(0) { 3 } to 0.12,
                    others.getOrElse(1) { 4 } to 0.08
                )
            }
            else -> mapOf(1 to 0.25, 2 to 0.25, 3 to 0.25, 4 to 0.25)
        }
    }

    // ── Skor Fonksiyonları ───────────────────────────────────────────
    private fun scoreTekrar(w: List<Int>): Double {
        if (w.size < 2) return 0.0
        return if (w.all { it == w[0] }) 1.0 else 0.0
    }

    private fun scoreBlokDuz(w: List<Int>): Double {
        if (w.size < 4) return 0.0
        var violations = 0; var hasRepeat = false
        for (i in 1 until w.size) {
            if (w[i] < w[i - 1]) violations++
            if (w[i] == w[i - 1]) hasRepeat = true
        }
        if (!hasRepeat) return 0.0
        val s = 1.0 - violations.toDouble() / (w.size - 1)
        return if (s >= 0.6) s else 0.0
    }

    private fun scoreBlokTers(w: List<Int>): Double {
        if (w.size < 4) return 0.0
        var violations = 0; var hasRepeat = false
        for (i in 1 until w.size) {
            if (w[i] > w[i - 1]) violations++
            if (w[i] == w[i - 1]) hasRepeat = true
        }
        if (!hasRepeat) return 0.0
        val s = 1.0 - violations.toDouble() / (w.size - 1)
        return if (s >= 0.6) s else 0.0
    }

    private fun scoreDALGASim(w: List<Int>, diff: Int): Double {
        if (w.size < 3) return 0.0
        val first = w.first(); val last = w.last()
        if (first != last) return 0.0
        val mid = w.drop(1).dropLast(1)
        if (mid.isEmpty()) return 0.0
        val core = mid.groupBy { it }.maxByOrNull { it.value.size }?.key ?: return 0.0
        if (kotlin.math.abs(core - first) != diff) return 0.0
        val c = mid.count { it == core }
        return if (c == mid.size) 1.0 else c.toDouble() / mid.size
    }

    private fun scoreDALGAAsimL(w: List<Int>, diff: Int): Double {
        if (w.size < 3) return 0.0
        val first = w.first(); val rest = w.drop(1)
        val core = rest.groupBy { it }.maxByOrNull { it.value.size }?.key ?: return 0.0
        if (kotlin.math.abs(core - first) != diff) return 0.0
        if (rest.last() != core) return 0.0
        val c = rest.count { it == core }
        return if (c == rest.size) 1.0 else c.toDouble() / rest.size * 0.8
    }

    private fun scoreDALGAAsimR(w: List<Int>, diff: Int): Double {
        if (w.size < 3) return 0.0
        val last = w.last(); val rest = w.dropLast(1)
        val core = rest.groupBy { it }.maxByOrNull { it.value.size }?.key ?: return 0.0
        if (kotlin.math.abs(core - last) != diff) return 0.0
        if (rest.first() != core) return 0.0
        val c = rest.count { it == core }
        return if (c == rest.size) 1.0 else c.toDouble() / rest.size * 0.8
    }

    private fun scoreDALGAAsimMix(w: List<Int>): Double {
        if (w.size < 3) return 0.0
        val first = w.first(); val last = w.last()
        if (first == last) return 0.0
        val mid = w.drop(1).dropLast(1)
        if (mid.isEmpty()) return 0.0
        val core = mid.groupBy { it }.maxByOrNull { it.value.size }?.key ?: return 0.0
        val d1 = kotlin.math.abs(core - first)
        val d2 = kotlin.math.abs(core - last)
        if (d1 == 0 || d2 == 0 || d1 == d2) return 0.0
        val c = mid.count { it == core }
        return if (c >= mid.size * 0.7) 0.8 else 0.0
    }

    private fun scoreArtis(w: List<Int>): Double {
        if (w.size < 3) return 0.0
        val asc = (1 until w.size).count { w[it] > w[it - 1] }
        val r = asc.toDouble() / (w.size - 1)
        return if (r >= 0.65) r else 0.0
    }

    private fun scoreAzalis(w: List<Int>): Double {
        if (w.size < 3) return 0.0
        val desc = (1 until w.size).count { w[it] < w[it - 1] }
        val r = desc.toDouble() / (w.size - 1)
        return if (r >= 0.65) r else 0.0
    }

    private fun scoreTepe(w: List<Int>): Double {
        if (w.size < 3) return 0.0
        val pi = w.indices.maxByOrNull { w[it] } ?: return 0.0
        if (pi == 0 || pi == w.size - 1) return 0.0
        val la = (1..pi).count { w[it] >= w[it - 1] }.toDouble() / pi
        val rd = (pi + 1 until w.size).count { w[it] <= w[it - 1] }.toDouble() / (w.size - 1 - pi)
        val s = (la + rd) / 2.0
        return if (s >= 0.65) s else 0.0
    }

    private fun scoreVadi(w: List<Int>): Double {
        if (w.size < 3) return 0.0
        val vi = w.indices.minByOrNull { w[it] } ?: return 0.0
        if (vi == 0 || vi == w.size - 1) return 0.0
        val ld = (1..vi).count { w[it] <= w[it - 1] }.toDouble() / vi
        val ra = (vi + 1 until w.size).count { w[it] >= w[it - 1] }.toDouble() / (w.size - 1 - vi)
        val s = (ld + ra) / 2.0
        return if (s >= 0.65) s else 0.0
    }

    private fun scoreDongu(w: List<Int>): Double {
        if (w.size < 4) return 0.0
        for (p in 2..4) {
            if (w.size < p * 2) continue
            val m = (p until w.size).count { w[it] == w[it - p] || w[it] == (w[it - p] % 4) + 1 }
            val r = m.toDouble() / (w.size - p)
            if (r >= 0.7) return r
        }
        return 0.0
    }

    private fun scoreDonguTers(w: List<Int>): Double {
        if (w.size < 4) return 0.0
        for (p in 2..4) {
            if (w.size < p * 2) continue
            val m = (p until w.size).count {
                val exp = if (w[it - p] > 1) w[it - p] - 1 else 4
                w[it] == exp || w[it] == w[it - p]
            }
            val r = m.toDouble() / (w.size - p)
            if (r >= 0.7) return r
        }
        return 0.0
    }

    private fun scoreSinir(w: List<Int>, a: Int, b: Int): Double {
        if (w.size < 3) return 0.0
        val inGroup = w.count { it == a || it == b }
        if (inGroup < w.size * 0.8) return 0.0
        val alt = (1 until w.size).count {
            w[it] != w[it - 1] && (w[it] == a || w[it] == b) && (w[it - 1] == a || w[it - 1] == b)
        }
        val s = alt.toDouble() / (w.size - 1)
        return if (s >= 0.5) s else 0.0
    }

    private fun scoreZigzak(w: List<Int>): Double {
        if (w.size < 3) return 0.0
        val alt = (1 until w.size).count {
            w[it] != w[it - 1] && kotlin.math.abs(w[it] - w[it - 1]) == 1
        }
        val s = alt.toDouble() / (w.size - 1)
        return if (s >= 0.6) s else 0.0
    }

    // ── Backward Compat ──────────────────────────────────────────────
    fun detectCurrentRegime(data: List<Int>): RegimeType {
        if (data.size < 5) return RegimeType.CHAOS
        val seq = detectRegimeSequence(data.takeLast(20), 1)
        return seq.regimes.lastOrNull()?.type?.toOldType() ?: RegimeType.CHAOS
    }

    fun getCurrentStreak(data: List<Int>): Pair<Int, Int> {
        if (data.isEmpty()) return Pair(0, 0)
        val last = data.last()
        var streak = 1
        for (i in data.size - 2 downTo 0) {
            if (data[i] == last) streak++ else break
        }
        return Pair(last, streak)
    }

    fun getStreakBreakVotes(data: List<Int>): Map<Int, Double> {
        val streakResult = getCurrentStreak(data)
        val sv = streakResult.first
        val sl = streakResult.second
        val votes = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)
        for (i in sl until data.size) {
            var j = i - 1; var c = 0
            while (j >= 0 && data[j] == sv) { c++; j-- }
            if (c == sl && i < data.size) {
                val nv = data[i]
                if (nv in 1..4 && nv != sv) {
                    val rec = PatternMatcher.recencyFactor(data.size - i, data.size)
                    votes[nv] = (votes[nv] ?: 0.0) + rec
                }
            }
        }
        val total = votes.values.sum()
        if (total == 0.0) {
            (1..4).filter { it != sv }.forEach { votes[it] = 1.0 / 3.0 }
            return votes
        }
        return votes.mapValues { it.value / total }
    }

    fun computeBlockEntropy(data: List<Int>, windowSize: Int): Double {
        if (data.size < windowSize) return 1.0
        val w = data.takeLast(windowSize)
        val freq = mutableMapOf<Int, Int>()
        w.forEach { freq[it] = (freq[it] ?: 0) + 1 }
        var entropy = 0.0
        for (count in freq.values) {
            val p = count.toDouble() / windowSize
            entropy -= p * kotlin.math.ln(p) / kotlin.math.ln(4.0)
        }
        return entropy
    }

    fun detectPattern(data: List<Int>): PatternInfo {
        if (data.size < 6) return PatternInfo("NONE", 0, 0.0, "Yetersiz veri")
        val patterns = PatternMatcher.findPatterns(data)
        if (patterns.isEmpty()) return PatternInfo("NONE", 0, 0.0, "Kalip bulunamadi")
        val best = patterns.maxByOrNull { it.patternLength * it.matchPositions.size }
            ?: return PatternInfo("NONE", 0, 0.0, "Gecersiz")
        val t = when {
            best.patternLength >= 6 && best.matchPositions.size >= 3 -> "STRONG_PERIODIC"
            best.patternLength >= 4 && best.matchPositions.size >= 2 -> "MODERATE_PERIODIC"
            best.patternLength >= 3 && best.matchPositions.size >= 2 -> "WEAK_PERIODIC"
            else -> "FRAGMENTARY"
        }
        return PatternInfo(
            t, best.patternLength,
            (best.patternLength.toDouble() / 10.0) * minOf(best.matchPositions.size / 3.0, 1.0),
            t
        )
    }

    fun eliminateLowVotes(votes: Map<Int, Double>): Map<Int, Double> {
        val filtered = votes.filter { it.value >= 0.20 }
        if (filtered.isEmpty()) return votes
        val total = filtered.values.sum()
        return filtered.mapValues { it.value / total }
    }

    private fun defaultResult() = RegimeAnalysisResult(
        currentRegimeType = MicroRegimeType.KAOS,
        regimeSequence = RegimeSequence(emptyList(), 0),
        votes = mapOf(1 to 0.25, 2 to 0.25, 3 to 0.25, 4 to 0.25),
        confidence = 0.25
    )
}