package com.fan.app.engine

class BayesianUpdater {

    fun compute(data: List<Int>): Map<Int, Double> {
        if (data.size < 3) return mapOf(1 to 0.25, 2 to 0.25, 3 to 0.25, 4 to 0.25)

        val last = data.last()
        val decayFactor = 0.95

        val conditionalCounts = mutableMapOf<Pair<Int, Int>, Double>()
        val priorCounts = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)

        for (i in 0 until data.size - 1) {
            val from = data[i]
            val to = data[i + 1]
            val weight = Math.pow(decayFactor, (data.size - 2 - i).toDouble())
            conditionalCounts[Pair(from, to)] = (conditionalCounts[Pair(from, to)] ?: 0.0) + weight
            priorCounts[to] = (priorCounts[to] ?: 0.0) + weight
        }

        val votes = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)
        val totalFromLast = (1..4).sumOf { conditionalCounts[Pair(last, it)] ?: 0.0 }

        val alpha = 0.5
        val totalPrior = priorCounts.values.sum()

        for (next in 1..4) {
            val conditional = conditionalCounts[Pair(last, next)] ?: 0.0
            val prior = priorCounts[next] ?: 0.0

            val likelihood = if (totalFromLast > 0)
                (conditional + alpha) / (totalFromLast + alpha * 4)
            else
                0.25

            val priorProb = if (totalPrior > 0)
                (prior + alpha) / (totalPrior + alpha * 4)
            else
                0.25

            votes[next] = likelihood * 0.7 + priorProb * 0.3
        }

        val total = votes.values.sum()
        if (total == 0.0) return mapOf(1 to 0.25, 2 to 0.25, 3 to 0.25, 4 to 0.25)
        return votes.mapValues { it.value / total }
    }
}