package com.fan.app.ui

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.Window
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.view.View

class SettingsDialog(context: Context) : Dialog(context) {

    private val prefs = context.getSharedPreferences("fan_settings", Context.MODE_PRIVATE)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        buildUI()
    }

    private fun buildUI() {
        val scroll = ScrollView(context)
        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(Color.parseColor("#F5F5F5"))
        }

        val title = TextView(context).apply {
            text = "Ayarlar"
            textSize = 18f
            setTextColor(Color.parseColor("#212121"))
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 24)
        }
        container.addView(title)

        // Buton Boyutu
        val currentSize = prefs.getInt("button_size", 100)
        val sizeLabel = buildLabel("Buton Boyutu: %$currentSize")
        container.addView(sizeLabel)
        val sizeSeek = buildSeekBar(
            min = 50, max = 100, step = 10,
            current = currentSize
        ) { value ->
            sizeLabel.text = "Buton Boyutu: %$value"
            prefs.edit().putInt("button_size", value).apply()
        }
        container.addView(sizeSeek)
        container.addView(buildDivider())

        // Buton Şeffaflığı
        val currentOpacity = prefs.getInt("button_opacity", 30)
        val opacityLabel = buildLabel("Buton Şeffaflığı: %$currentOpacity")
        container.addView(opacityLabel)
        val opacitySeek = buildSeekBar(
            min = 10, max = 100, step = 10,
            current = currentOpacity
        ) { value ->
            opacityLabel.text = "Buton Şeffaflığı: %$value"
            prefs.edit().putInt("button_opacity", value).apply()
        }
        container.addView(opacitySeek)
        container.addView(buildDivider())

        // Şeffaflık Gecikmesi
        val currentDelay = prefs.getInt("fade_delay", 4)
        val delayLabel = buildLabel("Şeffaflık Gecikmesi: ${currentDelay}sn")
        container.addView(delayLabel)
        val delaySeek = buildSeekBar(
            min = 2, max = 10, step = 2,
            current = currentDelay
        ) { value ->
            delayLabel.text = "Şeffaflık Gecikmesi: ${value}sn"
            prefs.edit().putInt("fade_delay", value).apply()
        }
        container.addView(delaySeek)
        container.addView(buildDivider())

        // Titreşim
        val vibRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 8, 0, 8)
        }
        val vibLabel = TextView(context).apply {
            text = "Titreşim"
            textSize = 14f
            setTextColor(Color.parseColor("#212121"))
            layoutParams = LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f
            )
        }
        val vibSwitch = Switch(context).apply {
            isChecked = prefs.getBoolean("vibration", false)
            setOnCheckedChangeListener { _, isChecked ->
                prefs.edit().putBoolean("vibration", isChecked).apply()
            }
        }
        vibRow.addView(vibLabel)
        vibRow.addView(vibSwitch)
        container.addView(vibRow)
        container.addView(buildDivider())

        // Kaydet & Kapat
        val saveBtn = Button(context).apply {
            text = "Kaydet & Kapat"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#1565C0"))
            setPadding(0, 16, 0, 16)
            setOnClickListener { dismiss() }
        }
        val btnParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = 16 }
        container.addView(saveBtn, btnParams)

        scroll.addView(container)
        setContentView(scroll)

        window?.setLayout(
            (context.resources.displayMetrics.widthPixels * 0.9).toInt(),
            android.view.WindowManager.LayoutParams.WRAP_CONTENT
        )
    }

    private fun buildLabel(text: String): TextView {
        return TextView(context).apply {
            this.text = text
            textSize = 14f
            setTextColor(Color.parseColor("#212121"))
            setPadding(0, 8, 0, 4)
        }
    }

    private fun buildSeekBar(
        min: Int,
        max: Int,
        step: Int,
        current: Int,
        onChange: (Int) -> Unit
    ): SeekBar {
        val steps = (max - min) / step
        val currentStep = (current - min) / step

        return SeekBar(context).apply {
            this.max = steps
            progress = currentStep
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                    val value = min + (progress * step)
                    onChange(value)
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
    }

    private fun buildDivider(): View {
        return android.view.View(context).apply {
            setBackgroundColor(Color.parseColor("#E0E0E0"))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 1
            ).apply { topMargin = 8; bottomMargin = 8 }
        }
    }
}