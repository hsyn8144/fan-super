package com.fan.app.engine

import com.fan.app.data.DataEntry

object MultiHorizonEnsemble {

    data class HorizonPrediction(
        val name: String,
        val windowSize: Int,
        val prediction: HorizonResult,  // ✅ Ensemble.EnsembleResult değil!
        val weight: Double,
        val confidence: Double
    )

    // ✅ Ensemble.EnsembleResult bağımlılığını kırmak için hafif sonuç sınıfı
    data class HorizonResult(
        val finalPrediction: Int,
        val secondPrediction: Int?,
        val confidence: Double,
        val showDouble: Boolean
    )

    data class MultiScaleResult(
        val finalPrediction: Int,
        val secondPrediction: Int?,
        val confidence: Double,
        val showDouble: Boolean,
        val horizonBreakdown: List<HorizonPrediction>,
        val consensusType: String,
        val regimeTransitionWarning: Boolean
    )

    /**
     * ✅ Döngüyü kıran iç hesaplama motoru.
     * Ensemble.compute() çağırmaz — sadece temel algoritmalar kullanır.
     */
    private fun computeHorizonResult(
        data: List<Int>,
        pastEntries: List<DataEntry>
    ): HorizonResult {
        if (data.size < 2) {
            return HorizonResult(1, 2, 0.25, true)
        }

        // Temel oy toplama — Ensemble.compute() ÇAĞRILMAZ
        val votes = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)

        // 1) Frekans analizi
        val freq = mutableMapOf(1 to 0, 2 to 0, 3 to 0, 4 to 0)
        data.forEach { if (it in 1..4) freq[it] = (freq[it] ?: 0) + 1 }
        val total = data.size.toDouble()
        val expected = total / 4.0
        for ((k, count) in freq) {
            votes[k] = (votes[k] ?: 0.0) + maxOf(0.0, expected - count) * 0.3
        }

        // 2) Regime analizi
        val regimeVotes = RegimeDetector.analyze(data).votes
        for ((k, v) in regimeVotes) {
            votes[k] = (votes[k] ?: 0.0) + v * 0.4
        }

        // 3) Pattern analizi
        val patterns = PatternMatcher.findPatterns(data)
        val patternResult = PatternMatcher.analyzePatternVotes(data, patterns)
        for ((k, v) in patternResult.votes) {
            votes[k] = (votes[k] ?: 0.0) + v * 0.3
        }

        // Normalize
        val sum = votes.values.sum()
        val normalized = if (sum > 0) votes.mapValues { it.value / sum }
        else mapOf(1 to 0.25, 2 to 0.25, 3 to 0.25, 4 to 0.25)

        val sorted = normalized.entries.sortedByDescending { it.value }
        val topConf = sorted[0].value
        val topPred = sorted[0].key
        val secondPred = sorted.getOrNull(1)?.key
        val showDouble = topConf < 0.60

        return HorizonResult(topPred, secondPred, topConf, showDouble)
    }

    fun compute(data: List<Int>, pastEntries: List<DataEntry>): MultiScaleResult {
        if (data.size < 10) {
            // ✅ Burada da computeHorizonResult kullan, Ensemble.compute() değil!
            val basic = computeHorizonResult(data, pastEntries)
            return MultiScaleResult(
                finalPrediction = basic.finalPrediction,
                secondPrediction = basic.secondPrediction,
                confidence = basic.confidence,
                showDouble = basic.showDouble,
                horizonBreakdown = emptyList(),
                consensusType = "INSUFFICIENT_DATA",
                regimeTransitionWarning = false
            )
        }

        val horizons = listOf(
            Triple(10, "ultra_short", 0.15),
            Triple(25, "short", 0.25),
            Triple(50, "medium", 0.25),
            Triple(100, "long", 0.20),
            Triple(data.size, "full", 0.15)
        )

        val horizonPredictions = horizons.map { (size, name, baseWeight) ->
            val windowData = data.takeLast(size)
            // ✅ Ensemble.compute() YOK — computeHorizonResult kullanılıyor
            val prediction = computeHorizonResult(windowData, pastEntries)
            val recencyWeight = calculateRecencyWeight(size, data.size)
            val stabilityBonus = calculateStabilityBonus(windowData)
            HorizonPrediction(
                name = name,
                windowSize = size,
                prediction = prediction,
                weight = baseWeight * recencyWeight * stabilityBonus,
                confidence = prediction.confidence
            )
        }

        val consensus = analyzeConsensus(horizonPredictions)
        val regimeTransition = detectRegimeTransition(horizonPredictions, data)

        val resolved = if (consensus.hasConflict) {
            resolveConflict(horizonPredictions, data, consensus, regimeTransition)
        } else {
            ResolvedPrediction(
                prediction = consensus.dominantPrediction,
                confidence = consensus.confidence,
                second = null,
                reason = "Konsensüs var"
            )
        }

        val showDouble = shouldShowDouble(resolved, horizonPredictions)

        return MultiScaleResult(
            finalPrediction = resolved.prediction,
            secondPrediction = resolved.second,
            confidence = resolved.confidence,
            showDouble = showDouble,
            horizonBreakdown = horizonPredictions,
            consensusType = if (consensus.hasConflict) "CONFLICT_RESOLVED" else "STRONG_CONSENSUS",
            regimeTransitionWarning = regimeTransition.isTransitioning
        )
    }

    private fun calculateRecencyWeight(windowSize: Int, totalSize: Int): Double =
        1.0 + 0.5 * (windowSize.toDouble() / totalSize)

    private fun calculateStabilityBonus(data: List<Int>): Double {
        if (data.size < 20) return 1.0
        val regime = RegimeDetector.detectCurrentRegime(data)
        val entropy = RegimeDetector.computeBlockEntropy(data, data.size)
        return when {
            regime == RegimeDetector.RegimeType.REGULAR && entropy < 0.7 -> 1.3
            regime == RegimeDetector.RegimeType.CHAOS && entropy > 0.8 -> 0.8
            else -> 1.0
        }
    }

    private fun analyzeConsensus(horizons: List<HorizonPrediction>): ConsensusAnalysis {
        val predictions = horizons.map { it.prediction.finalPrediction }
        val frequency = predictions.groupBy { it }.mapValues { it.value.size }
        val dominant = frequency.maxByOrNull { it.value }?.key ?: 1
        val dominantCount = frequency[dominant] ?: 0
        val hasConflict = dominantCount < horizons.size * 0.6
        val avgConfidence = horizons.map { it.confidence }.average()
        val confidenceVariance = horizons.map {
            (it.confidence - avgConfidence) * (it.confidence - avgConfidence)
        }.average()
        return ConsensusAnalysis(
            dominantPrediction = dominant,
            confidence = if (hasConflict) avgConfidence * 0.8 else avgConfidence,
            hasConflict = hasConflict,
            frequency = frequency,
            variance = confidenceVariance
        )
    }

    private fun detectRegimeTransition(
        horizons: List<HorizonPrediction>,
        data: List<Int>
    ): RegimeTransition {
        val shortTermRegime = RegimeDetector.detectCurrentRegime(data.takeLast(25))
        val longTermRegime = RegimeDetector.detectCurrentRegime(
            data.takeLast(minOf(100, data.size))
        )
        val isTransitioning = shortTermRegime != longTermRegime
        val direction = if (isTransitioning) {
            val shortPattern = RegimeDetector.detectPattern(data.takeLast(25))
            val longPattern = RegimeDetector.detectPattern(
                data.takeLast(minOf(100, data.size))
            )
            when {
                shortPattern.strength > longPattern.strength -> "STABILIZING"
                shortPattern.strength < longPattern.strength * 0.5 -> "DESTABILIZING"
                else -> "UNCERTAIN"
            }
        } else "STABLE"
        return RegimeTransition(isTransitioning, shortTermRegime, longTermRegime, direction)
    }

    private fun resolveConflict(
        horizons: List<HorizonPrediction>,
        data: List<Int>,
        consensus: ConsensusAnalysis,
        transition: RegimeTransition
    ): ResolvedPrediction {
        val shortTerm = horizons.firstOrNull { it.name == "short" } ?: horizons.first()
        val longTerm = horizons.firstOrNull { it.name == "long" } ?: horizons.last()
        return when {
            transition.isTransitioning && transition.direction == "DESTABILIZING" ->
                ResolvedPrediction(
                    shortTerm.prediction.finalPrediction,
                    shortTerm.confidence * 0.9,
                    longTerm.prediction.finalPrediction,
                    "Rejim değişimi: Kısa vade"
                )
            transition.isTransitioning && transition.direction == "STABILIZING" ->
                ResolvedPrediction(
                    longTerm.prediction.finalPrediction,
                    longTerm.confidence * 0.85,
                    shortTerm.prediction.finalPrediction,
                    "Rejim stabilizasyonu: Uzun vade"
                )
            consensus.variance > 0.1 -> {
                val w = calculateWeightedVote(horizons)
                ResolvedPrediction(w.first, w.second * 0.8, w.third, "Yüksek varyans: Ağırlıklı oylama")
            }
            else -> {
                val topTwo = consensus.frequency.entries.sortedByDescending { it.value }.take(2)
                ResolvedPrediction(
                    topTwo[0].key,
                    0.5,
                    if (topTwo.size > 1) topTwo[1].key else null,
                    "Zayıf konsensüs"
                )
            }
        }
    }

    private fun calculateWeightedVote(
        horizons: List<HorizonPrediction>
    ): Triple<Int, Double, Int?> {
        val votes = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)
        for (h in horizons) {
            val pred = h.prediction.finalPrediction
            votes[pred] = (votes[pred] ?: 0.0) + h.weight * h.confidence
            if (h.prediction.secondPrediction != null) {
                val second = h.prediction.secondPrediction
                votes[second] = (votes[second] ?: 0.0) + h.weight * h.confidence * 0.5
            }
        }
        val sorted = votes.entries.sortedByDescending { it.value }
        val total = votes.values.sum()
        return Triple(
            sorted[0].key,
            if (total > 0) sorted[0].value / total else 0.25,
            sorted.getOrNull(1)?.key
        )
    }

    private fun shouldShowDouble(
        resolved: ResolvedPrediction,
        horizons: List<HorizonPrediction>
    ): Boolean {
        if (resolved.confidence < 0.55) return true
        if (resolved.second != null &&
            resolved.confidence - (horizons.map { it.prediction.confidence }
                .minOrNull() ?: 0.0) < 0.15) return true
        return false
    }

    data class ConsensusAnalysis(
        val dominantPrediction: Int,
        val confidence: Double,
        val hasConflict: Boolean,
        val frequency: Map<Int, Int>,
        val variance: Double
    )

    data class RegimeTransition(
        val isTransitioning: Boolean,
        val shortTermRegime: RegimeDetector.RegimeType,
        val longTermRegime: RegimeDetector.RegimeType,
        val direction: String
    )

    data class ResolvedPrediction(
        val prediction: Int,
        val confidence: Double,
        val second: Int?,
        val reason: String
    )
}