package com.fan.app.engine

import com.fan.app.data.DataEntry
import kotlin.math.abs

class MetaLearner {

    data class Condition(
        val regimeType: String,
        val previousRegime: String,
        val patternLengthBucket: Int,
        val chaosBucket: Int,
        val councilDensityBucket: Int,
        val streakLen: Int,
        val deltaSign: Int,
        val freqBias: Int
    )

    private val methodPerformance = mutableMapOf<Int, MutableMap<String, Pair<Int, Int>>>()

    fun compute(
        data: List<Int>,
        methodVotes: List<Ensemble.MethodVote>,
        pastEntries: List<DataEntry>
    ): Map<Int, Double> {
        if (data.size < 20 || methodVotes.isEmpty()) {
            return methodVotes.fold(mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)) { acc, mv ->
                val top = mv.finalPrediction1.takeIf { it > 0 }
                    ?: mv.nativeVotes.maxByOrNull { it.value }?.key
                    ?: 1
                acc[top] = (acc[top] ?: 0.0) + 1.0
                acc
            }.let { normalizeVotes(it) }
        }

        val condition = extractCondition(data, pastEntries)
        val condKey = conditionToKey(condition)

        updatePerformance(pastEntries)

        // Tarihsel bağlam oyları
        val historicalVotes = buildHistoricalContextVotes(condition, pastEntries)

        val weightedVotes = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)

        for ((idx, mv) in methodVotes.withIndex()) {
            val perf = methodPerformance[idx]?.get(condKey)
            val weight = if (perf != null && perf.second >= 5) {
                val accuracy = perf.first.toDouble() / perf.second
                0.5 + accuracy
            } else {
                1.0
            }

            val top = mv.finalPrediction1.takeIf { it > 0 }
                ?: mv.nativeVotes.maxByOrNull { it.value }?.key
                ?: 1
            weightedVotes[top] = (weightedVotes[top] ?: 0.0) + weight

            // Native tahmine de kısmi ağırlık ver
            val nativeTop = mv.nativePrediction1.takeIf { it > 0 && it != top }
            if (nativeTop != null) {
                weightedVotes[nativeTop] = (weightedVotes[nativeTop] ?: 0.0) + weight * 0.25
            }
        }

        // Tarihsel bağlam oylarını ekle
        for ((k, v) in historicalVotes) {
            weightedVotes[k] = (weightedVotes[k] ?: 0.0) + v * 1.2
        }

        return normalizeVotes(weightedVotes)
    }

    private fun extractCondition(data: List<Int>, pastEntries: List<DataEntry>): Condition {
        val regime = RegimeDetector.detectCurrentRegime(data.takeLast(25))
        val previousRegime = pastEntries.lastOrNull()?.currentRegime ?: regime.name
        val (_, streak) = RegimeDetector.getCurrentStreak(data)
        val delta = if (data.size >= 2) Integer.signum(data.last() - data[data.size - 2]) else 0
        val freq = data.takeLast(20).groupBy { it }.maxByOrNull { it.value.size }?.key ?: 1

        val patternInfo = RegimeDetector.detectPattern(data)
        val chaosScore = ContextualMemory.getChaosScore()
        val activeCount = MeritCouncil.getAllStates().values.count { !it.muted }
            .takeIf { it > 0 } ?: DataEntry.METHOD_COUNT

        return Condition(
            regimeType = regime.name,
            previousRegime = extractRegimeGroup(previousRegime),
            patternLengthBucket = bucketPatternLength(patternInfo.length),
            chaosBucket = bucketChaos(chaosScore),
            councilDensityBucket = bucketCouncilDensity(activeCount),
            streakLen = minOf(streak, 6),
            deltaSign = delta,
            freqBias = freq
        )
    }

    private fun conditionToKey(c: Condition): String =
        "${c.regimeType}_${c.previousRegime}_${c.patternLengthBucket}_${c.chaosBucket}_${c.councilDensityBucket}_${c.streakLen}_${c.deltaSign}_${c.freqBias}"

    private fun updatePerformance(
        pastEntries: List<DataEntry>
    ) {
        val evaluated = pastEntries.drop(DataEntry.INTERNAL_THRESHOLD).takeLast(250)
        if (evaluated.isEmpty()) return

        for (entry in evaluated) {
            val entryCondKey = buildCondKeyFromEntry(entry)
            for (methodIdx in 0 until DataEntry.METHOD_COUNT) {
                val correct = getMethodCorrect(entry, methodIdx)
                methodPerformance.getOrPut(methodIdx) { mutableMapOf() }
                    .let { map ->
                        val prev = map[entryCondKey] ?: Pair(0, 0)
                        map[entryCondKey] = Pair(
                            prev.first + if (correct) 1 else 0,
                            prev.second + 1
                        )
                    }
            }
        }
    }

    /**
     * Tarihsel bağlam oyları: Geçmişte benzer koşullarda hangi değerler gelmiş?
     */
    private fun buildHistoricalContextVotes(
        currentCondition: Condition,
        pastEntries: List<DataEntry>
    ): Map<Int, Double> {
        val votes = mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0)
        val recent = pastEntries.drop(DataEntry.INTERNAL_THRESHOLD).takeLast(200)

        for ((idx, entry) in recent.withIndex()) {
            if (entry.value !in 1..4) continue

            val historicalCondition = buildConditionFromEntry(entry)
            val similarity = conditionSimilarity(currentCondition, historicalCondition)
            if (similarity <= 0.25) continue

            val recency = PatternMatcher.recencyFactor(recent.size - idx, recent.size)
            votes[entry.value] = (votes[entry.value] ?: 0.0) + similarity * recency
        }

        return votes
    }

    /**
     * İki koşul arasındaki benzerliği ölçer.
     * Tam eşit = 1.0, tamamen farklı = 0.0
     */
    private fun conditionSimilarity(a: Condition, b: Condition): Double {
        var score = 0.0
        var total = 0.0

        // Rejim eşleşmesi
        total += 1.0
        score += when {
            a.regimeType == b.regimeType -> 1.0
            regimeGroup(a.regimeType) == regimeGroup(b.regimeType) -> 0.6
            else -> 0.0
        }

        // Önceki rejim eşleşmesi
        total += 0.7
        score += 0.7 * when {
            a.previousRegime == b.previousRegime -> 1.0
            regimeGroup(a.previousRegime) == regimeGroup(b.previousRegime) -> 0.6
            else -> 0.0
        }

        // Kalıp uzunluğu bucket
        total += 0.6
        score += 0.6 * (1.0 - (abs(a.patternLengthBucket - b.patternLengthBucket).toDouble() / 4.0).coerceAtMost(1.0))

        // Kaos bucket
        total += 0.5
        score += 0.5 * (1.0 - (abs(a.chaosBucket - b.chaosBucket).toDouble() / 4.0).coerceAtMost(1.0))

        // Meclis yoğunluğu
        total += 0.4
        score += 0.4 * (1.0 - (abs(a.councilDensityBucket - b.councilDensityBucket).toDouble() / 4.0).coerceAtMost(1.0))

        // Seri uzunluğu
        total += 0.4
        score += 0.4 * (1.0 - (abs(a.streakLen - b.streakLen).toDouble() / 6.0).coerceAtMost(1.0))

        // Delta yönü
        total += 0.2
        score += 0.2 * if (a.deltaSign == b.deltaSign) 1.0 else 0.0

        // Frekans bias
        total += 0.2
        score += 0.2 * if (a.freqBias == b.freqBias) 1.0 else 0.0

        return if (total > 0) score / total else 0.0
    }

    private fun buildCondKeyFromEntry(entry: DataEntry): String {
        val cond = buildConditionFromEntry(entry)
        return conditionToKey(cond)
    }

    private fun buildConditionFromEntry(entry: DataEntry): Condition {
        return Condition(
            regimeType = extractRegimeGroup(entry.currentRegime),
            previousRegime = extractRegimeGroup(entry.previousRegime),
            patternLengthBucket = bucketPatternLength(entry.matchedPatternLength),
            chaosBucket = bucketChaos(entry.chaosScore),
            councilDensityBucket = bucketCouncilDensity(entry.activeModelCount),
            streakLen = minOf(entry.regimeStableCount, 6),
            deltaSign = 0,
            freqBias = entry.value
        )
    }

    private fun getMethodCorrect(entry: DataEntry, index: Int): Boolean =
        when (index) {
            0  -> entry.method1Correct
            1  -> entry.method2Correct
            2  -> entry.method3Correct
            3  -> entry.method4Correct
            4  -> entry.method5Correct
            5  -> entry.method6Correct
            6  -> entry.method7Correct
            7  -> entry.method8Correct
            8  -> entry.method9Correct
            9  -> entry.method10Correct
            10 -> entry.method11Correct
            11 -> entry.method12Correct
            12 -> entry.method13Correct
            else -> false
        }

    private fun bucketPatternLength(length: Int): Int = when {
        length >= 8 -> 4
        length >= 6 -> 3
        length >= 4 -> 2
        length >= 3 -> 1
        else -> 0
    }

    private fun bucketChaos(chaosScore: Double): Int = when {
        chaosScore >= 20.0 -> 4
        chaosScore >= 12.0 -> 3
        chaosScore >= 6.0 -> 2
        chaosScore >= 2.0 -> 1
        else -> 0
    }

    private fun bucketCouncilDensity(activeCount: Int): Int = when {
        activeCount >= 12 -> 4
        activeCount >= 10 -> 3
        activeCount >= 8 -> 2
        activeCount >= 6 -> 1
        else -> 0
    }

    private fun extractRegimeGroup(regime: String): String {
        return when {
            regime.contains("TEKRAR") || regime.contains("BLOK") || regime.contains("DALGA_TEK") -> "TEKRAR"
            regime.contains("ARTIS") || regime.contains("AZALIS") || regime.contains("TEPE") ||
                    regime.contains("VADI") || regime.contains("DONGU") -> "YON"
            regime.contains("SINIR") || regime.contains("KOSEGEN") || regime.contains("ZIGZAK") -> "SALINIMM"
            else -> "KAOS"
        }
    }

    private fun regimeGroup(regime: String): String = extractRegimeGroup(regime)

    private fun normalizeVotes(votes: Map<Int, Double>): Map<Int, Double> {
        val total = votes.values.sum()
        if (total == 0.0) return mapOf(1 to 0.25, 2 to 0.25, 3 to 0.25, 4 to 0.25)
        return votes.mapValues { it.value / total }
    }
}