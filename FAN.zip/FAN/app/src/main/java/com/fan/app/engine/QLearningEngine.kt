package com.fan.app.engine

class QLearningEngine {

    private val qTable = mutableMapOf<String, MutableMap<Int, Double>>()
    private val learningRate = 0.1
    private val discountFactor = 0.9
    private val epsilon = 0.1

    fun compute(data: List<Int>): Map<Int, Double> {
        if (data.size < 5) return mapOf(1 to 0.25, 2 to 0.25, 3 to 0.25, 4 to 0.25)

        trainOnHistory(data)

        val state = getState(data)
        val qValues = qTable[state] ?: return mapOf(1 to 0.25, 2 to 0.25, 3 to 0.25, 4 to 0.25)

        val minQ = qValues.values.minOrNull() ?: 0.0
        val shifted = qValues.mapValues { it.value - minQ + 0.01 }
        val total = shifted.values.sum()
        if (total == 0.0) return mapOf(1 to 0.25, 2 to 0.25, 3 to 0.25, 4 to 0.25)
        return shifted.mapValues { it.value / total }
    }

    /**
     * Bağlamsal feature'larla zenginleştirilmiş compute.
     * Ensemble tarafından çağrılır.
     */
    fun computeWithContext(
        data: List<Int>,
        currentRegimeGroup: String,
        previousRegimeGroup: String,
        matchedPatternLength: Int,
        chaosBucket: Int,
        activeModelCount: Int
    ): Map<Int, Double> {
        if (data.size < 5) return mapOf(1 to 0.25, 2 to 0.25, 3 to 0.25, 4 to 0.25)

        trainOnHistory(data)

        val state = getStateWithContext(
            data = data,
            currentRegimeGroup = currentRegimeGroup,
            previousRegimeGroup = previousRegimeGroup,
            matchedPatternLength = matchedPatternLength,
            chaosBucket = chaosBucket,
            activeModelCount = activeModelCount
        )

        val qValues = qTable[state] ?: return mapOf(1 to 0.25, 2 to 0.25, 3 to 0.25, 4 to 0.25)

        val minQ = qValues.values.minOrNull() ?: 0.0
        val shifted = qValues.mapValues { it.value - minQ + 0.01 }
        val total = shifted.values.sum()
        if (total == 0.0) return mapOf(1 to 0.25, 2 to 0.25, 3 to 0.25, 4 to 0.25)
        return shifted.mapValues { it.value / total }
    }

    private fun trainOnHistory(data: List<Int>) {
        val trainSize = minOf(data.size - 1, 200)
        for (i in data.size - trainSize until data.size - 1) {
            val state = getState(data.subList(0, i + 1))
            val action = data[i + 1]
            val nextState = getState(data.subList(0, i + 2))
            val reward = 1.0

            val currentQ = qTable.getOrPut(state) { mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0) }
            val nextQ = qTable.getOrPut(nextState) { mutableMapOf(1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0) }
            val maxNextQ = nextQ.values.maxOrNull() ?: 0.0

            val oldQ = currentQ[action] ?: 0.0
            currentQ[action] = oldQ + learningRate * (reward + discountFactor * maxNextQ - oldQ)
        }
    }

    /**
     * Eski state fonksiyonu — geriye uyumluluk için korundu.
     * Temel: son 3 değer + seri uzunluğu + delta yönü
     */
    private fun getState(data: List<Int>): String {
        val last3 = data.takeLast(3).joinToString("")
        val streak = run {
            var s = 1
            val last = data.last()
            for (i in data.size - 2 downTo 0) {
                if (data[i] == last) s++ else break
            }
            minOf(s, 4)
        }
        val delta = if (data.size >= 2)
            Integer.signum(data.last() - data[data.size - 2]) + 1
        else 1
        return "${last3}_${streak}_${delta}"
    }

    /**
     * Zenginleştirilmiş state:
     * son 3 değer + seri + delta + rejim grubu + önceki rejim + kalıp bucket + kaos bucket + aktif model bucket
     */
    private fun getStateWithContext(
        data: List<Int>,
        currentRegimeGroup: String,
        previousRegimeGroup: String,
        matchedPatternLength: Int,
        chaosBucket: Int,
        activeModelCount: Int
    ): String {
        val last3 = data.takeLast(3).joinToString("")
        val streak = run {
            var s = 1
            val last = data.last()
            for (i in data.size - 2 downTo 0) {
                if (data[i] == last) s++ else break
            }
            minOf(s, 4)
        }
        val delta = if (data.size >= 2)
            Integer.signum(data.last() - data[data.size - 2]) + 1
        else 1

        val patternBucket = when {
            matchedPatternLength >= 8 -> 4
            matchedPatternLength >= 6 -> 3
            matchedPatternLength >= 4 -> 2
            matchedPatternLength >= 3 -> 1
            else -> 0
        }

        val activeBucket = when {
            activeModelCount >= 12 -> 4
            activeModelCount >= 10 -> 3
            activeModelCount >= 8 -> 2
            activeModelCount >= 6 -> 1
            else -> 0
        }

        return "${last3}_${streak}_${delta}_${currentRegimeGroup}_${previousRegimeGroup}_${patternBucket}_${chaosBucket}_${activeBucket}"
    }
}