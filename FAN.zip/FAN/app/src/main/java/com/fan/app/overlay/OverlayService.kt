package com.fan.app.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.fan.app.R
import com.fan.app.data.CsvManager
import com.fan.app.engine.PredictionEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class OverlayService : Service() {

    companion object {
        var isRunning = false
        const val CHANNEL_ID = "fan_overlay_channel"
        const val NOTIF_ID = 1001

        const val ACTION_REFRESH = "com.fan.app.overlay.ACTION_REFRESH"
        const val ACTION_APPLY_SETTINGS = "com.fan.app.overlay.ACTION_APPLY_SETTINGS"
    }

    private lateinit var overlayView: OverlayView
    private lateinit var engine: PredictionEngine
    private lateinit var csvManager: CsvManager

    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        csvManager = CsvManager(this)
        engine = PredictionEngine(csvManager)
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification())
        initOverlay()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_REFRESH -> refreshOverlay()
            ACTION_APPLY_SETTINGS -> {
                applySettingsFromPrefs()
                refreshOverlay()
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        serviceScope.cancel()

        if (::overlayView.isInitialized) {
            try {
                overlayView.hide()
            } catch (_: Exception) {
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun initOverlay() {
        overlayView = OverlayView(this)

        overlayView.onValueEntered = { value ->
            serviceScope.launch {
                val result = engine.onNewValue(value)
                overlayView.updateDisplay(result)
            }
        }

        overlayView.onDeletePressed = {
            serviceScope.launch {
                val result = engine.deleteLastValue()
                if (result != null) overlayView.updateDisplay(result)
            }
        }

        applySettingsFromPrefs()
        overlayView.show()
        refreshOverlay()
    }

    private fun refreshOverlay() {
        if (!::overlayView.isInitialized) return
        serviceScope.launch {
            val result = engine.getCurrentPrediction()
            overlayView.updateDisplay(result)
        }
    }

    private fun applySettingsFromPrefs() {
        if (!::overlayView.isInitialized) return

        val prefs = getSharedPreferences("fan_settings", Context.MODE_PRIVATE)
        val buttonSize = prefs.getInt("button_size", 100)
        val opacity = prefs.getInt("button_opacity", 30)
        val fadeDelay = prefs.getInt("fade_delay", 4)
        val vibration = prefs.getBoolean("vibration", false)

        overlayView.setButtonSize(buttonSize)
        overlayView.setOpacity(opacity)
        overlayView.setFadeDelay(fadeDelay * 1000L)
        overlayView.setVibrationEnabled(vibration)
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "FAN Overlay",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "FAN overlay servisi"
            setShowBadge(false)
        }

        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("FAN Aktif")
            .setContentText("Overlay çalışıyor")
            .setSmallIcon(R.drawable.ic_fan_logo)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .build()
    }
}