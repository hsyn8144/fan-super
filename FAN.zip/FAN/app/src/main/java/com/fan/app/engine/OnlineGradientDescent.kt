package com.fan.app.engine

class OnlineGradientDescent {

    private val featureSize = 16
    private val weights = Array(4) { DoubleArray(featureSize) { 0.0 } }
    private val bias = DoubleArray(4) { 0.0 }
    private var lr = 0.025

    // Çeşitlilik takibi
    private val predHistory = ArrayDeque<Int>(20)

    fun compute(data: List<Int>): Map<Int, Double> {
        if (data.size < 4) return equal()

        val trainFrom = maxOf(0, data.size - 100)
        for (i in trainFrom until data.size - 1) {
            val features = extractFeatures(data, i)
            learn(features, data[i + 1])
        }

        val features = extractFeatures(data, data.size - 1)
        return predictWithDiversity(features)
    }

    private fun extractFeatures(data: List<Int>, idx: Int): DoubleArray {
        val f = DoubleArray(featureSize)
        val v = data[idx]
        f[0] = (v - 2.5) / 1.5
        f[1] = if (idx > 0) (data[idx] - data[idx-1]).toDouble() / 3.0 else 0.0
        f[2] = if (idx > 1) (data[idx-1] - data[idx-2]).toDouble() / 3.0 else 0.0
        // Frekans son 10
        val win = data.subList(maxOf(0, idx - 9), idx + 1)
        for (k in 1..4) f[2 + k] = win.count { it == k }.toDouble() / win.size
        // Seri uzunluğu
        var streak = 1
        for (j in idx - 1 downTo maxOf(0, idx - 5)) { if (data[j] == v) streak++ else break }
        f[7] = streak.toDouble() / 5.0
        // Pozisyon döngüleri
        for (p in 2..5) f[5 + p] = if (idx % p == 0) 1.0 else 0.0
        f[14] = v.toDouble() / 4.0
        f[15] = if (idx > 0 && data[idx] == data[idx-1]) 1.0 else 0.0
        return f
    }

    private fun rawScores(f: DoubleArray): DoubleArray =
        DoubleArray(4) { cls ->
            bias[cls] + f.indices.sumOf { j -> weights[cls][j] * f[j] }
        }

    private fun softmax(scores: DoubleArray): DoubleArray {
        val mx = scores.max()
        val ex = DoubleArray(4) { kotlin.math.exp(scores[it] - mx) }
        val s = ex.sum().coerceAtLeast(1e-9)
        return DoubleArray(4) { ex[it] / s }
    }

    private fun learn(f: DoubleArray, target: Int) {
        val probs = softmax(rawScores(f))
        for (cls in 0..3) {
            val t = if (cls == target - 1) 1.0 else 0.0
            val err = t - probs[cls]
            bias[cls] += lr * err
            for (j in f.indices) weights[cls][j] += lr * err * f[j]
        }
    }

    private fun predictWithDiversity(f: DoubleArray): Map<Int, Double> {
        val probs = softmax(rawScores(f))
        val adjusted = diversityAdjust(probs)

        val top = adjusted.indices.maxByOrNull { adjusted[it] }!! + 1
        if (predHistory.size >= 20) predHistory.removeFirst()
        predHistory.addLast(top)

        val total = adjusted.sum().coerceAtLeast(1e-9)
        return mapOf(1 to adjusted[0]/total, 2 to adjusted[1]/total, 3 to adjusted[2]/total, 4 to adjusted[3]/total)
    }

    private fun diversityAdjust(probs: DoubleArray): DoubleArray {
        if (predHistory.size < 8) return probs
        val recent = predHistory.toList().takeLast(8)
        val freq = DoubleArray(4) { k -> recent.count { it == k + 1 }.toDouble() / recent.size }
        val result = DoubleArray(4)
        for (k in 0..3) {
            val penalty = when {
                freq[k] > 0.6 -> 0.35
                freq[k] > 0.4 -> 0.65
                else -> 1.0
            }
            result[k] = probs[k] * penalty
        }
        return result
    }

    private fun equal() = mapOf(1 to 0.25, 2 to 0.25, 3 to 0.25, 4 to 0.25)
}