package com.fan.app.utils

import android.content.Context
import android.content.res.ColorStateList
import android.util.TypedValue
import android.view.View
import android.widget.Button
import androidx.core.content.ContextCompat

fun Int.dpToPx(context: Context): Int {
    return TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP,
        this.toFloat(),
        context.resources.displayMetrics
    ).toInt()
}

fun Float.dpToPx(context: Context): Float {
    return TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP,
        this,
        context.resources.displayMetrics
    )
}

fun Int.spToPx(context: Context): Int {
    return TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_SP,
        this.toFloat(),
        context.resources.displayMetrics
    ).toInt()
}

fun View.visible() { visibility = View.VISIBLE }
fun View.gone() { visibility = View.GONE }
fun View.invisible() { visibility = View.INVISIBLE }

fun Button.setTint(color: Int) {
    backgroundTintList = ColorStateList.valueOf(color)
}

fun Double.toPercent(): String = "%${(this * 100).toInt()}"

fun List<Int>.toDisplayString(): String {
    if (isEmpty()) return "- - - - - -"
    val padded = if (size < 6) {
        List(6 - size) { 0 } + this
    } else takeLast(6)
    return padded.joinToString(" ") { if (it == 0) "-" else it.toString() }
}

fun Map<Int, Double>.topTwo(): Pair<Int, Int?> {
    val sorted = entries.sortedByDescending { it.value }
    val top = sorted.getOrNull(0)?.key ?: 1
    val second = sorted.getOrNull(1)?.key
    return Pair(top, second)
}

fun Map<Int, Double>.confidence(): Double {
    return values.maxOrNull() ?: 0.25
}

fun Map<Int, Double>.filterLowVotes(threshold: Double = 0.25): Map<Int, Double> {
    val filtered = filter { it.value >= threshold }
    if (filtered.isEmpty()) return this
    val total = filtered.values.sum()
    return filtered.mapValues { it.value / total }
}

fun Long.toFormattedDate(): String {
    val sdf = java.text.SimpleDateFormat("dd.MM.yyyy HH:mm", java.util.Locale.getDefault())
    return sdf.format(java.util.Date(this))
}

fun Int.toValueColor(): Int {
    return when (this) {
        1 -> android.graphics.Color.parseColor("#4CAF50")
        2 -> android.graphics.Color.parseColor("#2196F3")
        3 -> android.graphics.Color.parseColor("#FF9800")
        4 -> android.graphics.Color.parseColor("#F44336")
        else -> android.graphics.Color.parseColor("#9E9E9E")
    }
}