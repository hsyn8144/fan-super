package com.fan.app.data

class DataEntry {

    // ── Satır Temeli ─────────────────────────────────────────────────
    var id: Long = 0
    var timestamp: Long = System.currentTimeMillis()
    var value: Int = 0
    var previousPredictionId: Long = 0
    var dataCount: Int = 0

    // ── Ensemble Final ───────────────────────────────────────────────
    var ensemblePrediction1: Int = 0
    var ensemblePrediction2: Int = 0
    var ensembleIsDouble: Boolean = false
    var ensembleConfidence: Double = 0.0
    var ensemblePrimary1Correct: Boolean = false
    var ensemblePrimary2Correct: Boolean = false
    var ensembleTotalCorrect: Boolean = false
    var ensemblePrimary1Accuracy: Double = 0.0
    var ensemblePrimary2Accuracy: Double = 0.0
    var ensembleTotalAccuracy: Double = 0.0

    // ── Combined ─────────────────────────────────────────────────────
    var combinedPrediction1: Int = 0
    var combinedPrediction2: Int = 0
    var combinedIsDouble: Boolean = false
    var combinedConfidence: Double = 0.0
    var combinedPrimary1Correct: Boolean = false
    var combinedPrimary2Correct: Boolean = false
    var combinedTotalCorrect: Boolean = false
    var combinedPrimary1Accuracy: Double = 0.0
    var combinedPrimary2Accuracy: Double = 0.0
    var combinedTotalAccuracy: Double = 0.0

    // ── Kalıp Tek ────────────────────────────────────────────────────
    var kalipPrediction1: Int = 0
    var kalipPrediction2: Int = 0
    var kalipIsDouble: Boolean = false
    var kalipConfidence: Double = 0.0
    var kalipPrimary1Correct: Boolean = false
    var kalipPrimary2Correct: Boolean = false
    var kalipTotalCorrect: Boolean = false
    var kalipPrimary1Accuracy: Double = 0.0
    var kalipPrimary2Accuracy: Double = 0.0
    var kalipTotalAccuracy: Double = 0.0

    // ── Yan Tahmin Standart ──────────────────────────────────────────
    var sideStandardPrediction: String = ""
    var sideStandardCorrect: Boolean = false
    var sideStandardDoubleCorrect: Boolean = false
    var sideStandardAccuracy: Double = 0.0
    var sideStandardDoubleAccuracy: Double = 0.0

    // ── Yan Tahmin Rejim ─────────────────────────────────────────────
    var sideRegimePrediction: String = ""
    var sideRegimeCorrect: Boolean = false
    var sideRegimeDoubleCorrect: Boolean = false
    var sideRegimeAccuracy: Double = 0.0
    var sideRegimeDoubleAccuracy: Double = 0.0

    // ── Yan Tahmin Final / Gösterim ──────────────────────────────────
    var sideDisplayPrediction: String = ""
    var sideFinalCorrect: Boolean = false
    var sideFinalDoubleCorrect: Boolean = false
    var sideFinalAccuracy: Double = 0.0
    var sideFinalDoubleAccuracy: Double = 0.0

    // ── Rejim / Kalıp / Kaos ─────────────────────────────────────────
    var currentRegime: String = "KAOS"
    var previousRegime: String = ""
    var regimeStableCount: Int = 0
    var matchedPatternLength: Int = 0
    var matchedPatternCount: Int = 0
    var matchedPatternRegime: String = ""
    var regimeSimilarityScore: Double = 0.0
    var chaosScore: Double = 0.0
    var patternBreakLength: Int = 0
    var anomalyFlags: String = ""
    var confidenceAdjusted: Boolean = false
    var activeModelCount: Int = 0

    // ── Meclis Durumu ────────────────────────────────────────────────
    var mutedModels: String = ""
    var rewardedModels: String = ""
    var returnedModels: String = ""
    var fallbackModel: String = ""
    var decisionReason: String = ""

    // ── Genel Trace Alanları ─────────────────────────────────────────
    var standartYanTahminTeklikCiftlikGuven: String = ""
    var standartYanTahminKucuklukBuyuklukGuven: String = ""
    var rejimYanTahminTeklikCiftlikGuven: String = ""
    var rejimYanTahminKucuklukBuyuklukGuven: String = ""
    var yanTahminFinalSecimKaynagi: String = ""
    var ensembleKararDetayi: String = ""
    var kaosSkoruDetayi: String = ""
    var kirilanKalipDetayi: String = ""
    var eslesenKalipDetayi: String = ""
    var rejimGecisTahmini: String = ""
    var rejimGecisDegerTahmini: String = ""
    var meclisDurumDetayi: String = ""

    // ─────────────────────────────────────────────────────────────────
    // METHOD 1 — Kalip_Arama
    // ─────────────────────────────────────────────────────────────────
    var method1Active: Boolean = true
    var method1Muted: Boolean = false
    var method1StreakSuccess: Int = 0
    var method1StreakFail: Int = 0
    var method1VoteMultiplier: Double = 1.0

    var method1NativePrediction1: Int = 0
    var method1NativePrediction2: Int = 0
    var method1NativeConfidence: Double = 0.0

    var method1PatternPrediction1: Int = 0
    var method1PatternPrediction2: Int = 0
    var method1PatternConfidence: Double = 0.0
    var method1PatternRefLength: Int = 0
    var method1PatternRefRegime: String = ""
    var method1PatternRefCount: Int = 0

    var method1RegimePrediction1: Int = 0
    var method1RegimePrediction2: Int = 0
    var method1RegimeConfidence: Double = 0.0

    var method1MetaPrediction1: Int = 0
    var method1MetaPrediction2: Int = 0
    var method1MetaConfidence: Double = 0.0

    var method1BlendedPrediction1: Int = 0
    var method1BlendedPrediction2: Int = 0
    var method1BlendedConfidence: Double = 0.0

    var method1FinalPrediction1: Int = 0
    var method1FinalPrediction2: Int = 0
    var method1FinalConfidence: Double = 0.0

    var method1DecisionSource: String = "NATIVE"
    var method1BiasShifted: Boolean = false

    var method1NativeCorrect: Boolean = false
    var method1PatternCorrect: Boolean = false
    var method1RegimeCorrect: Boolean = false
    var method1MetaCorrect: Boolean = false

    var method1NativeSuccessStreak: Int = 0
    var method1SupportSuccessStreak: Int = 0
    var method1SupportSharedSuccess: Boolean = false
    var method1RewardTier: String = "NONE"

    var method1Correct: Boolean = false
    var method1Accuracy: Double = 0.0

    // ─────────────────────────────────────────────────────────────────
    // METHOD 2 — Rejim_Tespiti
    // ─────────────────────────────────────────────────────────────────
    var method2Active: Boolean = true
    var method2Muted: Boolean = false
    var method2StreakSuccess: Int = 0
    var method2StreakFail: Int = 0
    var method2VoteMultiplier: Double = 1.0

    var method2NativePrediction1: Int = 0
    var method2NativePrediction2: Int = 0
    var method2NativeConfidence: Double = 0.0

    var method2PatternPrediction1: Int = 0
    var method2PatternPrediction2: Int = 0
    var method2PatternConfidence: Double = 0.0
    var method2PatternRefLength: Int = 0
    var method2PatternRefRegime: String = ""
    var method2PatternRefCount: Int = 0

    var method2RegimePrediction1: Int = 0
    var method2RegimePrediction2: Int = 0
    var method2RegimeConfidence: Double = 0.0

    var method2MetaPrediction1: Int = 0
    var method2MetaPrediction2: Int = 0
    var method2MetaConfidence: Double = 0.0

    var method2BlendedPrediction1: Int = 0
    var method2BlendedPrediction2: Int = 0
    var method2BlendedConfidence: Double = 0.0

    var method2FinalPrediction1: Int = 0
    var method2FinalPrediction2: Int = 0
    var method2FinalConfidence: Double = 0.0

    var method2DecisionSource: String = "NATIVE"
    var method2BiasShifted: Boolean = false

    var method2NativeCorrect: Boolean = false
    var method2PatternCorrect: Boolean = false
    var method2RegimeCorrect: Boolean = false
    var method2MetaCorrect: Boolean = false

    var method2NativeSuccessStreak: Int = 0
    var method2SupportSuccessStreak: Int = 0
    var method2SupportSharedSuccess: Boolean = false
    var method2RewardTier: String = "NONE"

    var method2Correct: Boolean = false
    var method2Accuracy: Double = 0.0

    // ─────────────────────────────────────────────────────────────────
    // METHOD 3 — Fark_Dizisi
    // ─────────────────────────────────────────────────────────────────
    var method3Active: Boolean = true
    var method3Muted: Boolean = false
    var method3StreakSuccess: Int = 0
    var method3StreakFail: Int = 0
    var method3VoteMultiplier: Double = 1.0

    var method3NativePrediction1: Int = 0
    var method3NativePrediction2: Int = 0
    var method3NativeConfidence: Double = 0.0

    var method3PatternPrediction1: Int = 0
    var method3PatternPrediction2: Int = 0
    var method3PatternConfidence: Double = 0.0
    var method3PatternRefLength: Int = 0
    var method3PatternRefRegime: String = ""
    var method3PatternRefCount: Int = 0

    var method3RegimePrediction1: Int = 0
    var method3RegimePrediction2: Int = 0
    var method3RegimeConfidence: Double = 0.0

    var method3MetaPrediction1: Int = 0
    var method3MetaPrediction2: Int = 0
    var method3MetaConfidence: Double = 0.0

    var method3BlendedPrediction1: Int = 0
    var method3BlendedPrediction2: Int = 0
    var method3BlendedConfidence: Double = 0.0

    var method3FinalPrediction1: Int = 0
    var method3FinalPrediction2: Int = 0
    var method3FinalConfidence: Double = 0.0

    var method3DecisionSource: String = "NATIVE"
    var method3BiasShifted: Boolean = false

    var method3NativeCorrect: Boolean = false
    var method3PatternCorrect: Boolean = false
    var method3RegimeCorrect: Boolean = false
    var method3MetaCorrect: Boolean = false

    var method3NativeSuccessStreak: Int = 0
    var method3SupportSuccessStreak: Int = 0
    var method3SupportSharedSuccess: Boolean = false
    var method3RewardTier: String = "NONE"

    var method3Correct: Boolean = false
    var method3Accuracy: Double = 0.0

    // ─────────────────────────────────────────────────────────────────
    // METHOD 4 — Ayna_Kalip
    // ─────────────────────────────────────────────────────────────────
    var method4Active: Boolean = true
    var method4Muted: Boolean = false
    var method4StreakSuccess: Int = 0
    var method4StreakFail: Int = 0
    var method4VoteMultiplier: Double = 1.0

    var method4NativePrediction1: Int = 0
    var method4NativePrediction2: Int = 0
    var method4NativeConfidence: Double = 0.0

    var method4PatternPrediction1: Int = 0
    var method4PatternPrediction2: Int = 0
    var method4PatternConfidence: Double = 0.0
    var method4PatternRefLength: Int = 0
    var method4PatternRefRegime: String = ""
    var method4PatternRefCount: Int = 0

    var method4RegimePrediction1: Int = 0
    var method4RegimePrediction2: Int = 0
    var method4RegimeConfidence: Double = 0.0

    var method4MetaPrediction1: Int = 0
    var method4MetaPrediction2: Int = 0
    var method4MetaConfidence: Double = 0.0

    var method4BlendedPrediction1: Int = 0
    var method4BlendedPrediction2: Int = 0
    var method4BlendedConfidence: Double = 0.0

    var method4FinalPrediction1: Int = 0
    var method4FinalPrediction2: Int = 0
    var method4FinalConfidence: Double = 0.0

    var method4DecisionSource: String = "NATIVE"
    var method4BiasShifted: Boolean = false

    var method4NativeCorrect: Boolean = false
    var method4PatternCorrect: Boolean = false
    var method4RegimeCorrect: Boolean = false
    var method4MetaCorrect: Boolean = false

    var method4NativeSuccessStreak: Int = 0
    var method4SupportSuccessStreak: Int = 0
    var method4SupportSharedSuccess: Boolean = false
    var method4RewardTier: String = "NONE"

    var method4Correct: Boolean = false
    var method4Accuracy: Double = 0.0

    // ─────────────────────────────────────────────────────────────────
    // METHOD 5 — Kume_Kaymasi
    // ─────────────────────────────────────────────────────────────────
    var method5Active: Boolean = true
    var method5Muted: Boolean = false
    var method5StreakSuccess: Int = 0
    var method5StreakFail: Int = 0
    var method5VoteMultiplier: Double = 1.0

    var method5NativePrediction1: Int = 0
    var method5NativePrediction2: Int = 0
    var method5NativeConfidence: Double = 0.0

    var method5PatternPrediction1: Int = 0
    var method5PatternPrediction2: Int = 0
    var method5PatternConfidence: Double = 0.0
    var method5PatternRefLength: Int = 0
    var method5PatternRefRegime: String = ""
    var method5PatternRefCount: Int = 0

    var method5RegimePrediction1: Int = 0
    var method5RegimePrediction2: Int = 0
    var method5RegimeConfidence: Double = 0.0

    var method5MetaPrediction1: Int = 0
    var method5MetaPrediction2: Int = 0
    var method5MetaConfidence: Double = 0.0

    var method5BlendedPrediction1: Int = 0
    var method5BlendedPrediction2: Int = 0
    var method5BlendedConfidence: Double = 0.0

    var method5FinalPrediction1: Int = 0
    var method5FinalPrediction2: Int = 0
    var method5FinalConfidence: Double = 0.0

    var method5DecisionSource: String = "NATIVE"
    var method5BiasShifted: Boolean = false

    var method5NativeCorrect: Boolean = false
    var method5PatternCorrect: Boolean = false
    var method5RegimeCorrect: Boolean = false
    var method5MetaCorrect: Boolean = false

    var method5NativeSuccessStreak: Int = 0
    var method5SupportSuccessStreak: Int = 0
    var method5SupportSharedSuccess: Boolean = false
    var method5RewardTier: String = "NONE"

    var method5Correct: Boolean = false
    var method5Accuracy: Double = 0.0

    // ─────────────────────────────────────────────────────────────────
    // METHOD 6 — Beklenti_Sapma
    // ─────────────────────────────────────────────────────────────────
    var method6Active: Boolean = true
    var method6Muted: Boolean = false
    var method6StreakSuccess: Int = 0
    var method6StreakFail: Int = 0
    var method6VoteMultiplier: Double = 1.0

    var method6NativePrediction1: Int = 0
    var method6NativePrediction2: Int = 0
    var method6NativeConfidence: Double = 0.0

    var method6PatternPrediction1: Int = 0
    var method6PatternPrediction2: Int = 0
    var method6PatternConfidence: Double = 0.0
    var method6PatternRefLength: Int = 0
    var method6PatternRefRegime: String = ""
    var method6PatternRefCount: Int = 0

    var method6RegimePrediction1: Int = 0
    var method6RegimePrediction2: Int = 0
    var method6RegimeConfidence: Double = 0.0

    var method6MetaPrediction1: Int = 0
    var method6MetaPrediction2: Int = 0
    var method6MetaConfidence: Double = 0.0

    var method6BlendedPrediction1: Int = 0
    var method6BlendedPrediction2: Int = 0
    var method6BlendedConfidence: Double = 0.0

    var method6FinalPrediction1: Int = 0
    var method6FinalPrediction2: Int = 0
    var method6FinalConfidence: Double = 0.0

    var method6DecisionSource: String = "NATIVE"
    var method6BiasShifted: Boolean = false

    var method6NativeCorrect: Boolean = false
    var method6PatternCorrect: Boolean = false
    var method6RegimeCorrect: Boolean = false
    var method6MetaCorrect: Boolean = false

    var method6NativeSuccessStreak: Int = 0
    var method6SupportSuccessStreak: Int = 0
    var method6SupportSharedSuccess: Boolean = false
    var method6RewardTier: String = "NONE"

    var method6Correct: Boolean = false
    var method6Accuracy: Double = 0.0

    // ─────────────────────────────────────────────────────────────────
    // METHOD 7 — Dalga_Tekrar
    // ─────────────────────────────────────────────────────────────────
    var method7Active: Boolean = true
    var method7Muted: Boolean = false
    var method7StreakSuccess: Int = 0
    var method7StreakFail: Int = 0
    var method7VoteMultiplier: Double = 1.0

    var method7NativePrediction1: Int = 0
    var method7NativePrediction2: Int = 0
    var method7NativeConfidence: Double = 0.0

    var method7PatternPrediction1: Int = 0
    var method7PatternPrediction2: Int = 0
    var method7PatternConfidence: Double = 0.0
    var method7PatternRefLength: Int = 0
    var method7PatternRefRegime: String = ""
    var method7PatternRefCount: Int = 0

    var method7RegimePrediction1: Int = 0
    var method7RegimePrediction2: Int = 0
    var method7RegimeConfidence: Double = 0.0

    var method7MetaPrediction1: Int = 0
    var method7MetaPrediction2: Int = 0
    var method7MetaConfidence: Double = 0.0

    var method7BlendedPrediction1: Int = 0
    var method7BlendedPrediction2: Int = 0
    var method7BlendedConfidence: Double = 0.0

    var method7FinalPrediction1: Int = 0
    var method7FinalPrediction2: Int = 0
    var method7FinalConfidence: Double = 0.0

    var method7DecisionSource: String = "NATIVE"
    var method7BiasShifted: Boolean = false

    var method7NativeCorrect: Boolean = false
    var method7PatternCorrect: Boolean = false
    var method7RegimeCorrect: Boolean = false
    var method7MetaCorrect: Boolean = false

    var method7NativeSuccessStreak: Int = 0
    var method7SupportSuccessStreak: Int = 0
    var method7SupportSharedSuccess: Boolean = false
    var method7RewardTier: String = "NONE"

    var method7Correct: Boolean = false
    var method7Accuracy: Double = 0.0

    // ─────────────────────────────────────────────────────────────────
    // METHOD 8 — Online_Gradient
    // ─────────────────────────────────────────────────────────────────
    var method8Active: Boolean = true
    var method8Muted: Boolean = false
    var method8StreakSuccess: Int = 0
    var method8StreakFail: Int = 0
    var method8VoteMultiplier: Double = 1.0

    var method8NativePrediction1: Int = 0
    var method8NativePrediction2: Int = 0
    var method8NativeConfidence: Double = 0.0

    var method8PatternPrediction1: Int = 0
    var method8PatternPrediction2: Int = 0
    var method8PatternConfidence: Double = 0.0
    var method8PatternRefLength: Int = 0
    var method8PatternRefRegime: String = ""
    var method8PatternRefCount: Int = 0

    var method8RegimePrediction1: Int = 0
    var method8RegimePrediction2: Int = 0
    var method8RegimeConfidence: Double = 0.0

    var method8MetaPrediction1: Int = 0
    var method8MetaPrediction2: Int = 0
    var method8MetaConfidence: Double = 0.0

    var method8BlendedPrediction1: Int = 0
    var method8BlendedPrediction2: Int = 0
    var method8BlendedConfidence: Double = 0.0

    var method8FinalPrediction1: Int = 0
    var method8FinalPrediction2: Int = 0
    var method8FinalConfidence: Double = 0.0

    var method8DecisionSource: String = "NATIVE"
    var method8BiasShifted: Boolean = false

    var method8NativeCorrect: Boolean = false
    var method8PatternCorrect: Boolean = false
    var method8RegimeCorrect: Boolean = false
    var method8MetaCorrect: Boolean = false

    var method8NativeSuccessStreak: Int = 0
    var method8SupportSuccessStreak: Int = 0
    var method8SupportSharedSuccess: Boolean = false
    var method8RewardTier: String = "NONE"

    var method8Correct: Boolean = false
    var method8Accuracy: Double = 0.0

    // ─────────────────────────────────────────────────────────────────
    // METHOD 9 — Bayesian
    // ─────────────────────────────────────────────────────────────────
    var method9Active: Boolean = true
    var method9Muted: Boolean = false
    var method9StreakSuccess: Int = 0
    var method9StreakFail: Int = 0
    var method9VoteMultiplier: Double = 1.0

    var method9NativePrediction1: Int = 0
    var method9NativePrediction2: Int = 0
    var method9NativeConfidence: Double = 0.0

    var method9PatternPrediction1: Int = 0
    var method9PatternPrediction2: Int = 0
    var method9PatternConfidence: Double = 0.0
    var method9PatternRefLength: Int = 0
    var method9PatternRefRegime: String = ""
    var method9PatternRefCount: Int = 0

    var method9RegimePrediction1: Int = 0
    var method9RegimePrediction2: Int = 0
    var method9RegimeConfidence: Double = 0.0

    var method9MetaPrediction1: Int = 0
    var method9MetaPrediction2: Int = 0
    var method9MetaConfidence: Double = 0.0

    var method9BlendedPrediction1: Int = 0
    var method9BlendedPrediction2: Int = 0
    var method9BlendedConfidence: Double = 0.0

    var method9FinalPrediction1: Int = 0
    var method9FinalPrediction2: Int = 0
    var method9FinalConfidence: Double = 0.0

    var method9DecisionSource: String = "NATIVE"
    var method9BiasShifted: Boolean = false

    var method9NativeCorrect: Boolean = false
    var method9PatternCorrect: Boolean = false
    var method9RegimeCorrect: Boolean = false
    var method9MetaCorrect: Boolean = false

    var method9NativeSuccessStreak: Int = 0
    var method9SupportSuccessStreak: Int = 0
    var method9SupportSharedSuccess: Boolean = false
    var method9RewardTier: String = "NONE"

    var method9Correct: Boolean = false
    var method9Accuracy: Double = 0.0

    // ─────────────────────────────────────────────────────────────────
    // METHOD 10 — Meta_Ogrenme
    // ─────────────────────────────────────────────────────────────────
    var method10Active: Boolean = true
    var method10Muted: Boolean = false
    var method10StreakSuccess: Int = 0
    var method10StreakFail: Int = 0
    var method10VoteMultiplier: Double = 1.0

    var method10NativePrediction1: Int = 0
    var method10NativePrediction2: Int = 0
    var method10NativeConfidence: Double = 0.0

    var method10PatternPrediction1: Int = 0
    var method10PatternPrediction2: Int = 0
    var method10PatternConfidence: Double = 0.0
    var method10PatternRefLength: Int = 0
    var method10PatternRefRegime: String = ""
    var method10PatternRefCount: Int = 0

    var method10RegimePrediction1: Int = 0
    var method10RegimePrediction2: Int = 0
    var method10RegimeConfidence: Double = 0.0

    var method10MetaPrediction1: Int = 0
    var method10MetaPrediction2: Int = 0
    var method10MetaConfidence: Double = 0.0

    var method10BlendedPrediction1: Int = 0
    var method10BlendedPrediction2: Int = 0
    var method10BlendedConfidence: Double = 0.0

    var method10FinalPrediction1: Int = 0
    var method10FinalPrediction2: Int = 0
    var method10FinalConfidence: Double = 0.0

    var method10DecisionSource: String = "NATIVE"
    var method10BiasShifted: Boolean = false

    var method10NativeCorrect: Boolean = false
    var method10PatternCorrect: Boolean = false
    var method10RegimeCorrect: Boolean = false
    var method10MetaCorrect: Boolean = false

    var method10NativeSuccessStreak: Int = 0
    var method10SupportSuccessStreak: Int = 0
    var method10SupportSharedSuccess: Boolean = false
    var method10RewardTier: String = "NONE"

    var method10Correct: Boolean = false
    var method10Accuracy: Double = 0.0

    // ─────────────────────────────────────────────────────────────────
    // METHOD 11 — Q_Learning
    // ─────────────────────────────────────────────────────────────────
    var method11Active: Boolean = true
    var method11Muted: Boolean = false
    var method11StreakSuccess: Int = 0
    var method11StreakFail: Int = 0
    var method11VoteMultiplier: Double = 1.0

    var method11NativePrediction1: Int = 0
    var method11NativePrediction2: Int = 0
    var method11NativeConfidence: Double = 0.0

    var method11PatternPrediction1: Int = 0
    var method11PatternPrediction2: Int = 0
    var method11PatternConfidence: Double = 0.0
    var method11PatternRefLength: Int = 0
    var method11PatternRefRegime: String = ""
    var method11PatternRefCount: Int = 0

    var method11RegimePrediction1: Int = 0
    var method11RegimePrediction2: Int = 0
    var method11RegimeConfidence: Double = 0.0

    var method11MetaPrediction1: Int = 0
    var method11MetaPrediction2: Int = 0
    var method11MetaConfidence: Double = 0.0

    var method11BlendedPrediction1: Int = 0
    var method11BlendedPrediction2: Int = 0
    var method11BlendedConfidence: Double = 0.0

    var method11FinalPrediction1: Int = 0
    var method11FinalPrediction2: Int = 0
    var method11FinalConfidence: Double = 0.0

    var method11DecisionSource: String = "NATIVE"
    var method11BiasShifted: Boolean = false

    var method11NativeCorrect: Boolean = false
    var method11PatternCorrect: Boolean = false
    var method11RegimeCorrect: Boolean = false
    var method11MetaCorrect: Boolean = false

    var method11NativeSuccessStreak: Int = 0
    var method11SupportSuccessStreak: Int = 0
    var method11SupportSharedSuccess: Boolean = false
    var method11RewardTier: String = "NONE"

    var method11Correct: Boolean = false
    var method11Accuracy: Double = 0.0

    // ─────────────────────────────────────────────────────────────────
    // METHOD 12 — Mini_Transformer
    // ─────────────────────────────────────────────────────────────────
    var method12Active: Boolean = true
    var method12Muted: Boolean = false
    var method12StreakSuccess: Int = 0
    var method12StreakFail: Int = 0
    var method12VoteMultiplier: Double = 1.0

    var method12NativePrediction1: Int = 0
    var method12NativePrediction2: Int = 0
    var method12NativeConfidence: Double = 0.0

    var method12PatternPrediction1: Int = 0
    var method12PatternPrediction2: Int = 0
    var method12PatternConfidence: Double = 0.0
    var method12PatternRefLength: Int = 0
    var method12PatternRefRegime: String = ""
    var method12PatternRefCount: Int = 0

    var method12RegimePrediction1: Int = 0
    var method12RegimePrediction2: Int = 0
    var method12RegimeConfidence: Double = 0.0

    var method12MetaPrediction1: Int = 0
    var method12MetaPrediction2: Int = 0
    var method12MetaConfidence: Double = 0.0

    var method12BlendedPrediction1: Int = 0
    var method12BlendedPrediction2: Int = 0
    var method12BlendedConfidence: Double = 0.0

    var method12FinalPrediction1: Int = 0
    var method12FinalPrediction2: Int = 0
    var method12FinalConfidence: Double = 0.0

    var method12DecisionSource: String = "NATIVE"
    var method12BiasShifted: Boolean = false

    var method12NativeCorrect: Boolean = false
    var method12PatternCorrect: Boolean = false
    var method12RegimeCorrect: Boolean = false
    var method12MetaCorrect: Boolean = false

    var method12NativeSuccessStreak: Int = 0
    var method12SupportSuccessStreak: Int = 0
    var method12SupportSharedSuccess: Boolean = false
    var method12RewardTier: String = "NONE"

    var method12Correct: Boolean = false
    var method12Accuracy: Double = 0.0

    // ─────────────────────────────────────────────────────────────────
    // METHOD 13 — Markov
    // ─────────────────────────────────────────────────────────────────
    var method13Active: Boolean = true
    var method13Muted: Boolean = false
    var method13StreakSuccess: Int = 0
    var method13StreakFail: Int = 0
    var method13VoteMultiplier: Double = 1.0

    var method13NativePrediction1: Int = 0
    var method13NativePrediction2: Int = 0
    var method13NativeConfidence: Double = 0.0

    var method13PatternPrediction1: Int = 0
    var method13PatternPrediction2: Int = 0
    var method13PatternConfidence: Double = 0.0
    var method13PatternRefLength: Int = 0
    var method13PatternRefRegime: String = ""
    var method13PatternRefCount: Int = 0

    var method13RegimePrediction1: Int = 0
    var method13RegimePrediction2: Int = 0
    var method13RegimeConfidence: Double = 0.0

    var method13MetaPrediction1: Int = 0
    var method13MetaPrediction2: Int = 0
    var method13MetaConfidence: Double = 0.0

    var method13BlendedPrediction1: Int = 0
    var method13BlendedPrediction2: Int = 0
    var method13BlendedConfidence: Double = 0.0

    var method13FinalPrediction1: Int = 0
    var method13FinalPrediction2: Int = 0
    var method13FinalConfidence: Double = 0.0

    var method13DecisionSource: String = "NATIVE"
    var method13BiasShifted: Boolean = false

    var method13NativeCorrect: Boolean = false
    var method13PatternCorrect: Boolean = false
    var method13RegimeCorrect: Boolean = false
    var method13MetaCorrect: Boolean = false

    var method13NativeSuccessStreak: Int = 0
    var method13SupportSuccessStreak: Int = 0
    var method13SupportSharedSuccess: Boolean = false
    var method13RewardTier: String = "NONE"

    var method13Correct: Boolean = false
    var method13Accuracy: Double = 0.0

    // ── CSV Trace Kolonları ──────────────────────────────────────────
    val traceColumns: LinkedHashMap<String, String> = linkedMapOf()

    // ── Trace yardımcıları ───────────────────────────────────────────
    fun setTrace(key: String, value: Any?) {
        traceColumns[key] = value?.toString()?.replace("|", "/") ?: ""
    }

    fun getTrace(key: String): String = traceColumns[key] ?: ""

    // ── Method Yardımcıları ──────────────────────────────────────────
    fun getMethodActive(index: Int): Boolean = when (index) {
        0  -> method1Active
        1  -> method2Active
        2  -> method3Active
        3  -> method4Active
        4  -> method5Active
        5  -> method6Active
        6  -> method7Active
        7  -> method8Active
        8  -> method9Active
        9  -> method10Active
        10 -> method11Active
        11 -> method12Active
        12 -> method13Active
        else -> true
    }

    fun getMethodMuted(index: Int): Boolean = when (index) {
        0  -> method1Muted
        1  -> method2Muted
        2  -> method3Muted
        3  -> method4Muted
        4  -> method5Muted
        5  -> method6Muted
        6  -> method7Muted
        7  -> method8Muted
        8  -> method9Muted
        9  -> method10Muted
        10 -> method11Muted
        11 -> method12Muted
        12 -> method13Muted
        else -> false
    }

    fun getMethodCorrect(index: Int): Boolean = when (index) {
        0  -> method1Correct
        1  -> method2Correct
        2  -> method3Correct
        3  -> method4Correct
        4  -> method5Correct
        5  -> method6Correct
        6  -> method7Correct
        7  -> method8Correct
        8  -> method9Correct
        9  -> method10Correct
        10 -> method11Correct
        11 -> method12Correct
        12 -> method13Correct
        else -> false
    }

    fun getMethodAccuracy(index: Int): Double = when (index) {
        0  -> method1Accuracy
        1  -> method2Accuracy
        2  -> method3Accuracy
        3  -> method4Accuracy
        4  -> method5Accuracy
        5  -> method6Accuracy
        6  -> method7Accuracy
        7  -> method8Accuracy
        8  -> method9Accuracy
        9  -> method10Accuracy
        10 -> method11Accuracy
        11 -> method12Accuracy
        12 -> method13Accuracy
        else -> 0.0
    }

    fun getMethodFinalPrediction1(index: Int): Int = when (index) {
        0  -> method1FinalPrediction1
        1  -> method2FinalPrediction1
        2  -> method3FinalPrediction1
        3  -> method4FinalPrediction1
        4  -> method5FinalPrediction1
        5  -> method6FinalPrediction1
        6  -> method7FinalPrediction1
        7  -> method8FinalPrediction1
        8  -> method9FinalPrediction1
        9  -> method10FinalPrediction1
        10 -> method11FinalPrediction1
        11 -> method12FinalPrediction1
        12 -> method13FinalPrediction1
        else -> 0
    }

    fun getMethodFinalPrediction2(index: Int): Int = when (index) {
        0  -> method1FinalPrediction2
        1  -> method2FinalPrediction2
        2  -> method3FinalPrediction2
        3  -> method4FinalPrediction2
        4  -> method5FinalPrediction2
        5  -> method6FinalPrediction2
        6  -> method7FinalPrediction2
        7  -> method8FinalPrediction2
        8  -> method9FinalPrediction2
        9  -> method10FinalPrediction2
        10 -> method11FinalPrediction2
        11 -> method12FinalPrediction2
        12 -> method13FinalPrediction2
        else -> 0
    }

    fun getMethodFinalConfidence(index: Int): Double = when (index) {
        0  -> method1FinalConfidence
        1  -> method2FinalConfidence
        2  -> method3FinalConfidence
        3  -> method4FinalConfidence
        4  -> method5FinalConfidence
        5  -> method6FinalConfidence
        6  -> method7FinalConfidence
        7  -> method8FinalConfidence
        8  -> method9FinalConfidence
        9  -> method10FinalConfidence
        10 -> method11FinalConfidence
        11 -> method12FinalConfidence
        12 -> method13FinalConfidence
        else -> 0.0
    }

    fun getMethodStreakSuccess(index: Int): Int = when (index) {
        0  -> method1StreakSuccess
        1  -> method2StreakSuccess
        2  -> method3StreakSuccess
        3  -> method4StreakSuccess
        4  -> method5StreakSuccess
        5  -> method6StreakSuccess
        6  -> method7StreakSuccess
        7  -> method8StreakSuccess
        8  -> method9StreakSuccess
        9  -> method10StreakSuccess
        10 -> method11StreakSuccess
        11 -> method12StreakSuccess
        12 -> method13StreakSuccess
        else -> 0
    }

    fun getMethodStreakFail(index: Int): Int = when (index) {
        0  -> method1StreakFail
        1  -> method2StreakFail
        2  -> method3StreakFail
        3  -> method4StreakFail
        4  -> method5StreakFail
        5  -> method6StreakFail
        6  -> method7StreakFail
        7  -> method8StreakFail
        8  -> method9StreakFail
        9  -> method10StreakFail
        10 -> method11StreakFail
        11 -> method12StreakFail
        12 -> method13StreakFail
        else -> 0
    }

    fun getMethodVoteMultiplier(index: Int): Double = when (index) {
        0  -> method1VoteMultiplier
        1  -> method2VoteMultiplier
        2  -> method3VoteMultiplier
        3  -> method4VoteMultiplier
        4  -> method5VoteMultiplier
        5  -> method6VoteMultiplier
        6  -> method7VoteMultiplier
        7  -> method8VoteMultiplier
        8  -> method9VoteMultiplier
        9  -> method10VoteMultiplier
        10 -> method11VoteMultiplier
        11 -> method12VoteMultiplier
        12 -> method13VoteMultiplier
        else -> 1.0
    }

    fun getMethodDecisionSource(index: Int): String = when (index) {
        0 -> method1DecisionSource
        1 -> method2DecisionSource
        2 -> method3DecisionSource
        3 -> method4DecisionSource
        4 -> method5DecisionSource
        5 -> method6DecisionSource
        6 -> method7DecisionSource
        7 -> method8DecisionSource
        8 -> method9DecisionSource
        9 -> method10DecisionSource
        10 -> method11DecisionSource
        11 -> method12DecisionSource
        12 -> method13DecisionSource
        else -> "NATIVE"
    }

    fun getMethodNativeCorrect(index: Int): Boolean = when (index) {
        0 -> method1NativeCorrect
        1 -> method2NativeCorrect
        2 -> method3NativeCorrect
        3 -> method4NativeCorrect
        4 -> method5NativeCorrect
        5 -> method6NativeCorrect
        6 -> method7NativeCorrect
        7 -> method8NativeCorrect
        8 -> method9NativeCorrect
        9 -> method10NativeCorrect
        10 -> method11NativeCorrect
        11 -> method12NativeCorrect
        12 -> method13NativeCorrect
        else -> false
    }

    fun getMethodPatternCorrect(index: Int): Boolean = when (index) {
        0 -> method1PatternCorrect
        1 -> method2PatternCorrect
        2 -> method3PatternCorrect
        3 -> method4PatternCorrect
        4 -> method5PatternCorrect
        5 -> method6PatternCorrect
        6 -> method7PatternCorrect
        7 -> method8PatternCorrect
        8 -> method9PatternCorrect
        9 -> method10PatternCorrect
        10 -> method11PatternCorrect
        11 -> method12PatternCorrect
        12 -> method13PatternCorrect
        else -> false
    }

    fun getMethodRegimeCorrect(index: Int): Boolean = when (index) {
        0 -> method1RegimeCorrect
        1 -> method2RegimeCorrect
        2 -> method3RegimeCorrect
        3 -> method4RegimeCorrect
        4 -> method5RegimeCorrect
        5 -> method6RegimeCorrect
        6 -> method7RegimeCorrect
        7 -> method8RegimeCorrect
        8 -> method9RegimeCorrect
        9 -> method10RegimeCorrect
        10 -> method11RegimeCorrect
        11 -> method12RegimeCorrect
        12 -> method13RegimeCorrect
        else -> false
    }

    fun getMethodMetaCorrect(index: Int): Boolean = when (index) {
        0 -> method1MetaCorrect
        1 -> method2MetaCorrect
        2 -> method3MetaCorrect
        3 -> method4MetaCorrect
        4 -> method5MetaCorrect
        5 -> method6MetaCorrect
        6 -> method7MetaCorrect
        7 -> method8MetaCorrect
        8 -> method9MetaCorrect
        9 -> method10MetaCorrect
        10 -> method11MetaCorrect
        11 -> method12MetaCorrect
        12 -> method13MetaCorrect
        else -> false
    }

    fun getMethodNativeSuccessStreak(index: Int): Int = when (index) {
        0 -> method1NativeSuccessStreak
        1 -> method2NativeSuccessStreak
        2 -> method3NativeSuccessStreak
        3 -> method4NativeSuccessStreak
        4 -> method5NativeSuccessStreak
        5 -> method6NativeSuccessStreak
        6 -> method7NativeSuccessStreak
        7 -> method8NativeSuccessStreak
        8 -> method9NativeSuccessStreak
        9 -> method10NativeSuccessStreak
        10 -> method11NativeSuccessStreak
        11 -> method12NativeSuccessStreak
        12 -> method13NativeSuccessStreak
        else -> 0
    }

    fun getMethodSupportSuccessStreak(index: Int): Int = when (index) {
        0 -> method1SupportSuccessStreak
        1 -> method2SupportSuccessStreak
        2 -> method3SupportSuccessStreak
        3 -> method4SupportSuccessStreak
        4 -> method5SupportSuccessStreak
        5 -> method6SupportSuccessStreak
        6 -> method7SupportSuccessStreak
        7 -> method8SupportSuccessStreak
        8 -> method9SupportSuccessStreak
        9 -> method10SupportSuccessStreak
        10 -> method11SupportSuccessStreak
        11 -> method12SupportSuccessStreak
        12 -> method13SupportSuccessStreak
        else -> 0
    }

    fun getMethodSupportSharedSuccess(index: Int): Boolean = when (index) {
        0 -> method1SupportSharedSuccess
        1 -> method2SupportSharedSuccess
        2 -> method3SupportSharedSuccess
        3 -> method4SupportSharedSuccess
        4 -> method5SupportSharedSuccess
        5 -> method6SupportSharedSuccess
        6 -> method7SupportSharedSuccess
        7 -> method8SupportSharedSuccess
        8 -> method9SupportSharedSuccess
        9 -> method10SupportSharedSuccess
        10 -> method11SupportSharedSuccess
        11 -> method12SupportSharedSuccess
        12 -> method13SupportSharedSuccess
        else -> false
    }

    fun getMethodRewardTier(index: Int): String = when (index) {
        0 -> method1RewardTier
        1 -> method2RewardTier
        2 -> method3RewardTier
        3 -> method4RewardTier
        4 -> method5RewardTier
        5 -> method6RewardTier
        6 -> method7RewardTier
        7 -> method8RewardTier
        8 -> method9RewardTier
        9 -> method10RewardTier
        10 -> method11RewardTier
        11 -> method12RewardTier
        12 -> method13RewardTier
        else -> "NONE"
    }

    fun setMethodCore(
        index: Int,
        active: Boolean,
        muted: Boolean,
        streakSuccess: Int,
        streakFail: Int,
        voteMultiplier: Double,
        finalPrediction1: Int,
        finalPrediction2: Int,
        finalConfidence: Double,
        correct: Boolean,
        accuracy: Double
    ) {
        when (index) {
            0 -> {
                method1Active = active
                method1Muted = muted
                method1StreakSuccess = streakSuccess
                method1StreakFail = streakFail
                method1VoteMultiplier = voteMultiplier
                method1FinalPrediction1 = finalPrediction1
                method1FinalPrediction2 = finalPrediction2
                method1FinalConfidence = finalConfidence
                method1Correct = correct
                method1Accuracy = accuracy
            }
            1 -> {
                method2Active = active
                method2Muted = muted
                method2StreakSuccess = streakSuccess
                method2StreakFail = streakFail
                method2VoteMultiplier = voteMultiplier
                method2FinalPrediction1 = finalPrediction1
                method2FinalPrediction2 = finalPrediction2
                method2FinalConfidence = finalConfidence
                method2Correct = correct
                method2Accuracy = accuracy
            }
            2 -> {
                method3Active = active
                method3Muted = muted
                method3StreakSuccess = streakSuccess
                method3StreakFail = streakFail
                method3VoteMultiplier = voteMultiplier
                method3FinalPrediction1 = finalPrediction1
                method3FinalPrediction2 = finalPrediction2
                method3FinalConfidence = finalConfidence
                method3Correct = correct
                method3Accuracy = accuracy
            }
            3 -> {
                method4Active = active
                method4Muted = muted
                method4StreakSuccess = streakSuccess
                method4StreakFail = streakFail
                method4VoteMultiplier = voteMultiplier
                method4FinalPrediction1 = finalPrediction1
                method4FinalPrediction2 = finalPrediction2
                method4FinalConfidence = finalConfidence
                method4Correct = correct
                method4Accuracy = accuracy
            }
            4 -> {
                method5Active = active
                method5Muted = muted
                method5StreakSuccess = streakSuccess
                method5StreakFail = streakFail
                method5VoteMultiplier = voteMultiplier
                method5FinalPrediction1 = finalPrediction1
                method5FinalPrediction2 = finalPrediction2
                method5FinalConfidence = finalConfidence
                method5Correct = correct
                method5Accuracy = accuracy
            }
            5 -> {
                method6Active = active
                method6Muted = muted
                method6StreakSuccess = streakSuccess
                method6StreakFail = streakFail
                method6VoteMultiplier = voteMultiplier
                method6FinalPrediction1 = finalPrediction1
                method6FinalPrediction2 = finalPrediction2
                method6FinalConfidence = finalConfidence
                method6Correct = correct
                method6Accuracy = accuracy
            }
            6 -> {
                method7Active = active
                method7Muted = muted
                method7StreakSuccess = streakSuccess
                method7StreakFail = streakFail
                method7VoteMultiplier = voteMultiplier
                method7FinalPrediction1 = finalPrediction1
                method7FinalPrediction2 = finalPrediction2
                method7FinalConfidence = finalConfidence
                method7Correct = correct
                method7Accuracy = accuracy
            }
            7 -> {
                method8Active = active
                method8Muted = muted
                method8StreakSuccess = streakSuccess
                method8StreakFail = streakFail
                method8VoteMultiplier = voteMultiplier
                method8FinalPrediction1 = finalPrediction1
                method8FinalPrediction2 = finalPrediction2
                method8FinalConfidence = finalConfidence
                method8Correct = correct
                method8Accuracy = accuracy
            }
            8 -> {
                method9Active = active
                method9Muted = muted
                method9StreakSuccess = streakSuccess
                method9StreakFail = streakFail
                method9VoteMultiplier = voteMultiplier
                method9FinalPrediction1 = finalPrediction1
                method9FinalPrediction2 = finalPrediction2
                method9FinalConfidence = finalConfidence
                method9Correct = correct
                method9Accuracy = accuracy
            }
            9 -> {
                method10Active = active
                method10Muted = muted
                method10StreakSuccess = streakSuccess
                method10StreakFail = streakFail
                method10VoteMultiplier = voteMultiplier
                method10FinalPrediction1 = finalPrediction1
                method10FinalPrediction2 = finalPrediction2
                method10FinalConfidence = finalConfidence
                method10Correct = correct
                method10Accuracy = accuracy
            }
            10 -> {
                method11Active = active
                method11Muted = muted
                method11StreakSuccess = streakSuccess
                method11StreakFail = streakFail
                method11VoteMultiplier = voteMultiplier
                method11FinalPrediction1 = finalPrediction1
                method11FinalPrediction2 = finalPrediction2
                method11FinalConfidence = finalConfidence
                method11Correct = correct
                method11Accuracy = accuracy
            }
            11 -> {
                method12Active = active
                method12Muted = muted
                method12StreakSuccess = streakSuccess
                method12StreakFail = streakFail
                method12VoteMultiplier = voteMultiplier
                method12FinalPrediction1 = finalPrediction1
                method12FinalPrediction2 = finalPrediction2
                method12FinalConfidence = finalConfidence
                method12Correct = correct
                method12Accuracy = accuracy
            }
            12 -> {
                method13Active = active
                method13Muted = muted
                method13StreakSuccess = streakSuccess
                method13StreakFail = streakFail
                method13VoteMultiplier = voteMultiplier
                method13FinalPrediction1 = finalPrediction1
                method13FinalPrediction2 = finalPrediction2
                method13FinalConfidence = finalConfidence
                method13Correct = correct
                method13Accuracy = accuracy
            }
        }
    }

    fun setMethodDecisionDetail(
        index: Int,
        decisionSource: String,
        nativeCorrect: Boolean,
        patternCorrect: Boolean,
        regimeCorrect: Boolean,
        metaCorrect: Boolean,
        nativeSuccessStreak: Int,
        supportSuccessStreak: Int,
        supportSharedSuccess: Boolean,
        rewardTier: String
    ) {
        when (index) {
            0 -> {
                method1DecisionSource = decisionSource
                method1NativeCorrect = nativeCorrect
                method1PatternCorrect = patternCorrect
                method1RegimeCorrect = regimeCorrect
                method1MetaCorrect = metaCorrect
                method1NativeSuccessStreak = nativeSuccessStreak
                method1SupportSuccessStreak = supportSuccessStreak
                method1SupportSharedSuccess = supportSharedSuccess
                method1RewardTier = rewardTier
            }
            1 -> {
                method2DecisionSource = decisionSource
                method2NativeCorrect = nativeCorrect
                method2PatternCorrect = patternCorrect
                method2RegimeCorrect = regimeCorrect
                method2MetaCorrect = metaCorrect
                method2NativeSuccessStreak = nativeSuccessStreak
                method2SupportSuccessStreak = supportSuccessStreak
                method2SupportSharedSuccess = supportSharedSuccess
                method2RewardTier = rewardTier
            }
            2 -> {
                method3DecisionSource = decisionSource
                method3NativeCorrect = nativeCorrect
                method3PatternCorrect = patternCorrect
                method3RegimeCorrect = regimeCorrect
                method3MetaCorrect = metaCorrect
                method3NativeSuccessStreak = nativeSuccessStreak
                method3SupportSuccessStreak = supportSuccessStreak
                method3SupportSharedSuccess = supportSharedSuccess
                method3RewardTier = rewardTier
            }
            3 -> {
                method4DecisionSource = decisionSource
                method4NativeCorrect = nativeCorrect
                method4PatternCorrect = patternCorrect
                method4RegimeCorrect = regimeCorrect
                method4MetaCorrect = metaCorrect
                method4NativeSuccessStreak = nativeSuccessStreak
                method4SupportSuccessStreak = supportSuccessStreak
                method4SupportSharedSuccess = supportSharedSuccess
                method4RewardTier = rewardTier
            }
            4 -> {
                method5DecisionSource = decisionSource
                method5NativeCorrect = nativeCorrect
                method5PatternCorrect = patternCorrect
                method5RegimeCorrect = regimeCorrect
                method5MetaCorrect = metaCorrect
                method5NativeSuccessStreak = nativeSuccessStreak
                method5SupportSuccessStreak = supportSuccessStreak
                method5SupportSharedSuccess = supportSharedSuccess
                method5RewardTier = rewardTier
            }
            5 -> {
                method6DecisionSource = decisionSource
                method6NativeCorrect = nativeCorrect
                method6PatternCorrect = patternCorrect
                method6RegimeCorrect = regimeCorrect
                method6MetaCorrect = metaCorrect
                method6NativeSuccessStreak = nativeSuccessStreak
                method6SupportSuccessStreak = supportSuccessStreak
                method6SupportSharedSuccess = supportSharedSuccess
                method6RewardTier = rewardTier
            }
            6 -> {
                method7DecisionSource = decisionSource
                method7NativeCorrect = nativeCorrect
                method7PatternCorrect = patternCorrect
                method7RegimeCorrect = regimeCorrect
                method7MetaCorrect = metaCorrect
                method7NativeSuccessStreak = nativeSuccessStreak
                method7SupportSuccessStreak = supportSuccessStreak
                method7SupportSharedSuccess = supportSharedSuccess
                method7RewardTier = rewardTier
            }
            7 -> {
                method8DecisionSource = decisionSource
                method8NativeCorrect = nativeCorrect
                method8PatternCorrect = patternCorrect
                method8RegimeCorrect = regimeCorrect
                method8MetaCorrect = metaCorrect
                method8NativeSuccessStreak = nativeSuccessStreak
                method8SupportSuccessStreak = supportSuccessStreak
                method8SupportSharedSuccess = supportSharedSuccess
                method8RewardTier = rewardTier
            }
            8 -> {
                method9DecisionSource = decisionSource
                method9NativeCorrect = nativeCorrect
                method9PatternCorrect = patternCorrect
                method9RegimeCorrect = regimeCorrect
                method9MetaCorrect = metaCorrect
                method9NativeSuccessStreak = nativeSuccessStreak
                method9SupportSuccessStreak = supportSuccessStreak
                method9SupportSharedSuccess = supportSharedSuccess
                method9RewardTier = rewardTier
            }
            9 -> {
                method10DecisionSource = decisionSource
                method10NativeCorrect = nativeCorrect
                method10PatternCorrect = patternCorrect
                method10RegimeCorrect = regimeCorrect
                method10MetaCorrect = metaCorrect
                method10NativeSuccessStreak = nativeSuccessStreak
                method10SupportSuccessStreak = supportSuccessStreak
                method10SupportSharedSuccess = supportSharedSuccess
                method10RewardTier = rewardTier
            }
            10 -> {
                method11DecisionSource = decisionSource
                method11NativeCorrect = nativeCorrect
                method11PatternCorrect = patternCorrect
                method11RegimeCorrect = regimeCorrect
                method11MetaCorrect = metaCorrect
                method11NativeSuccessStreak = nativeSuccessStreak
                method11SupportSuccessStreak = supportSuccessStreak
                method11SupportSharedSuccess = supportSharedSuccess
                method11RewardTier = rewardTier
            }
            11 -> {
                method12DecisionSource = decisionSource
                method12NativeCorrect = nativeCorrect
                method12PatternCorrect = patternCorrect
                method12RegimeCorrect = regimeCorrect
                method12MetaCorrect = metaCorrect
                method12NativeSuccessStreak = nativeSuccessStreak
                method12SupportSuccessStreak = supportSuccessStreak
                method12SupportSharedSuccess = supportSharedSuccess
                method12RewardTier = rewardTier
            }
            12 -> {
                method13DecisionSource = decisionSource
                method13NativeCorrect = nativeCorrect
                method13PatternCorrect = patternCorrect
                method13RegimeCorrect = regimeCorrect
                method13MetaCorrect = metaCorrect
                method13NativeSuccessStreak = nativeSuccessStreak
                method13SupportSuccessStreak = supportSuccessStreak
                method13SupportSharedSuccess = supportSharedSuccess
                method13RewardTier = rewardTier
            }
        }
    }

    // ── Kopya ────────────────────────────────────────────────────────
    fun copyMutable(): DataEntry {
        val copy = DataEntry()

        copy.id = id
        copy.timestamp = timestamp
        copy.value = value
        copy.previousPredictionId = previousPredictionId
        copy.dataCount = dataCount

        copy.ensemblePrediction1 = ensemblePrediction1
        copy.ensemblePrediction2 = ensemblePrediction2
        copy.ensembleIsDouble = ensembleIsDouble
        copy.ensembleConfidence = ensembleConfidence
        copy.ensemblePrimary1Correct = ensemblePrimary1Correct
        copy.ensemblePrimary2Correct = ensemblePrimary2Correct
        copy.ensembleTotalCorrect = ensembleTotalCorrect
        copy.ensemblePrimary1Accuracy = ensemblePrimary1Accuracy
        copy.ensemblePrimary2Accuracy = ensemblePrimary2Accuracy
        copy.ensembleTotalAccuracy = ensembleTotalAccuracy

        copy.combinedPrediction1 = combinedPrediction1
        copy.combinedPrediction2 = combinedPrediction2
        copy.combinedIsDouble = combinedIsDouble
        copy.combinedConfidence = combinedConfidence
        copy.combinedPrimary1Correct = combinedPrimary1Correct
        copy.combinedPrimary2Correct = combinedPrimary2Correct
        copy.combinedTotalCorrect = combinedTotalCorrect
        copy.combinedPrimary1Accuracy = combinedPrimary1Accuracy
        copy.combinedPrimary2Accuracy = combinedPrimary2Accuracy
        copy.combinedTotalAccuracy = combinedTotalAccuracy

        copy.kalipPrediction1 = kalipPrediction1
        copy.kalipPrediction2 = kalipPrediction2
        copy.kalipIsDouble = kalipIsDouble
        copy.kalipConfidence = kalipConfidence
        copy.kalipPrimary1Correct = kalipPrimary1Correct
        copy.kalipPrimary2Correct = kalipPrimary2Correct
        copy.kalipTotalCorrect = kalipTotalCorrect
        copy.kalipPrimary1Accuracy = kalipPrimary1Accuracy
        copy.kalipPrimary2Accuracy = kalipPrimary2Accuracy
        copy.kalipTotalAccuracy = kalipTotalAccuracy

        copy.sideStandardPrediction = sideStandardPrediction
        copy.sideStandardCorrect = sideStandardCorrect
        copy.sideStandardDoubleCorrect = sideStandardDoubleCorrect
        copy.sideStandardAccuracy = sideStandardAccuracy
        copy.sideStandardDoubleAccuracy = sideStandardDoubleAccuracy

        copy.sideRegimePrediction = sideRegimePrediction
        copy.sideRegimeCorrect = sideRegimeCorrect
        copy.sideRegimeDoubleCorrect = sideRegimeDoubleCorrect
        copy.sideRegimeAccuracy = sideRegimeAccuracy
        copy.sideRegimeDoubleAccuracy = sideRegimeDoubleAccuracy

        copy.sideDisplayPrediction = sideDisplayPrediction
        copy.sideFinalCorrect = sideFinalCorrect
        copy.sideFinalDoubleCorrect = sideFinalDoubleCorrect
        copy.sideFinalAccuracy = sideFinalAccuracy
        copy.sideFinalDoubleAccuracy = sideFinalDoubleAccuracy

        copy.currentRegime = currentRegime
        copy.previousRegime = previousRegime
        copy.regimeStableCount = regimeStableCount
        copy.matchedPatternLength = matchedPatternLength
        copy.matchedPatternCount = matchedPatternCount
        copy.matchedPatternRegime = matchedPatternRegime
        copy.regimeSimilarityScore = regimeSimilarityScore
        copy.chaosScore = chaosScore
        copy.patternBreakLength = patternBreakLength
        copy.anomalyFlags = anomalyFlags
        copy.confidenceAdjusted = confidenceAdjusted
        copy.activeModelCount = activeModelCount

        copy.mutedModels = mutedModels
        copy.rewardedModels = rewardedModels
        copy.returnedModels = returnedModels
        copy.fallbackModel = fallbackModel
        copy.decisionReason = decisionReason

        copy.standartYanTahminTeklikCiftlikGuven = standartYanTahminTeklikCiftlikGuven
        copy.standartYanTahminKucuklukBuyuklukGuven = standartYanTahminKucuklukBuyuklukGuven
        copy.rejimYanTahminTeklikCiftlikGuven = rejimYanTahminTeklikCiftlikGuven
        copy.rejimYanTahminKucuklukBuyuklukGuven = rejimYanTahminKucuklukBuyuklukGuven
        copy.yanTahminFinalSecimKaynagi = yanTahminFinalSecimKaynagi
        copy.ensembleKararDetayi = ensembleKararDetayi
        copy.kaosSkoruDetayi = kaosSkoruDetayi
        copy.kirilanKalipDetayi = kirilanKalipDetayi
        copy.eslesenKalipDetayi = eslesenKalipDetayi
        copy.rejimGecisTahmini = rejimGecisTahmini
        copy.rejimGecisDegerTahmini = rejimGecisDegerTahmini
        copy.meclisDurumDetayi = meclisDurumDetayi

        for (i in 0 until METHOD_COUNT) {
            copy.setMethodCore(
                index = i,
                active = getMethodActive(i),
                muted = getMethodMuted(i),
                streakSuccess = getMethodStreakSuccess(i),
                streakFail = getMethodStreakFail(i),
                voteMultiplier = getMethodVoteMultiplier(i),
                finalPrediction1 = getMethodFinalPrediction1(i),
                finalPrediction2 = getMethodFinalPrediction2(i),
                finalConfidence = getMethodFinalConfidence(i),
                correct = getMethodCorrect(i),
                accuracy = getMethodAccuracy(i)
            )

            copy.setMethodDecisionDetail(
                index = i,
                decisionSource = getMethodDecisionSource(i),
                nativeCorrect = getMethodNativeCorrect(i),
                patternCorrect = getMethodPatternCorrect(i),
                regimeCorrect = getMethodRegimeCorrect(i),
                metaCorrect = getMethodMetaCorrect(i),
                nativeSuccessStreak = getMethodNativeSuccessStreak(i),
                supportSuccessStreak = getMethodSupportSuccessStreak(i),
                supportSharedSuccess = getMethodSupportSharedSuccess(i),
                rewardTier = getMethodRewardTier(i)
            )
        }

        copy.traceColumns.putAll(traceColumns)
        return copy
    }

    companion object {
        const val METHOD_COUNT = 13
        const val INTERNAL_THRESHOLD = 5
        const val SILENT_THRESHOLD = 50
        const val MIN_ACTIVE_MODELS = 6

        val METHOD_NAMES = listOf(
            "Kalip_Arama",
            "Rejim_Tespiti",
            "Fark_Dizisi",
            "Ayna_Kalip",
            "Kume_Kaymasi",
            "Beklenti_Sapma",
            "Dalga_Tekrar",
            "Online_Gradient",
            "Bayesian",
            "Meta_Ogrenme",
            "Q_Learning",
            "Mini_Transformer",
            "Markov"
        )

        val COMBINED_METHOD_INDICES = listOf(0, 5, 7, 8, 12)

        val LEARNING_METHOD_INDICES = listOf(7, 8, 9, 10, 11, 12)

        val METHOD_GROUP_FIT = mapOf(
            0  to listOf("TEKRAR", "YON"),
            1  to listOf("TEKRAR", "YON", "SALINIMM"),
            2  to listOf("YON", "SALINIMM"),
            3  to listOf("TEKRAR", "SALINIMM"),
            4  to listOf("YON", "SALINIMM"),
            5  to listOf("TEKRAR", "YON"),
            6  to listOf("TEKRAR", "SALINIMM"),
            7  to listOf("YON", "KAOS"),
            8  to listOf("KAOS", "TEKRAR"),
            9  to listOf("TEKRAR", "YON", "KAOS"),
            10 to listOf("KAOS", "SALINIMM"),
            11 to listOf("YON", "SALINIMM", "KAOS"),
            12 to listOf("TEKRAR", "SALINIMM", "YON", "KAOS")
        )

        val METHOD_REGIME_FIT = mapOf(
            0  to listOf("REGULAR", "REPEAT"),
            1  to listOf("REGULAR", "WAVE", "REPEAT"),
            2  to listOf("WAVE", "REGULAR"),
            3  to listOf("REGULAR", "REPEAT", "MIXED"),
            4  to listOf("REGULAR", "WAVE"),
            5  to listOf("REGULAR", "MIXED"),
            6  to listOf("WAVE", "REPEAT"),
            7  to listOf("WAVE", "CHAOS", "REPEAT"),
            8  to listOf("CHAOS", "MIXED", "REGULAR"),
            9  to listOf("REGULAR", "MIXED", "CHAOS"),
            10 to listOf("CHAOS", "MIXED", "WAVE"),
            11 to listOf("REGULAR", "WAVE", "CHAOS"),
            12 to listOf("REGULAR", "CHAOS", "WAVE", "REPEAT", "MIXED")
        )

        val TRACE_HEADERS: List<String> = buildList {
            add("Standart_Yan_Tahmin_Teklik_Ciftlik_Guven")
            add("Standart_Yan_Tahmin_Kucukluk_Buyukluk_Guven")
            add("Rejim_Yan_Tahmin_Teklik_Ciftlik_Guven")
            add("Rejim_Yan_Tahmin_Kucukluk_Buyukluk_Guven")
            add("Yan_Tahmin_Final_Secim_Kaynagi")
            add("Ensemble_Karar_Detayi")
            add("Kaos_Skoru_Detayi")
            add("Kirilan_Kalip_Detayi")
            add("Eslesen_Kalip_Detayi")
            add("Rejim_Gecis_Tahmini")
            add("Rejim_Gecis_Deger_Tahmini")
            add("Meclis_Durum_Detayi")

            // EKLENEN GLOBAL METRIKLER
            add("model_konsensus_orani")
            add("ayni_final_tahmin_yapan_model_sayisi")
            add("ayni_kaynakla_karar_veren_model_sayisi")

            for (name in METHOD_NAMES) {
                add("${name}_native_tahmin1")
                add("${name}_native_tahmin2")
                add("${name}_native_guven")

                add("${name}_kalip_tahmin1")
                add("${name}_kalip_tahmin2")
                add("${name}_kalip_guven")
                add("${name}_kalip_ref_uzunluk")
                add("${name}_kalip_ref_rejim")
                add("${name}_kalip_ref_eslesme")

                add("${name}_regime_tahmin1")
                add("${name}_regime_tahmin2")
                add("${name}_regime_guven")

                add("${name}_meta_tahmin1")
                add("${name}_meta_tahmin2")
                add("${name}_meta_guven")

                add("${name}_blended_tahmin1")
                add("${name}_blended_tahmin2")
                add("${name}_blended_guven")

                add("${name}_final_secim_kaynagi")
                add("${name}_basari_kaynagi") // YENİ
                add("${name}_native_dogru")
                add("${name}_kalip_dogru")
                add("${name}_rejim_dogru")
                add("${name}_meta_dogru")
                add("${name}_native_basari_seri")
                add("${name}_destek_basari_seri")
                add("${name}_destek_paylasimli_basari")
                add("${name}_odul_kademesi")
                add("${name}_bias_kaydirildi")
            }
        }
    }
}