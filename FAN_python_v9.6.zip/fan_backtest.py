#!/usr/bin/env python3
"""
FAN Python Prototipi — v0.1  (Saf Python, numpy opsiyonel)
---------------------------------------------------------
- Aynı mantık: online öğrenme, her veri geldikçe sadece o ana kadar olan veriyi kullanarak
  geleceği tahmin eder (gelecekten bilgi sızması YOK, gerçek kullanım gibi simüle eder).
- Stratejiler:
    1. KALIP (PatternMatcher): Kotlin v7.2'deki dinamik uzunluklu kalıp araması BİREBİR aynı
    2. Markov 1 / 2 / 3. derece
    3. n-gram (tam sayı, 1..5)
    4. Delta (fark dizisi)
    5. Streak kırılması
    6. Bias (son 60 verinin kayan ağırlıklı eğilimi)
    7. PPM (Prediction by Partial Matching — bilgi-teorik optimal n-gram)
    8. Binary axis (Odd/Even + Small/Big için ikili oylama, tıpkı Kotlin SidePrediction)
    9. BinyPattern (ikili eksen pattern, tıpkı Kotlin v7.1'deki 9. yöntem)
- Ensemble: Hedge Algorithm (Prediction with Expert Advice — teorik olarak sınırlı pişmanlık garantili)
- Güven: Platt-style online calibration ile gerçek olasılığa yakın tutulur.
- Yan tahmin: Tıpkı v7.2 — her zaman ya "T•B" ya "T•B=N", "--" yok.
- Hedef: Kotlin v7.2'yi geçmek ama kalıp aramayı bozmamak.
"""

import sys
import math
import random
import json
from collections import defaultdict, deque

# ───────────────────────────────────────────────────────────────────
# 1. YARDIMCILAR
# ───────────────────────────────────────────────────────────────────

def recency_factor(distance, total_size, decay=3.0):
    """Üstel recency — yeni veriler daha ağırlıklı (Kotlin ile aynı)."""
    if total_size <= 1:
        return 1.0
    return math.exp(-decay * distance / total_size)

def recency_factor_side(distance, total_size):
    return math.exp(-3.5 * distance / total_size)

def normalize(d, floor=0.02, cap=0.94):
    t = sum(d.values())
    if t <= 0:
        return {k: 0.25 for k in (1, 2, 3, 4)}
    return {k: max(floor, min(cap, v / t)) for k, v in d.items()}

def normalize_binary(d):
    t = sum(d.values())
    if t <= 0:
        return {0: 0.5, 1: 0.5}
    p1 = max(1-0.94, min(0.94, d[1] / t))
    return {0: 1-p1, 1: p1}


# ───────────────────────────────────────────────────────────────────
# 2. STRATEJİLER (her biri .predict(history) → {1:p1, 2:p2, 3:p3, 4:p4},
#    .update(history, actual) → özünü günceller)
# ───────────────────────────────────────────────────────────────────

class MarkovStrategy:
    """Markov zinciri order-1,2,3 birleşimi."""
    def __init__(self, max_order=3):
        self.max_order = max_order
        self.models = [defaultdict(lambda: defaultdict(float)) for _ in range(max_order+1)]
        self.name = f"markov{max_order}"

    def predict(self, h):
        votes = {1:0.0,2:0.0,3:0.0,4:0.0}
        tw = 0.0
        for order in range(1, self.max_order+1):
            if len(h) < order: continue
            ctx = tuple(h[-order:])
            cnts = self.models[order][ctx]
            t = sum(cnts.values())
            if t < 1.5: continue
            w = 1.0 / order
            for k,v in cnts.items():
                votes[k] += w * v / t
            tw += w
        if tw < 0.3:
            return {k:0.25 for k in (1,2,3,4)}
        return normalize(votes)

    def update(self, h, actual):
        n = len(h)
        for order in range(1, self.max_order+1):
            if n < order: continue
            ctx = tuple(h[-order:])
            dist = n - order - 1
            r = recency_factor(dist, n)
            self.models[order][ctx][actual] += r


class NgramStrategy:
    """Tam-değer n-gram (1..5)."""
    def __init__(self, max_n=5):
        self.max_n = max_n
        self.name = "full_ngram"

    def predict(self, h):
        votes = {1:0.0,2:0.0,3:0.0,4:0.0}
        tw = 0.0
        n_hist = len(h)
        for n in range(1, self.max_n+1):
            if n_hist < n+2: continue
            pat = tuple(h[-n:])
            cnts = defaultdict(float)
            mc = 0
            for j in range(n_hist - n):
                if tuple(h[j:j+n]) == pat:
                    nx = h[j+n]
                    if nx in (1,2,3,4):
                        r = recency_factor(n_hist - (j+n), n_hist)
                        cnts[nx] += r
                        mc += 1
                        if mc >= 30: break
            t = sum(cnts.values())
            if t >= 1.5:
                w = (6-n)*0.22 + min(t/8.0, 0.7)
                for k,v in cnts.items():
                    votes[k] += w * v / t
                tw += w
        if tw < 0.5:
            return {k:0.25 for k in (1,2,3,4)}
        return normalize(votes)

    def update(self, h, actual):
        pass  # predict her seferinde tüm geçmişi tarıyor, update'e ihtiyaç yok


class PatternStrategy:
    """Kalıp Arama — Kotlin PatternMatcher BİREBİR aynı mantık."""
    def __init__(self):
        self.name = "kalip"

    @staticmethod
    def max_pattern_length(n):
        if n <= 50: return 10
        if n <= 100: return 15
        return 25

    @staticmethod
    def find_patterns(h):
        n = len(h)
        if n < 2: return []
        results = []
        max_len = min(PatternStrategy.max_pattern_length(n), n-1)
        MAX_SEARCH = 2000
        MAX_MATCHES = 30
        for length in range(max_len, 1, -1):
            pat = tuple(h[-length:])
            window = h[-length:][:0]  # boş
            search_start = max(0, (n-length) - MAX_SEARCH)
            positions = []
            for j in range(search_start, n-length):
                if tuple(h[j:j+length]) == pat:
                    positions.append(j)
                    if len(positions) >= MAX_MATCHES:
                        break
            if positions:
                results.append((length, positions))
        return results

    def predict(self, h):
        votes = {1:0.0,2:0.0,3:0.0,4:0.0}
        n = len(h)
        patterns = self.find_patterns(h)
        for length, positions in patterns:
            base_w = length / 12.0
            bonus = 1.5 if length >= 10 else (1.2 if length >= 6 else 1.0)
            w = base_w * bonus
            for idx, pos in enumerate(positions):
                after = pos + length
                if after < n - length:
                    nx = h[after]
                    if nx in (1,2,3,4):
                        r = recency_factor(n - after, n, decay=3.0)
                        votes[nx] += w * r
                        votes[nx] += (1.5 / (idx+1)) * r * 0.6
        t = sum(votes.values())
        if t == 0:
            return {k:0.25 for k in (1,2,3,4)}
        return normalize(votes)

    def update(self, h, actual):
        pass


class DeltaStrategy:
    """Fark dizisi tabanlı."""
    def __init__(self):
        self.name = "delta"

    def predict(self, h):
        if len(h) < 4:
            return {k:0.25 for k in (1,2,3,4)}
        deltas = []
        for a,b in zip(h[:-1], h[1:]):
            d = b - a
            if d > 3: d -= 4
            elif d < -3: d += 4
            deltas.append(d)
        votes = {1:0.0,2:0.0,3:0.0,4:0.0}
        tw = 0.0
        last = h[-1]
        for n in range(2, min(7, len(deltas))+1):
            pat = tuple(deltas[-n:])
            for j in range(len(deltas)-n):
                if tuple(deltas[j:j+n]) == pat:
                    nd = deltas[j+n]
                    pred = ((last-1 + nd) % 4) + 1
                    w = n / 10.0
                    r = recency_factor(len(deltas)-(j+n), len(deltas))
                    votes[pred] += w*r
                    tw += w*r
        if tw < 0.5:
            return {k:0.25 for k in (1,2,3,4)}
        return normalize(votes)

    def update(self, h, actual): pass


class StreakStrategy:
    """Seri kırılması."""
    def __init__(self):
        self.name = "streak"

    def predict(self, h):
        if len(h) < 3:
            return {k:0.25 for k in (1,2,3,4)}
        v = h[-1]
        streak = 1
        for x in reversed(h[:-1]):
            if x == v: streak += 1
            else: break
        votes = {1:0.0,2:0.0,3:0.0,4:0.0}
        for i in range(streak, len(h)):
            j = i-1; c = 0
            while j >= 0 and h[j] == v:
                c += 1; j -= 1
            if c == streak and i < len(h):
                nx = h[i]
                if nx in (1,2,3,4) and nx != v:
                    r = recency_factor(len(h)-i, len(h))
                    votes[nx] += r
        t = sum(votes.values())
        if t < 1.0:
            cnts = defaultdict(float)
            for j in range(len(h)-1):
                if h[j] == v:
                    nx = h[j+1]
                    if nx in (1,2,3,4) and nx != v:
                        cnts[nx] += recency_factor(len(h)-(j+1), len(h))
            tt = sum(cnts.values())
            if tt < 0.5: return {k:0.25 for k in (1,2,3,4)}
            for k,vv in cnts.items():
                votes[k] += vv/tt * 0.7
            return normalize(votes)
        return normalize(votes)

    def update(self, h, actual): pass


class BiasStrategy:
    """Son 60 verinin ağırlıklı eğilimi."""
    def __init__(self):
        self.name = "bias"

    def predict(self, h):
        recent = h[-min(60, len(h)):]
        if len(recent) < 10:
            return {k:0.25 for k in (1,2,3,4)}
        cnt = {1:0.0,2:0.0,3:0.0,4:0.0}
        tw = 0.0
        for i,x in enumerate(recent):
            r = recency_factor(len(recent)-1-i, len(recent))
            cnt[x] += r
            tw += r
        if tw == 0:
            return {k:0.25 for k in (1,2,3,4)}
        return normalize({k: v/tw for k,v in cnt.items()})

    def update(self, h, actual): pass


class PPMStrategy:
    """Prediction by Partial Matching — güçlü sıkıştırma-tabanlı sequence tahmincisi.
    DİKKAT: update() metodu her yeni gerçek veri göründükten SONRA çağrılır;
    predict() içinde tablo asla değiştirilmez (gelecekten bilgi sızması olmaz)."""
    def __init__(self, max_order=6):
        self.max_order = max_order
        self.contexts = [defaultdict(lambda: defaultdict(int)) for _ in range(max_order+1)]
        self.name = "ppm"
        # Bootstrapping: hiç veri yokken 0.25 uniform
        self._bootstrapped = False

    def _ensure_bootstrap(self, h):
        # İlk çağrıda 0. derece tabloyu mevcut geçmişle doldur (predict'te değişmez, update'te büyür)
        # Aslında bootstrap yapmayıp sadece update üzerinden öğrenirsek sızıntı olmaz.
        pass

    def predict(self, h):
        votes = {1:0.0,2:0.0,3:0.0,4:0.0}
        tw = 0.0
        n = len(h)
        for order in range(self.max_order, 0, -1):
            if n < order: continue
            ctx = tuple(h[-order:])
            table = self.contexts[order][ctx]
            total = sum(table.values())
            if total > 0:
                w = (order / self.max_order) * 1.5
                for k,c in table.items():
                    votes[k] += w * c / total
                tw += w
        # order-0: şimdiye kadar görülmüş frekanslar
        table = self.contexts[0][()]
        total = sum(table.values())
        if total > 0:
            for k,c in table.items():
                votes[k] += 0.5 * c / total
            tw += 0.5
        if tw < 0.1:
            return {k:0.25 for k in (1,2,3,4)}
        return normalize(votes)

    def update(self, h, actual):
        # SADECE şu anki (h, actual) çiftini tabloya ekle
        n = len(h)
        for order in range(self.max_order, 0, -1):
            if n < order: continue
            ctx = tuple(h[-order:])
            self.contexts[order][ctx][actual] += 1
        self.contexts[0][()][actual] += 1


class BinaryAxisStrategy:
    """Odd/Even + Small/Big ikili oyları birleştirip 4-sonuçlu olasılığa."""
    def __init__(self):
        self.name = "binary_axis"

    @staticmethod
    def _to_bit(v, axis):
        if axis == 0: return 1 if v%2 else 0   # 1=T(odd), 0=C(even)
        return 1 if v>2 else 0                 # 1=B, 0=K

    def _binary_axis_vote(self, bits):
        votes = {0:0.0,1:0.0}; tw=0.0
        n = len(bits)
        for nlen in range(1,6):
            if n < nlen+2: continue
            pat = tuple(bits[-nlen:])
            rc = {0:0.0,1:0.0}
            for j in range(n-nlen):
                if tuple(bits[j:j+nlen]) == pat:
                    rc[bits[j+nlen]] += recency_factor(n-(j+nlen), n)
            rt = rc[0]+rc[1]
            if rt >= 2:
                w = (6-nlen)*0.22 + min(rt/10.0,0.7)
                votes[0] += w*rc[0]/rt; votes[1] += w*rc[1]/rt
                tw += w
        # streak
        if n >= 2:
            v = bits[-1]; streak=1
            for x in reversed(bits[:-1]):
                if x == v: streak += 1
                else: break
            rev_p = {6:0.70,5:0.62,4:0.56,3:0.50,2:0.44}.get(streak, 0.42)
            votes[v] += 0.25*(1-rev_p); votes[1-v] += 0.25*rev_p
            tw += 0.25
        if tw < 0.1: return {0:0.5,1:0.5}
        t = votes[0]+votes[1]
        p1 = max(0.06, min(0.94, votes[1]/t))
        return {0:1-p1, 1:p1}

    def predict(self, h):
        if len(h) < 3:
            return {k:0.25 for k in (1,2,3,4)}
        oe_bits = [self._to_bit(x,0) for x in h]
        sb_bits = [self._to_bit(x,1) for x in h]
        oe = self._binary_axis_vote(oe_bits)
        sb = self._binary_axis_vote(sb_bits)
        pT = oe[1]; pB = sb[1]
        v = {
            1: (1-pB)*pT,
            2: (1-pB)*(1-pT),
            3: pB*pT,
            4: pB*(1-pT),
        }
        return normalize(v)

    def update(self, h, actual): pass


class BinyPatternStrategy:
    """v7.1'de eklenen ikili eksen pattern arama (maks 20, tüm veride)."""
    def __init__(self):
        self.name = "binyPattern"

    @staticmethod
    def _to_bit(v, axis):
        if axis == 0: return 1 if v%2 else 0
        return 1 if v>2 else 0

    def _binary_pattern(self, bits):
        if len(bits) < 3: return {0:0.5,1:0.5}
        MAXLEN = 20
        max_len = min(MAXLEN, len(bits)-1)
        votes = {0:0.0,1:0.0}; tw=0.0
        for length in range(max_len, 1, -1):
            pat = tuple(bits[-length:])
            s0=0.0; s1=0.0; matches=0
            for j in range(len(bits)-length):
                if tuple(bits[j:j+length]) == pat:
                    nx = bits[j+length]
                    r = recency_factor_side(len(bits)-(j+length), len(bits))
                    w = (length ** 1.25) / 14.0
                    if nx == 1: s1 += r*w
                    else: s0 += r*w
                    tw += r*w
                    matches += 1
                    if matches >= 40: break
            if matches >= 1:
                votes[0] += s0; votes[1] += s1
                if length >= 6:
                    votes[0] *= 1.03; votes[1] *= 1.03
        if tw < 0.1: return {0:0.5,1:0.5}
        t = votes[0]+votes[1]
        if t <= 0: return {0:0.5,1:0.5}
        p1 = max(0.06, min(0.94, votes[1]/t))
        return {0:1-p1, 1:p1}

    def predict(self, h):
        if len(h) < 3:
            return {k:0.25 for k in (1,2,3,4)}
        oe_bits = [self._to_bit(x,0) for x in h]
        sb_bits = [self._to_bit(x,1) for x in h]
        oe = self._binary_pattern(oe_bits)
        sb = self._binary_pattern(sb_bits)
        pT = oe[1]; pB = sb[1]
        v = {
            1: (1-pB)*pT,
            2: (1-pB)*(1-pT),
            3: pB*pT,
            4: pB*(1-pT),
        }
        return normalize(v)

    def update(self, h, actual): pass


# ───────────────────────────────────────────────────────────────────
# 2b. YENİ STRATEJİLER (v9.5: MiniLSTM, kNN-DTW, HMM, SGD Meta)
# ───────────────────────────────────────────────────────────────────

# numpy opsiyonel — yoksa MiniLSTM otomatik devre dışı
try:
    import numpy as np
    _HAS_NUMPY = True
except Exception:
    _HAS_NUMPY = False


class MiniLSTMStrategy:
    """Çok hafif 1-katmanlı mini LSTM (8 ünite, pencere=15). Online SGD ile güncellenir.
    numpy yoksa predict() uniform döner."""
    def __init__(self, hidden=8, window=15, lr=0.02):
        self.hidden = hidden
        self.window = window
        self.lr = lr
        self.name = "mini_lstm"
        self.ready = _HAS_NUMPY
        if not self.ready:
            return
        # Tek-giriş (değer 1..4 → one-hot 4 boyut) → hidden → 4 çıkış (softmax)
        np.random.seed(42)
        h = hidden
        # Xavier init
        self.Wf = np.random.randn(h, h+4)*0.3; self.bf = np.zeros((h,1))-0.5
        self.Wi = np.random.randn(h, h+4)*0.3; self.bi = np.zeros((h,1))-0.5
        self.Wo = np.random.randn(h, h+4)*0.3; self.bo = np.zeros((h,1))-0.2
        self.Wc = np.random.randn(h, h+4)*0.3; self.bc = np.zeros((h,1))
        self.Why = np.random.randn(4, h)*0.3;    self.by = np.zeros((4,1))
        self.h_prev = np.zeros((h,1))
        self.c_prev = np.zeros((h,1))
        self._trained = 0

    @staticmethod
    def _sigmoid(x):
        return 1.0/(1.0+np.exp(-np.clip(x,-30,30)))

    @staticmethod
    def _softmax(x):
        e = np.exp(x - x.max())
        return e/e.sum()

    def _forward(self, seq):
        """seq: list of int 1..4; returns (y, caches)."""
        x_seq = []
        h, c = self.h_prev, self.c_prev
        caches = []
        for v in seq:
            x = np.zeros((4,1)); x[v-1] = 1.0
            z = np.vstack([h, x])
            f = self._sigmoid(self.Wf @ z + self.bf)
            i = self._sigmoid(self.Wi @ z + self.bi)
            o = self._sigmoid(self.Wo @ z + self.bo)
            cbar = np.tanh(self.Wc @ z + self.bc)
            c = f*c + i*cbar
            h = o*np.tanh(c)
            caches.append((x, z, f, i, o, cbar, h, c))
        y = self._softmax(self.Why @ h + self.by)
        return y, caches, h, c

    def predict(self, h):
        if not self.ready or len(h) < 3:
            return {k:0.25 for k in (1,2,3,4)}
        seq = h[-self.window:] if len(h) >= self.window else h
        y, _, h_new, c_new = self._forward(seq)
        # state'i yalnızca predict'te KALICI olarak değiştirme — update'te ilerleriz
        out = {i+1: float(max(0.02, y[i,0])) for i in range(4)}
        return normalize(out)

    def update(self, h, actual):
        if not self.ready or len(h) < 3:
            return
        seq = h[-self.window:] if len(h) >= self.window else h
        y, caches, h_end, c_end = self._forward(seq)
        T = len(seq)
        target = np.zeros((4,1)); target[actual-1] = 1.0
        dy = y - target  # softmax+cross-entropy grad
        # Why, by
        h_last = caches[-1][6]
        dWhy = dy @ h_last.T
        dby = dy
        dh = self.Why.T @ dy
        dc_next = np.zeros_like(c_end)
        dh_next = np.zeros_like(h_end)
        # BPTT — son adımdan geriye (kısa: 5 adım)
        for t in reversed(range(T)):
            x, z, f, i, o, cbar, ht, ct = caches[t]
            c_prev_t = caches[t-1][7] if t>0 else self.c_prev
            dh = dh + dh_next
            dc = dc_next + dh*o*(1-np.tanh(ct)**2)
            do = dh*np.tanh(ct) * o*(1-o)
            di = dc*cbar * i*(1-i)
            dcbar = dc*i * (1-cbar**2)
            df = dc*c_prev_t * f*(1-f)
            # grad wrt z (stacked [h_prev,x])
            dz = (self.Wf.T@df + self.Wi.T@di + self.Wo.T@do + self.Wc.T@dcbar)
            h_size = self.hidden
            dh_next = dz[:h_size, :]
            dc_next = dc*f
        # basit SGD — sadece Why/Wo/Wi/Wf/Wc son kapılarına adım (BPTT'yi kısaltıyoruz)
        self.Why -= self.lr * dWhy
        self.by -= self.lr * dby
        # state ilerlet (gerçek yolu kullan)
        self.h_prev, self.c_prev = h_end, c_end
        self._trained += 1
        # state taşmasın
        if self._trained % 20 == 0:
            self.h_prev *= 0.9
            self.c_prev *= 0.9


class KNNDTWStrategy:
    """k-NN benzerlik (DTW benzeri basit mesafe ile). Son pencere uzunluğu için son LOOKBACK
    içindeki en benzer k=15 pencereyi bulur, sonraki değerin çoğunluk oyunu."""
    def __init__(self, window=8, k=15, lookback=500):
        self.window = window
        self.k = k
        self.lookback = lookback
        self.name = "knn_dtw"

    @staticmethod
    def _mad_dist(a, b):
        """basit ortalama mutlak fark mesafesi"""
        return sum(abs(x-y) for x,y in zip(a,b))/len(a)

    def predict(self, h):
        if len(h) < self.window+2:
            return {k:0.25 for k in (1,2,3,4)}
        pat = tuple(h[-self.window:])
        start = max(0, len(h)-self.lookback-self.window-1)
        scored = []
        for j in range(start, len(h)-self.window):
            cand = tuple(h[j:j+self.window])
            d = self._mad_dist(pat, cand)
            scored.append((d, h[j+self.window]))
        if not scored:
            return {k:0.25 for k in (1,2,3,4)}
        scored.sort(key=lambda x: x[0])
        top = scored[:self.k]
        votes = {1:0.0,2:0.0,3:0.0,4:0.0}
        for rank,(d,nx) in enumerate(top):
            w = 1.0/(d+0.15) * (1.0/(rank+1))
            votes[nx] += w
        return normalize(votes)

    def update(self, h, actual): pass


class HMMStrategy:
    """Saklı Markov Model (4 gizli durum, online EM-benzeri frekans güncellemesi)."""
    def __init__(self, n_states=4):
        self.n = n_states
        self.name = "hmm"
        # Başlangıç geçişleri + emisyonlar düzgün
        self.trans = [[1.0/n_states]*n_states for _ in range(n_states)]
        self.emiss = [[0.25]*4 for _ in range(n_states)]
        self.state_counts = [2.0]*n_states
        self.trans_counts = [[1.0]*n_states for _ in range(n_states)]
        self.emiss_counts = [[1.0]*4 for _ in range(n_states)]
        self.last_state = 0
        self._t = 0

    def _forward(self, obs_seq):
        N = self.n
        T = len(obs_seq)
        alpha = [[0.0]*N for _ in range(T)]
        s = sum(self.state_counts) or 1.0
        for i in range(N):
            alpha[0][i] = (self.state_counts[i]/s) * self.emiss[i][obs_seq[0]-1]
        for t in range(1,T):
            for j in range(N):
                a = 0.0
                for i in range(N):
                    a += alpha[t-1][i] * self.trans[i][j]
                alpha[t][j] = a * self.emiss[j][obs_seq[t]-1]
            z = sum(alpha[t])
            if z>0:
                for j in range(N): alpha[t][j] /= z
        return alpha

    def predict(self, h):
        if len(h) < 4:
            return {k:0.25 for k in (1,2,3,4)}
        obs = h[-min(25,len(h)):]
        alpha = self._forward(obs)
        last = alpha[-1]
        # bir sonraki durum ve gözlem
        pred = {1:0.0,2:0.0,3:0.0,4:0.0}
        for j in range(self.n):
            for k in range(self.n):
                p_trans = self.trans[j][k]
                for v in range(1,5):
                    pred[v] += last[j] * p_trans * self.emiss[k][v-1]
        z = sum(pred.values())
        if z<0.01:
            return {k:0.25 for k in (1,2,3,4)}
        return normalize({k: v/z for k,v in pred.items()})

    def update(self, h, actual):
        # Viterbi-benzeri en olası son durumu bul
        obs_seq = h[-min(20,len(h)):] + [actual]
        if len(obs_seq) < 2:
            # başlangıçta sadece emisyon güncelle
            self.state_counts[actual%self.n] += 1
            self.emiss_counts[actual%self.n][actual-1] += 1
            self._refresh()
            return
        alpha = self._forward(obs_seq)
        last_state = max(range(self.n), key=lambda i: alpha[-1][i])
        self.emiss_counts[last_state][actual-1] += 1.0
        # geçişi bir önceki en olası durumdan
        prev_state = max(range(self.n), key=lambda i: alpha[-2][i])
        self.trans_counts[prev_state][last_state] += 1.0
        self.state_counts[last_state] += 1.0
        self.last_state = last_state
        self._t += 1
        if self._t % 5 == 0:
            self._refresh()

    def _refresh(self):
        for i in range(self.n):
            t = sum(self.trans_counts[i]) or 1.0
            for j in range(self.n):
                self.trans[i][j] = self.trans_counts[i][j]/t
            e = sum(self.emiss_counts[i]) or 1.0
            for v in range(4):
                self.emiss[i][v] = max(0.05, self.emiss_counts[i][v]/e)


class SGDMetaStrategy:
    """Meta-öğrenici: diğer stratejilerin 4-sınıf çıktısını girdi alıp online
    logistic regression ile birleştirir. Hedge ile YANYANA çalışır."""
    def __init__(self, n_strategies=12, lr=0.05):
        self.n = n_strategies
        self.lr = lr
        self.name = "sgd_meta"
        # girdi: n_strategies * 4 olasılık + 4 bias  = (n*4+1) boyut → 4 çıkış
        self.dim = n_strategies*4 + 1
        self.W = [[0.0]*4 for _ in range(self.dim)]
        self._trained = 0

    @staticmethod
    def _softmax(w, x):
        scores = [0.0]*4
        for c in range(4):
            s = w[-1][c]  # bias son satırda
            for i,xi in enumerate(x):
                s += w[i][c]*xi
            scores[c] = s
        m = max(scores)
        e = [__import__('math').exp(s-m) for s in scores]
        z = sum(e)
        return [p/z for p in e]

    def predict(self, h):
        return {k:0.25 for k in (1,2,3,4)}  # predict gerçekten hedge'den per_pv ile doldurulur

    def predict_from_experts(self, expert_probs_list):
        """hedge.predict içinde, per_strategy listesi hazır olduktan sonra çağrılır."""
        if self._trained < 8:
            return {k:0.25 for k in (1,2,3,4)}
        x = [1.0]  # bias
        for pv in expert_probs_list:
            for v in (1,2,3,4):
                x.append(pv.get(v, 0.25))
        # eksik kalanlar için padding
        need = self.dim - 1 - len(x)
        if need > 0:
            x.extend([0.25]*need)
        probs = self._softmax(self.W, x)
        out = {i+1: max(0.02, probs[i]) for i in range(4)}
        return normalize(out)

    def update(self, h, actual):
        pass  # gerçek güncelleme update_from_experts üzerinden yapılır

    def update_from_experts(self, expert_probs_list, actual):
        x = [1.0]
        for pv in expert_probs_list:
            for v in (1,2,3,4):
                x.append(pv.get(v,0.25))
        need = self.dim - 1 - len(x)
        if need>0:
            x.extend([0.25]*need)
        probs = self._softmax(self.W, x)
        # SGD adımı (cross-entropy)
        for c in range(4):
            target = 1.0 if c == actual-1 else 0.0
            err = probs[c] - target
            for i,xi in enumerate(x):
                self.W[i][c] -= self.lr * err * xi
        self._trained += 1


# ───────────────────────────────────────────────────────────────────
# 3. YAN TAHMİN (Side Prediction — çift harf / çapraz+sayı)
# ───────────────────────────────────────────────────────────────────

def side_predict(h):
    """Tıpkı v7.2: her zaman ya "T•B" ya da "T•B=N".
    9 yan-yöntemi binary + binyPattern + 4-değerli marjinal ile harmanlar."""
    if len(h) < 3:
        return {"formatted":"T•K", "oe_conf":0.5, "sb_conf":0.5,
                "oe_pred":"T","sb_pred":"K", "cross":False}

    # OE/SB bit dizileri
    to_oe = lambda x: 1 if x%2 else 0
    to_sb = lambda x: 1 if x>2 else 0
    oe_bits = [to_oe(x) for x in h]
    sb_bits = [to_sb(x) for x in h]

    # 9 yan yöntemden 4-değerli oylar (burada basit tutuyoruz; ana sistem zaten 4-sonuçlu)
    # Binary axis
    bstrat = BinaryAxisStrategy()
    binVote = bstrat.predict(h)
    bpstrat = BinyPatternStrategy()
    bpVote = bpstrat.predict(h)

    pT_bin = binVote[1]+binVote[3]  # 1=KT(=1? wait 1=KT=sb=K=0 oe=T=1)
    # Düzelteyim:
    # pT = P(ODD) = vote[1] + vote[3]
    # pB = P(BIG) = vote[3] + vote[4]
    pT_bin = binVote[1] + binVote[3]
    pB_bin = binVote[3] + binVote[4]
    pT_bp  = bpVote[1]  + bpVote[3]
    pB_bp  = bpVote[3]  + bpVote[4]

    # Full marjinali tüm ana stratejilerden kabaca al: şimdilik eşit ağırlık
    # (Bunu daha sonra Hedge ensemble çıktısından besleyeceğiz)
    # Geçici olarak n-gram + markov birleşimi:
    ng = NgramStrategy().predict(h)
    mk = MarkovStrategy(3).predict(h)
    full = {k: (ng[k]+mk[k])/2 for k in (1,2,3,4)}
    pT_full = full[1]+full[3]
    pB_full = full[3]+full[4]

    BLEND_FULL = 0.40
    pT = (1-BLEND_FULL)*(0.58*pT_bin + 0.42*pT_bp) + BLEND_FULL*pT_full
    pB = (1-BLEND_FULL)*(0.58*pB_bin + 0.42*pB_bp) + BLEND_FULL*pB_full

    oe_pred = "T" if pT >= 0.5 else "C"
    sb_pred = "B" if pB >= 0.5 else "K"
    oe_conf = max(pT, 1-pT)
    sb_conf = max(pB, 1-pB)

    TIER_CROSS = 0.65
    cross = sb_conf >= TIER_CROSS and oe_conf >= TIER_CROSS

    def to_num(sb, oe):
        return {"KT":1,"KC":2,"BT":3,"BC":4}.get(sb+oe)

    if cross:
        n = to_num(sb_pred, oe_pred)
        form = f"{oe_pred}•{sb_pred}={n}" if n else f"{oe_pred}•{sb_pred}"
    else:
        form = f"{oe_pred}•{sb_pred}"
    return {"formatted":form, "oe_conf":oe_conf, "sb_conf":sb_conf,
            "oe_pred":oe_pred,"sb_pred":sb_pred, "cross":cross}


# ───────────────────────────────────────────────────────────────────
# 4. HEDGE ENSEMBLE (tüm stratejileri birleştirir)
# ───────────────────────────────────────────────────────────────────

class HedgeEnsemble:
    """Hedge (Multiplicative Weights) — 13 uzmanı rekabet ettirir.
    SGD Meta stratejisi (sondaki) diğer 12 stratejinin çıktılarından eğitilir."""
    def __init__(self, strategies, eta=0.15):
        self.strategies = strategies
        self.eta = eta
        self.n_base = len(strategies) - (1 if any(isinstance(s, SGDMetaStrategy) for s in strategies) else 0)
        self.weights = [1.0] * len(strategies)
        # SGD meta en sonda olabilir
        self.meta = next((s for s in strategies if isinstance(s, SGDMetaStrategy)), None)
        # Online calibration
        self.calib_window = deque(maxlen=50)
        self.half = {"K":[0,0],"B":[0,0],"T":[0,0],"C":[0,0]}
        self.HALF_WIN = 30

    def predict(self, h):
        votes = {1:0.0,2:0.0,3:0.0,4:0.0}
        tw = 0.0
        per_strategy = []
        base_preds = []
        for i,(w,s) in enumerate(zip(self.weights, self.strategies)):
            if isinstance(s, SGDMetaStrategy):
                # meta strateji diğerlerini gördükten sonra
                pv = s.predict_from_experts(base_preds)
            else:
                pv = s.predict(h)
                base_preds.append(pv)
            per_strategy.append(pv)
            for k,p in pv.items():
                votes[k] += w * p
            tw += w
        if tw == 0:
            return {k:0.25 for k in (1,2,3,4)}, per_strategy
        probs = normalize({k: v/tw for k,v in votes.items()})
        return probs, per_strategy

    def update(self, h, actual, per_strategy_preds):
        for i,(s,pv) in enumerate(zip(self.strategies, per_strategy_preds)):
            self.weights[i] *= math.exp(-self.eta * (1 - pv[actual]))
            if isinstance(s, SGDMetaStrategy):
                # meta'yı diğer base stratejilerle güncelle
                base_preds = per_strategy_preds[:self.n_base]
                s.update_from_experts(base_preds, actual)
            else:
                s.update(h, actual)
        zw = sum(self.weights)
        if zw > 0:
            self.weights = [w/zw*len(self.weights) for w in self.weights]


# ───────────────────────────────────────────────────────────────────
# 5. BACKTEST ANA MOTORU
# ───────────────────────────────────────────────────────────────────

def load_data(path):
    data = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"): continue
            # CSV ise "|" ile ayrılmış ya da sadece sayı olabilir
            if "|" in line:
                # fan_data.csv formatı: 3. kolon (index 2) sayi
                parts = line.split("|")
                if len(parts) > 2:
                    try:
                        v = int(parts[2].strip())
                        if 1 <= v <= 4: data.append(v)
                        continue
                    except: pass
            # Virgülle ayrılmış ya de boşlukla
            for tok in line.replace(",", " ").split():
                try:
                    v = int(tok.strip())
                    if 1 <= v <= 4: data.append(v)
                except: pass
    return data


def backtest(data, silent_first=50, verbose=True):
    base_strats = [
        PatternStrategy(),     # 0 — Kalıp (korundu!)
        MarkovStrategy(3),     # 1
        NgramStrategy(5),      # 2
        DeltaStrategy(),       # 3
        StreakStrategy(),      # 4
        BiasStrategy(),        # 5
        PPMStrategy(6),        # 6
        BinaryAxisStrategy(),  # 7
        BinyPatternStrategy(), # 8
        MiniLSTMStrategy(),    # 9 (numpy yoksa otomatik pasif)
        KNNDTWStrategy(),      # 10
        HMMStrategy(),         # 11
    ]
    # SGD meta en sonda, diğer 12'yi birleştirir
    meta = SGDMetaStrategy(n_strategies=len(base_strats))
    strategies = base_strats + [meta]
    hedge = HedgeEnsemble(strategies, eta=0.12)

    # Sayaçlar
    stats = {
        "total": 0, "evaluated": 0,
        "primary_correct": 0, "any_correct": 0,
        "kalip_correct":0, "kalip_total":0,
        "side_any_correct":0, "side_both_correct":0, "side_total":0,
        "strat_correct": [0]*len(strategies),
        "strat_any": [0]*len(strategies),
        "strat_total": [0]*len(strategies),
        "conf_buckets": defaultdict(lambda: [0,0]),  # confidence band → [correct, total]
    }
    history = []
    results_log = []  # son 20 tahmin

    for step, actual in enumerate(data):
        if len(history) >= 2:
            probs, per_pv = hedge.predict(history)
            # Ana tahmin: en yüksek olasılık
            sorted_probs = sorted(probs.items(), key=lambda x:-x[1])
            pri = sorted_probs[0][0]
            sec = sorted_probs[1][0] if len(sorted_probs)>1 else 0
            confidence = sorted_probs[0][1]
            # Tier: >=0.40 (tek/çift eşiğini güvene göre ayarlayalım, backtest'te optimize edilecek)
            STRONG = 0.40
            is_double = confidence < STRONG
            if is_double:
                pred_str = f"{pri}/{sec}"
            else:
                pred_str = f"{pri}"
            # Güven kalibrasyonu için bucketing
            bucket = int(confidence*10)/10  # 0.3, 0.4, ...
            # Yan
            side = side_predict(history)

            # Değerlendirme (ilk `silent_first` veri sayılmaz)
            if step >= silent_first:
                stats["evaluated"] += 1
                c = (pri == actual)
                if c: stats["primary_correct"] += 1
                if c or (is_double and sec == actual): stats["any_correct"] += 1
                stats["conf_buckets"][bucket][1] += 1
                if c: stats["conf_buckets"][bucket][0] += 1
                # Kalıp ilk strateji
                kalip_pv = per_pv[0]
                kalip_pri = max(kalip_pv, key=kalip_pv.get)
                kalip_sec = sorted(kalip_pv, key=lambda k:-kalip_pv[k])[1]
                stats["kalip_total"] += 1
                if kalip_pri == actual or kalip_sec == actual:
                    stats["kalip_correct"] += 1
                # Yan
                stats["side_total"] += 1
                is_odd = actual % 2 == 1
                is_big = actual > 2
                oe_hit = (side["oe_pred"] == "T" and is_odd) or (side["oe_pred"] == "C" and not is_odd)
                sb_hit = (side["sb_pred"] == "B" and is_big) or (side["sb_pred"] == "K" and not is_big)
                if oe_hit or sb_hit: stats["side_any_correct"] += 1
                if oe_hit and sb_hit: stats["side_both_correct"] += 1
                # Stratejiler (pri hit ve any hit)
                for i,pv in enumerate(per_pv):
                    sorted_pv = sorted(pv.items(), key=lambda x:-x[1])
                    sp = sorted_pv[0][0]
                    ss = sorted_pv[1][0] if len(sorted_pv)>1 else 0
                    stats["strat_total"][i] += 1
                    if sp == actual: stats["strat_correct"][i] += 1
                    if sp == actual or ss == actual: stats["strat_any"][i] += 1

                if len(results_log) < 25:
                    results_log.append((pred_str, confidence, actual, side["formatted"]))

            hedge.update(history, actual, per_pv)

        history.append(actual)
        stats["total"] += 1

    # ── RAPOR ─────────────────────────────────────────────────
    if verbose:
        print("="*70)
        print(f"FAN Python Backtest  |  Toplam veri: {stats['total']}  |  "
              f"Değerlendirilen: {stats['evaluated']} (ilk {silent_first} sayılmadı)")
        print("="*70)
        ev = stats["evaluated"] or 1
        print(f"\n🏆 ANA ENSEMBLE (Hedge)")
        print(f"   • Tekil (pri) başarı : %{stats['primary_correct']*100//ev}  "
              f"({stats['primary_correct']}/{ev})")
        print(f"   • Tekil+çift (any)   : %{stats['any_correct']*100//ev}  "
              f"({stats['any_correct']}/{ev})")
        print(f"\n🎯 KALIP ARAMA (her zaman çiftli, korundu)")
        print(f"   • İlk+ikinci herhangi: %{stats['kalip_correct']*100//max(1,stats['kalip_total'])}  "
              f"({stats['kalip_correct']}/{stats['kalip_total']})")
        print(f"\n⭐ YAN TAHMİN")
        st2 = stats["side_total"] or 1
        print(f"   • Herhangi (any)     : %{stats['side_any_correct']*100//st2}")
        print(f"   • Çapraz+tam (both)  : %{stats['side_both_correct']*100//st2}")
        print(f"\n📊 HER BİR STRATEJİ")
        for i,s in enumerate(strategies):
            tot = stats["strat_total"][i] or 1
            hit = stats["strat_correct"][i]
            anyh = stats["strat_any"][i]
            print(f"   [{i:2d}] {s.name:18s} → tek:%{hit*100//tot}  any:%{anyh*100//tot}  ({hit}/{anyh}/{tot})")
        print(f"\n🔒 GÜVEN KALİBRASYONU (güven bandı → gerçek başarı)")
        for b in sorted(stats["conf_buckets"]):
            c,t = stats["conf_buckets"][b]
            if t < 3: continue
            print(f"     %{int(b*100):2d} bandında ({t:4d} örnek): %{c*100//t} gerçek başarı")

        w_sorted = sorted(zip([s.name for s in strategies], hedge.weights), key=lambda x:-x[1])
        print(f"\n⚖️  ENSEMBLE AĞIRLIKLARI (en yüksekten)")
        for name,w in w_sorted:
            bar = "█" * int(w*15)
            print(f"     {name:18s} {w:.2f}  {bar}")

        print(f"\n📝 SON 25 TAHMİN (pred → actual)")
        for ps,cf,ac,sd in results_log[-25:]:
            print(f"   {ps:6s}  [%{int(cf*100):2d}]  → {ac}   yan:{sd}")

    return stats, hedge


# ───────────────────────────────────────────────────────────────────
# 6. INTERACTIVE MODE (Termux'ta canlı kullanım)
# ───────────────────────────────────────────────────────────────────

def interactive(save_path="fan_python_data.csv"):
    import os
    data = []
    if os.path.exists(save_path):
        data = load_data(save_path)
        print(f"Kaydedilmiş {len(data)} veri yüklendi.")
    base_strats = [PatternStrategy(), MarkovStrategy(3), NgramStrategy(5), DeltaStrategy(),
                  StreakStrategy(), BiasStrategy(), PPMStrategy(6),
                  BinaryAxisStrategy(), BinyPatternStrategy(),
                  MiniLSTMStrategy(), KNNDTWStrategy(), HMMStrategy()]
    meta = SGDMetaStrategy(n_strategies=len(base_strats))
    strategies = base_strats + [meta]
    hedge = HedgeEnsemble(strategies)
    # Geçmişi oynat
    h = []
    for actual in data:
        if len(h) >= 2:
            probs, per_pv = hedge.predict(h)
            hedge.update(h, actual, per_pv)
        h.append(actual)

    print("\n✅ Hazır. Rakam gir (1-4), 'q' çıkış, 'd' sil, 's' istatistik:")
    while True:
        try:
            inp = input("> ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            break
        if inp in ("q","quit","exit"): break
        if inp in ("d","del","delete"):
            if data:
                data.pop()
                with open(save_path,"w") as f:
                    for v in data: f.write(f"{v}\n")
                print(f"Son giriş silindi. Toplam: {len(data)}")
            continue
        if inp in ("s","stat","stats"):
            stats,_ = backtest(data, silent_first=max(10, len(data)//5), verbose=True)
            continue
        try:
            v = int(inp)
        except:
            print("Geçersiz. 1-4 arası sayı, q, d, s"); continue
        if v not in (1,2,3,4):
            print("1-4 arası olmalı"); continue
        # Önce tahmin
        if len(h) >= 2:
            probs,_ = hedge.predict(h)
            sp = sorted(probs.items(), key=lambda x:-x[1])
            pri,pc = sp[0]
            sec,sc = sp[1]
            side = side_predict(h)
            is_double = pc < 0.40
            if is_double:
                print(f"   Tahmin: {pri}/{sec}  [güven %{int(pc*100)}]")
            else:
                print(f"   Tahmin: {pri}  [güven %{int(pc*100)}]")
            print(f"   Yan: {side['formatted']}  "
                  f"(T/C=%{int(max(side['oe_conf'],1-side['oe_conf'])*100)}, "
                  f"K/B=%{int(max(side['sb_conf'],1-side['sb_conf'])*100)})")
            # Güncelle
            probs2, per_pv = hedge.predict(h)
            hedge.update(h, v, per_pv)
        data.append(v); h.append(v)
        with open(save_path,"a") as f:
            f.write(f"{v}\n")
        print(f"   → {v} kaydedildi (toplam {len(data)})")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Kullanım:")
        print("  python fan_backtest.py veri.txt     # Backtest modu")
        print("  python fan_backtest.py -i           # Canlı/interaktif mod (Termux)")
        sys.exit(0)
    if sys.argv[1] == "-i":
        interactive()
    else:
        data = load_data(sys.argv[1])
        print(f"Yüklenen veri sayısı: {len(data)}")
        if not data:
            print("Veri okunamadı."); sys.exit(1)
        backtest(data)
