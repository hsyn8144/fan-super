#!/usr/bin/env python3
"""
FAN Live Monitor v9.6
=====================
Termux'ta/PC'de calisir. Download/FAN/fan_data.csv'yi izler, yeni veri geldikce
online ogrenmeye devam eder, her yeni tahmin icin Download/FAN/fan_python_log.csv'ye
bir satir yazar (Kotlin uygulamasi bu log'u okur).

CSV format (fan_python_log.csv, basliksiz, | ile ayrilmis) — v9.6:
  ts|pri|sec|conf|side|side_conf|oe_conf|sb_conf|
  kpri|ksec|kconf|evaluated|pri_acc|any_acc|side_any_acc|
  strat_pri_hits|strat_any_hits|strat_n|weights_summary

  - strat_* alanlari virgulle ayrisik 13 sayidir (sirasiyla 13 strateji).
"""
import os
import sys
import time
import argparse
from collections import deque

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fan_backtest import (
    PatternStrategy, MarkovStrategy, NgramStrategy, DeltaStrategy,
    StreakStrategy, BiasStrategy, PPMStrategy, BinaryAxisStrategy,
    BinyPatternStrategy, MiniLSTMStrategy, KNNDTWStrategy, HMMStrategy,
    SGDMetaStrategy, HedgeEnsemble, side_predict, _HAS_NUMPY,
)

DEFAULT_PATHS = [
    # Buyuk/kucuk harf duyarli cihazlar icin hem "fan" hem "FAN" dene
    os.path.expanduser("~/storage/downloads/FAN/fan_data.csv"),
    os.path.expanduser("~/storage/downloads/fan/fan_data.csv"),
    os.path.expanduser("~/storage/downloads/fan_data_live.csv"),
    os.path.expanduser("~/storage/downloads/fan_data.csv"),
    os.path.expanduser("~/fan_data.csv"),
    "/sdcard/Download/FAN/fan_data.csv",
    "/sdcard/Download/fan/fan_data.csv",
    "/sdcard/Download/fan_data.csv",
    "/storage/emulated/0/Download/FAN/fan_data.csv",
    "/storage/emulated/0/Download/fan/fan_data.csv",
]

LOG_FILE_NAME = "fan_python_log.csv"
SILENT_THRESHOLD = 50
STRONG_TIER = 0.40

STRATEGY_NAMES = [
    "Kalip (Pattern)",
    "Markov-3",
    "N-gram (5)",
    "Delta",
    "Streak (Seri)",
    "Bias (Siklik)",
    "PPM (6)",
    "Binary Axis",
    "Biny Pattern",
    "Mini LSTM",
    "kNN-DTW",
    "HMM",
    "SGD Meta",
]


def find_folder(user_path=None):
    if user_path:
        if os.path.exists(user_path):
            folder = os.path.dirname(user_path) or "."
            return user_path, os.path.join(folder, LOG_FILE_NAME)
        return None, None
    for p in DEFAULT_PATHS:
        if os.path.exists(p):
            folder = os.path.dirname(p)
            return p, os.path.join(folder, LOG_FILE_NAME)
    return None, None


class LiveTracker:
    def __init__(self, silent=SILENT_THRESHOLD):
        base = [
            PatternStrategy(),     # 0
            MarkovStrategy(3),     # 1
            NgramStrategy(5),      # 2
            DeltaStrategy(),       # 3
            StreakStrategy(),      # 4
            BiasStrategy(),        # 5
            PPMStrategy(6),        # 6
            BinaryAxisStrategy(),  # 7
            BinyPatternStrategy(), # 8
            MiniLSTMStrategy(),    # 9
            KNNDTWStrategy(),      # 10
            HMMStrategy(),         # 11
        ]
        meta = SGDMetaStrategy(n_strategies=len(base))  # 12
        self.strats = base + [meta]
        self.hedge = HedgeEnsemble(self.strats, eta=0.12)
        self.silent = silent
        self.history = []
        # Genel sayaclar
        self.evaluated = 0
        self.pri_hit = 0
        self.any_hit = 0
        self.kalip_hit = 0
        self.yan_any = 0
        self.yan_both = 0
        # Her strateji icin [pri_hits, any_hits, n]
        self.strat_stats = [[0, 0, 0] for _ in self.strats]
        self.last_pred = None  # (pri, sec, conf, side, kpv, per_strat)
        self._last_ppv = None
        self.window = deque(maxlen=50)

    # ------------------------------------------------------------------
    def _per_strategy_preds(self, ppv):
        out = []
        for pv in ppv:
            if not pv:
                out.append((0, None)); continue
            sp = sorted(pv.items(), key=lambda x: -x[1])
            pri = sp[0][0]
            sec = sp[1][0] if len(sp) > 1 else None
            out.append((pri, sec))
        return out

    def feed_new(self, value, log_path=None, record_log=True):
        self._consume(value, record_log=record_log, log_path=log_path if record_log else None)
        if record_log:
            return self._make_prediction_and_log(log_path)
        else:
            return self._make_prediction()

    def _make_prediction(self):
        if len(self.history) < 2:
            return None
        probs, ppv = self.hedge.predict(self.history)
        sp = sorted(probs.items(), key=lambda x: -x[1])
        pri = sp[0][0]; sec = sp[1][0]; conf = sp[0][1]
        sec_final = sec if conf < STRONG_TIER else None
        side = side_predict(self.history)
        kpv = ppv[0]
        ksp = sorted(kpv.items(), key=lambda x: -x[1])
        kpri = ksp[0][0]; ksec = ksp[1][0]
        per_strat = self._per_strategy_preds(ppv)
        self.last_pred = (pri, sec_final, conf, side, kpv, per_strat)
        self._last_ppv = ppv
        return True

    def _consume(self, actual, record_log=False, log_path=None):
        if len(self.history) >= 2 and self.last_pred is not None:
            pri, sec, conf, side, kpv, per_strat = self.last_pred
            if len(self.history) >= self.silent:
                self.evaluated += 1
                c = (pri == actual)
                if c: self.pri_hit += 1
                if c or (sec is not None and sec == actual): self.any_hit += 1
                if kpv is not None:
                    ksp = sorted(kpv.items(), key=lambda x: -x[1])
                    if ksp[0][0] == actual or ksp[1][0] == actual:
                        self.kalip_hit += 1
                io = actual % 2 == 1; ib = actual > 2
                oh = (side['oe_pred'] == 'T' and io) or (side['oe_pred'] == 'C' and not io)
                bh = (side['sb_pred'] == 'B' and ib) or (side['sb_pred'] == 'K' and not ib)
                if oh or bh: self.yan_any += 1
                if oh and bh: self.yan_both += 1
                self.window.append((c, c or (sec is not None and sec == actual)))
                for i, (spri, ssec) in enumerate(per_strat):
                    if spri <= 0: continue
                    self.strat_stats[i][2] += 1
                    if spri == actual:
                        self.strat_stats[i][0] += 1
                        self.strat_stats[i][1] += 1
                    elif ssec is not None and ssec == actual:
                        self.strat_stats[i][1] += 1
            self.hedge.update(self.history, actual, self._last_ppv)
        self.history.append(actual)

    def _make_prediction_and_log(self, log_path):
        if len(self.history) < 2:
            return None
        probs, ppv = self.hedge.predict(self.history)
        sp = sorted(probs.items(), key=lambda x: -x[1])
        pri = sp[0][0]; sec = sp[1][0]; conf = sp[0][1]
        sec_final = sec if conf < STRONG_TIER else None
        side = side_predict(self.history)
        kpv = ppv[0]
        ksp = sorted(kpv.items(), key=lambda x: -x[1])
        kpri = ksp[0][0]; ksec = ksp[1][0]
        per_strat = self._per_strategy_preds(ppv)
        names = [s.name for s in self.strats]
        weight_pairs = sorted(zip(self.hedge.weights, names), reverse=True)[:3]
        wsum = ",".join(f"{n}={w:.2f}" for w, n in weight_pairs)
        self.last_pred = (pri, sec_final, conf, side, kpv, per_strat)
        self._last_ppv = ppv

        # ----- Log yaz -----
        try:
            ts = int(time.time())
            sec_str = str(sec_final) if sec_final else "0"
            n = max(1, self.evaluated)
            pri_acc = int(100.0 * self.pri_hit / n)
            any_acc = int(100.0 * self.any_hit / n)
            yan_acc = int(100.0 * self.yan_any / n)
            spri_s = ",".join(str(s[0]) for s in self.strat_stats)
            sany_s = ",".join(str(s[1]) for s in self.strat_stats)
            sn_s   = ",".join(str(s[2]) for s in self.strat_stats)
            line = "|".join([
                str(ts),
                str(pri), sec_str,
                f"%{int(conf * 100)}",
                side['formatted'],
                f"%{int(((side['oe_conf'] + side['sb_conf']) / 2) * 100)}",
                f"%{int(max(side['oe_conf'], 1 - side['oe_conf']) * 100)}",
                f"%{int(max(side['sb_conf'], 1 - side['sb_conf']) * 100)}",
                str(kpri), str(ksec), f"%{int(ksp[0][1] * 100)}",
                str(self.evaluated),
                f"%{pri_acc}", f"%{any_acc}", f"%{yan_acc}",
                spri_s, sany_s, sn_s,
                wsum,
            ])
            os.makedirs(os.path.dirname(log_path), exist_ok=True)
            with open(log_path, "a", encoding="utf-8") as f:
                f.write(line + "\n")
        except Exception as e:
            print(f"[!] Log yazilamadi: {e}", file=sys.stderr)

        return {
            "pri": pri, "sec": sec_final, "conf": conf,
            "side": side, "kalip": (kpri, ksec, ksp[0][1]),
            "per_strat": per_strat, "strat_stats": self.strat_stats,
            "pri_acc": self.pri_hit / n,
            "any_acc": self.any_hit / n,
            "side_any_acc": self.yan_any / n,
            "n": self.evaluated, "weights": weight_pairs,
        }

    # ------------------------------------------------------------------
    def snapshot_text(self, data_path, log_path):
        n = max(1, self.evaluated)
        lines = []
        lines.append("\033[2J\033[H")
        lines.append("=" * 64)
        lines.append(f"  FAN PYTHON CANLI (v9.6) — Toplam veri: {len(self.history)}")
        if not _HAS_NUMPY:
            lines.append("  (!) numpy bulunamadi — MiniLSTM pasif")
        lines.append("=" * 64)
        lines.append(f"  Veri: {data_path}")
        lines.append(f"  Log:  {log_path}")
        lines.append("")
        if len(self.history) < self.silent:
            lines.append(f"  Ogrenme: {self.silent - len(self.history)} veri daha")
        else:
            win = list(self.window) or [(0, 0)]
            wp = sum(1 for p, _ in win if p)
            wa = sum(1 for _, a in win if a)
            wt = len(win)
            lines.append(f"  GENEL (n={n})             Son 50")
            lines.append(f"     Py pri   %{100 * self.pri_hit // n:>2d}       (son 50: %{100 * wp // max(1, wt)})")
            lines.append(f"     Py any   %{100 * self.any_hit // n:>2d}       (son 50: %{100 * wa // max(1, wt)})")
            lines.append(f"     Kalip    %{100 * self.kalip_hit // n:>2d}")
            lines.append(f"     Yan any  %{100 * self.yan_any // n:>2d}  both %{100 * self.yan_both // n:>2d}")
            lines.append("")
            lines.append("  STRATEJILER:")
            for i, s in enumerate(self.strats):
                ph, ah, sn = self.strat_stats[i]
                name = STRATEGY_NAMES[i] if i < len(STRATEGY_NAMES) else s.name
                if sn < 5:
                    lines.append(f"     {name:18s}  (warmup: {sn}/5)")
                else:
                    pa = 100 * ph // sn; aa = 100 * ah // sn
                    lines.append(f"     {name:18s}  pri %{pa:>2d}  any %{aa:>2d}  (n={sn})")
        if self.last_pred is not None:
            pri, sec, conf, side, kpv, _ = self.last_pred
            lines.append("")
            lines.append(f"  PYTHON TAHMIN:  {pri}{'/' + str(sec) if sec else ''}   (guven %{int(conf * 100)})")
            lines.append(
                f"     Py Yan: {side['formatted']}  "
                f"(T/C=%{int(max(side['oe_conf'], 1 - side['oe_conf']) * 100)}  "
                f"K/B=%{int(max(side['sb_conf'], 1 - side['sb_conf']) * 100)})"
            )
            ksorted = sorted(kpv.items(), key=lambda x: -x[1])
            lines.append(f"     Kalip: {ksorted[0][0]}/{ksorted[1][0]}")
        lines.append("")
        lines.append("  Son agirliklar:")
        names = [s.name for s in self.strats]
        mxw = max(self.hedge.weights) or 1
        for name, w in sorted(zip(names, self.hedge.weights), key=lambda x: -x[1])[:6]:
            bar = "#" * int(20 * w / mxw)
            lines.append(f"     {name:14s} {w:.2f}  {bar}")
        lines.append("")
        lines.append("  (Ctrl+C ile cik)")
        return "\n".join(lines)


def read_values(path):
    values = []
    if not path or not os.path.exists(path):
        return values
    with open(path, encoding="utf-8", errors="ignore") as f:
        for line in f:
            line = line.strip()
            if not line: continue
            parts = line.split("|")
            if len(parts) < 3: continue
            if parts[0].strip() == "id": continue
            try:
                v = int(parts[2].strip())
                if 1 <= v <= 4: values.append(v)
            except ValueError:
                continue
    return values


def run_once(data_path, log_path):
    import fan_backtest as fb
    fb.backtest(read_values(data_path) or data_path)


def run_live(data_path, log_path, interval):
    tracker = LiveTracker()
    initial = read_values(data_path)
    print(f"[?] Ilk yukleme: {len(initial)} gecmis veri")

    # Gecmis veriyi modele tam olarak besle
    for v in initial[:2]:
        tracker.history.append(v)
    if len(initial) >= 2:
        tracker._make_prediction()
        for v in initial[2:]:
            tracker._consume(v, record_log=False)
            tracker._make_prediction()
    if len(initial) >= 2:
        try:
            tracker._make_prediction_and_log(log_path)
        except Exception:
            pass

    last_count = len(initial)
    print(tracker.snapshot_text(data_path, log_path))
    print(f"\n[ok] Izleniyor ({interval} sn arayla)...")
    try:
        while True:
            time.sleep(interval)
            new_vals = read_values(data_path)
            if len(new_vals) > last_count:
                added = new_vals[last_count:]
                for v in added:
                    tracker.feed_new(v, log_path=log_path, record_log=True)
                last_count = len(new_vals)
                print(tracker.snapshot_text(data_path, log_path))
    except KeyboardInterrupt:
        print("\n[.] Cikiliyor.")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("path", nargs="?", help="fan_data.csv yolu")
    ap.add_argument("--once", action="store_true")
    ap.add_argument("--interval", type=float, default=0.8)
    args = ap.parse_args()

    data_path, log_path = find_folder(args.path)
    if not data_path:
        print("[!] Veri dosyasi bulunamadi.")
        print("    Varsayilan aranan yollar:")
        for p in DEFAULT_PATHS:
            print(f"       - {p}")
        sys.exit(1)

    if args.once:
        run_once(data_path, log_path)
    else:
        if "~/storage" in data_path and not os.path.exists(os.path.expanduser("~/storage")):
            print("[!] Termux depolama izni yok. Sunu calistir:  termux-setup-storage")
        run_live(data_path, log_path, args.interval)


if __name__ == "__main__":
    main()
