# FAN Python v9.5 — Termux Kurulumu

## Yenilikler (v9.5)
- 4 yeni strateji eklendi (toplam 13):
  - **Mini LSTM**: Hafif 8-uniteli online LSTM (numpy ile)
  - **kNN-DTW**: Son 8 veriye benzer gecmis pencereleri bulur
  - **HMM**: Sakli Markov Modeli (rejim gecisleri)
  - **SGD Meta**: Diger 12 stratejinin ciktilarindan ogrenir
- Hedge ile SGD Meta yanyana calisir (biri digerini ezer)
- v8.x log formatina GERI UYUMLU (9 kolonlu eski loglar da okunur)

## Kurulum
```bash
# 1) Dosyalari ~/ veya ~/fan_python/ altina kopyala
cp fan_live.py fan_backtest.py ~/

# 2) (Opsiyonel) numpy — MiniLSTM icin gerekli
pkg install python -y
pip install numpy

# 3) Calistir
cd ~ && python fan_live.py
```

Veri yolu otomatik olarak su klasorlerde aranir:
- `~/storage/downloads/FAN/fan_data.csv`
- `~/storage/downloads/fan/fan_data.csv`
- `/sdcard/Download/FAN/fan_data.csv`
- `/storage/emulated/0/Download/FAN/fan_data.csv`

Log dosyasi `fan_python_log.csv` olarak aynı klasöre yazilir.
