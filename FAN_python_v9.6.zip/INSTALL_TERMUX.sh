#!/data/data/com.termux/files/usr/bin/bash
# FAN Python v9.5 Kurulum Scripti (Termux)
echo "========================================"
echo " FAN v9.5 Python Canli Tahmin Kurulumu"
echo "========================================"
echo ""
echo "[1/5] Depolama izni istenirse IZIN VER..."
termux-setup-storage
sleep 2
echo ""
echo "[2/5] Python ve numpy kuruluyor (ilk seferde biraz surebilir)..."
pkg update -y && pkg install python -y
pip install --quiet numpy 2>/dev/null || echo "   (!) numpy kurulamadi — MiniLSTM pasif calisacak"
echo ""
echo "[3/5] fan_live.py ve fan_backtest.py Termux home'a kopyalaniyor..."
mkdir -p ~/fan_python
cp -r ~/storage/downloads/FAN/*.py ~/fan_python/ 2>/dev/null
cp fan_live.py fan_backtest.py ~/fan_python/ 2>/dev/null
cp fan_live.py fan_backtest.py ~/ 2>/dev/null
chmod +x ~/fan_live.py ~/fan_backtest.py ~/fan_python/*.py 2>/dev/null
echo ""
echo "[4/5] v9.5: 13 strateji — MiniLSTM, kNN-DTW, HMM, SGD Meta eklendi"
echo ""
echo "[5/5] Ilk deneme calistirmasi (veri yolu otomatik bulunacak)..."
echo ""
echo "========================================"
echo " Kurulum tamam!"
echo "========================================"
echo ""
echo "Her seferinde baslatmak icin:"
echo "   cd ~"
echo "   python fan_live.py"
echo ""
sleep 2
echo ""
echo "fan_live.py simdi baslatiliyor... (cikmak icin Ctrl+C)"
sleep 2
if [ -f ~/fan_live.py ]; then
    cd ~ && python fan_live.py
else
    echo "!! fan_live.py ~/ altinda bulunamadi. Lutfen dosyalari ~/ altina koyun."
fi
